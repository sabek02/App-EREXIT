﻿const STORAGE_KEY = "cfp-erexit-manager-v1";
const SESSION_RESUME_KEY = "cfp-erexit-session-active";
const CLEANUP_MODE_KEY = "cfp-erexit-cleanup-until";
const SERVER_MODE = ["http:", "https:"].includes(window.location.protocol);
const PUBLIC_REGISTRATION_MODE = SERVER_MODE && window.location.pathname.replace(/\/+$/, "") === "/inscription";
let currentUser = null;
let studentPortalData = null;
let onlineRegistrationOptions = { courses: [], groups: [] };
let saveTimer = null;
let syncTimer = null;
let saveChain = Promise.resolve();
let lastSavedAt = "";
let serverRevision = "";
let hasPendingChanges = false;
let localChangeVersion = 0;
let lastSyncedState = null;
const personFileDrafts = {
  student: { photoData: "", documents: [] },
  trainer: { photoData: "", documents: [] },
  staff: { photoData: "", documents: [] }
};

const today = () => new Date().toISOString().slice(0, 10);
const DAY_MS = 24 * 60 * 60 * 1000;

const VIEW_LABELS = {
  dashboard: "Tableau de bord",
  onlineRequests: "Demandes en ligne",
  students: "Ã‰tudiants",
  courses: "Formations",
  groups: "Promotions",
  enrollments: "Inscriptions",
  payments: "Paiements",
  cash: "Caisse",
  attendance: "PrÃ©sences",
  trainers: "Formateurs",
  staff: "Personnel",
  grades: "Notes",
  reports: "Rapports",
  settings: "ParamÃ¨tres"
};

const ACCESS_VIEWS = Object.keys(VIEW_LABELS);
const MANAGED_ACCESS_VIEWS = ACCESS_VIEWS.filter(view => view !== "settings");
const ROLE_OPTIONS = ["Administrateur", "Directeur", "Secrétaire", "Comptable", "Formateur", "Accueil", "Etudiant"];
const TUITION_MOTIF_KEYS = ["scolarite", "formation", "mensualite"];
const MAKEUP_MOTIF_KEY = "rattrapage";
const PASSING_SCORE_20 = 12;
const MAKEUP_FEE = 5000;
const TABLE_PAGE_SIZE = 25;
const tablePages = {};

function defaultPaymentMotifs() {
  return [
    { key: "scolarite", label: "ScolaritÃ©", amount: 0 },
    { key: "inscription", label: "Inscription", amount: 15000 },
    { key: "document", label: "Document", amount: 5000 },
    { key: "tenue", label: "Tenue", amount: 25000 },
    { key: "tshirt", label: "T-shirt", amount: 5000 },
    { key: "macaron", label: "Macaron", amount: 2000 },
    { key: MAKEUP_MOTIF_KEY, label: "Rattrapage", amount: MAKEUP_FEE }
  ];
}

function defaultDocumentTemplates() {
  return [
    {
      key: "attestation-inscription",
      title: "Attestation d'inscription",
      category: "Attestation",
      audience: "student",
      status: "active",
      locked: true,
      content: `Nous soussignÃ©s {{centre_nom}}, attestons que {{etudiant_nom}}, matricule {{matricule}}, est rÃ©guliÃ¨rement inscrit(e) Ã  la formation {{formation}}, promotion {{promotion}}, en {{type_cours}}.

La prÃ©sente attestation est dÃ©livrÃ©e pour servir et valoir ce que de droit.

Fait Ã  LomÃ©, le {{date}}.`
    },
    {
      key: "attestation-fin-formation",
      title: "Attestation de fin de formation",
      category: "Attestation",
      audience: "student",
      status: "active",
      locked: true,
      content: `Nous soussignÃ©s {{centre_nom}}, attestons que {{etudiant_nom}}, matricule {{matricule}}, a suivi la formation {{formation}} au sein de notre centre.

Cette attestation est Ã©tablie sous rÃ©serve de la validation administrative et pÃ©dagogique du dossier.

Fait Ã  LomÃ©, le {{date}}.`
    },
    {
      key: "reglement-interieur",
      title: "RÃ¨glement intÃ©rieur",
      category: "RÃ¨glement",
      audience: "general",
      status: "active",
      locked: true,
      content: `Le prÃ©sent rÃ¨glement intÃ©rieur fixe les conditions de conduite, de ponctualitÃ©, de discipline et de respect des biens du centre.

Chaque Ã©tudiant s'engage Ã  respecter les horaires, le programme de formation, les consignes donnÃ©es par l'administration et les formateurs, ainsi que les modalitÃ©s de paiement convenues.

Tout manquement grave peut entraÃ®ner des mesures disciplinaires aprÃ¨s examen par l'administration.`
    },
    {
      key: "contrat-formation",
      title: "Contrat de formation",
      category: "Contrat",
      audience: "student",
      status: "active",
      locked: true,
      content: `Entre {{centre_nom}} et {{etudiant_nom}}, matricule {{matricule}}, il est convenu ce qui suit :

L'Ã©tudiant est inscrit Ã  la formation {{formation}}, promotion {{promotion}}, en {{type_cours}}.

La scolaritÃ© convenue est de {{scolarite}}. Le reste scolaritÃ© Ã  la date du document est de {{reste_scolarite}}.

L'Ã©tudiant s'engage Ã  respecter le rÃ¨glement intÃ©rieur, les horaires et les modalitÃ©s de paiement. Le centre s'engage Ã  assurer la formation selon le programme prÃ©vu.`
    },
    {
      key: "contrat-travail",
      title: "Contrat de travail",
      category: "Contrat",
      audience: "staff",
      status: "active",
      locked: true,
      content: `Entre {{centre_nom}} et {{beneficiaire_nom}}, occupant la fonction de {{fonction}}, il est Ã©tabli le prÃ©sent contrat de travail.

Le bÃ©nÃ©ficiaire s'engage Ã  exercer ses missions avec ponctualitÃ©, confidentialitÃ© et professionnalisme.

Les conditions particuliÃ¨res de rÃ©munÃ©ration, d'horaires et de responsabilitÃ©s sont dÃ©finies par l'administration du centre.

Fait Ã  LomÃ©, le {{date}}.`
    }
  ];
}

const seedState = () => ({
  center: {
    name: "CFP EREXIT",
    subtitle: "Centre de Formation Professionnelle",
    phone: "",
    email: "",
    address: "",
    logoData: "",
    stampData: ""
  },
  users: [],
  passwordResetRequests: [],
  onlineRegistrationRequests: [],
  studentAccounts: [],
  onlinePayments: [],
  notifications: [],
  loginHistory: [],
  paymentMotifs: defaultPaymentMotifs(),
  documentTemplates: defaultDocumentTemplates(),
  auditLog: [],
  requiredDocuments: {
    student: ["Photo", "PiÃ¨ce d'identitÃ©", "Contrat signÃ©"],
    trainer: ["Photo", "PiÃ¨ce d'identitÃ©", "Contrat signÃ©", "DiplÃ´me ou CV"],
    staff: ["Photo", "PiÃ¨ce d'identitÃ©", "Contrat signÃ©"]
  },
  students: [
    {
      id: 1,
      matricule: "ERX-2026-001",
      firstName: "Amina",
      lastName: "Traore",
      gender: "F",
      birthDate: "2003-04-18",
      phone: "+221 77 000 10 01",
      email: "amina@example.com",
      address: "Quartier Centre",
      emergencyName: "Mariam Traore",
      emergencyPhone: "+221 77 100 10 01",
      status: "actif"
    },
    {
      id: 2,
      matricule: "ERX-2026-002",
      firstName: "Moussa",
      lastName: "Diallo",
      gender: "M",
      birthDate: "2001-09-08",
      phone: "+221 77 000 10 02",
      email: "moussa@example.com",
      address: "Route Principale",
      emergencyName: "Oumar Diallo",
      emergencyPhone: "+221 77 100 10 02",
      status: "actif"
    },
    {
      id: 3,
      matricule: "ERX-2026-003",
      firstName: "Fatou",
      lastName: "Ndiaye",
      gender: "F",
      birthDate: "2002-02-22",
      phone: "+221 77 000 10 03",
      email: "fatou@example.com",
      address: "Cite Nouvelle",
      emergencyName: "Adama Ndiaye",
      emergencyPhone: "+221 77 100 10 03",
      status: "preinscrit"
    },
    {
      id: 4,
      matricule: "ERX-2026-004",
      firstName: "Jean",
      lastName: "Kouame",
      gender: "M",
      birthDate: "2000-12-14",
      phone: "+225 07 00 10 04",
      email: "jean@example.com",
      address: "Avenue de la Paix",
      emergencyName: "Claire Kouame",
      emergencyPhone: "+225 07 10 10 04",
      status: "actif"
    }
  ],
  courses: [
    {
      id: 1,
      code: "BUR",
      name: "Informatique bureautique",
      duration: "6 mois",
      description: "Word, Excel, PowerPoint, Internet et outils administratifs.",
      registrationFee: 15000,
      trainingFee: 120000,
      monthlyFee: 20000,
      status: "active"
    },
    {
      id: 2,
      code: "COMPTA",
      name: "ComptabilitÃ© pratique",
      duration: "8 mois",
      description: "Bases comptables, caisse, facturation et Ã©tats financiers.",
      registrationFee: 20000,
      trainingFee: 160000,
      monthlyFee: 25000,
      status: "active"
    },
    {
      id: 3,
      code: "INFO",
      name: "Maintenance informatique",
      duration: "9 mois",
      description: "MatÃ©riel, systÃ¨mes, rÃ©seaux et dÃ©pannage.",
      registrationFee: 20000,
      trainingFee: 180000,
      monthlyFee: 30000,
      status: "active"
    }
  ],
  groups: [
    {
      id: 1,
      name: "Bureautique 2026 - Groupe A",
      courseId: 1,
      year: "2026",
      sessionType: "jour",
      trainer: "Mme Coulibaly",
      capacity: 25,
      startDate: "2026-01-12",
      endDate: "2026-07-12",
      status: "active"
    },
    {
      id: 2,
      name: "ComptabilitÃ© 2026 - Groupe A",
      courseId: 2,
      year: "2026",
      sessionType: "soir",
      trainer: "M. Diop",
      capacity: 20,
      startDate: "2026-02-03",
      endDate: "2026-10-03",
      status: "active"
    },
    {
      id: 3,
      name: "Maintenance 2026 - Groupe A",
      courseId: 3,
      year: "2026",
      sessionType: "jour",
      trainer: "M. Kone",
      capacity: 18,
      startDate: "2026-03-01",
      endDate: "2026-12-01",
      status: "active"
    }
  ],
  trainers: [
    {
      id: 1,
      firstName: "Awa",
      lastName: "Coulibaly",
      phone: "+228 90 00 00 01",
      email: "awa.coulibaly@cftperexit.com",
      specialty: "Bureautique",
      modules: "Word, Excel, PowerPoint",
      status: "actif"
    },
    {
      id: 2,
      firstName: "Mamadou",
      lastName: "Diop",
      phone: "+228 90 00 00 02",
      email: "mamadou.diop@cftperexit.com",
      specialty: "Comptabilite pratique",
      modules: "Caisse, facturation, etats financiers",
      status: "actif"
    },
    {
      id: 3,
      firstName: "Koffi",
      lastName: "Kone",
      phone: "+228 90 00 00 03",
      email: "koffi.kone@cftperexit.com",
      specialty: "Maintenance informatique",
      modules: "Materiel, systemes, reseaux",
      status: "actif"
    }
  ],
  staffMembers: [
    {
      id: 1,
      firstName: "Abla",
      lastName: "Kossibokon",
      role: "Comptable",
      phone: "",
      email: "",
      salary: 0,
      status: "actif"
    }
  ],
  enrollments: [
    {
      id: 1,
      studentId: 1,
      courseId: 1,
      groupId: 1,
      date: "2026-01-13",
      totalAmount: 135000,
      discountAmount: 0,
      finalAmount: 135000,
      status: "validee"
    },
    {
      id: 2,
      studentId: 2,
      courseId: 2,
      groupId: 2,
      date: "2026-02-05",
      totalAmount: 180000,
      discountAmount: 10000,
      finalAmount: 170000,
      status: "validee"
    },
    {
      id: 3,
      studentId: 3,
      courseId: 1,
      groupId: 1,
      date: "2026-03-02",
      totalAmount: 135000,
      discountAmount: 0,
      finalAmount: 135000,
      status: "en attente"
    },
    {
      id: 4,
      studentId: 4,
      courseId: 3,
      groupId: 3,
      date: "2026-03-10",
      totalAmount: 200000,
      discountAmount: 0,
      finalAmount: 200000,
      status: "validee"
    }
  ],
  payments: [
    {
      id: 1,
      enrollmentId: 1,
      receiptNumber: "REC-2026-001",
      amount: 35000,
      method: "EspÃ¨ce",
      reason: "Frais d'inscription",
      date: "2026-01-13",
      receivedBy: "Comptable"
    },
    {
      id: 2,
      enrollmentId: 1,
      receiptNumber: "REC-2026-002",
      amount: 20000,
      method: "Mobile Money",
      reason: "MensualitÃ©",
      date: "2026-02-12",
      receivedBy: "Comptable"
    },
    {
      id: 3,
      enrollmentId: 2,
      receiptNumber: "REC-2026-003",
      amount: 50000,
      method: "EspÃ¨ce",
      reason: "Frais d'inscription",
      date: "2026-02-05",
      receivedBy: "Comptable"
    },
    {
      id: 4,
      enrollmentId: 4,
      receiptNumber: "REC-2026-004",
      amount: 60000,
      method: "Virement",
      reason: "Formation",
      date: "2026-03-11",
      receivedBy: "Comptable"
    }
  ],
  paymentAuditLog: [],
  cashEntries: [],
  staffPayments: [],
  attendanceSessions: [
    {
      id: 1,
      groupId: 1,
      date: "2026-04-02",
      topic: "Traitement de texte",
      records: [
        { studentId: 1, status: "present" },
        { studentId: 3, status: "absent" }
      ]
    }
  ],
  trainerAttendanceSessions: [],
  evaluations: [
    {
      id: 1,
      groupId: 1,
      trainerId: 1,
      title: "Evaluation Word",
      type: "pratique",
      date: "2026-04-15",
      maxScore: 20,
      grades: [
        { studentId: 1, score: 16, appreciation: "Bon travail" },
        { studentId: 3, score: 12, appreciation: "A renforcer" }
      ]
    }
  ]
});

let state = loadState();
let currentView = "dashboard";

const ids = {
  pageTitle: document.getElementById("pageTitle"),
  toast: document.getElementById("toast"),
  saveStatus: document.getElementById("saveStatus"),
  loginScreen: document.getElementById("loginScreen"),
  appShell: document.getElementById("appShell"),
  loginChoiceView: document.getElementById("loginChoiceView"),
  publicRegistration: document.getElementById("publicRegistration"),
  onlineRegistrationForm: document.getElementById("onlineRegistrationForm"),
  onlineCourse: document.getElementById("onlineCourse"),
  onlineRegistrationError: document.getElementById("onlineRegistrationError"),
  onlineRegistrationSuccess: document.getElementById("onlineRegistrationSuccess"),
  studentPortal: document.getElementById("studentPortal"),
  studentPortalLoginError: document.getElementById("studentPortalLoginError"),
  studentPortalName: document.getElementById("studentPortalName"),
  studentPortalMeta: document.getElementById("studentPortalMeta"),
  studentPortalSummary: document.getElementById("studentPortalSummary"),
  studentPortalInfo: document.getElementById("studentPortalInfo"),
  studentPortalEnrollments: document.getElementById("studentPortalEnrollments"),
  studentPortalPayments: document.getElementById("studentPortalPayments"),
  studentPortalGrades: document.getElementById("studentPortalGrades"),
  studentPortalAttendance: document.getElementById("studentPortalAttendance"),
  statsGrid: document.getElementById("statsGrid"),
  recentPaymentsTable: document.getElementById("recentPaymentsTable"),
  balancesTable: document.getElementById("balancesTable"),
  paymentAlertsTable: document.getElementById("paymentAlertsTable"),
  paymentAlertCount: document.getElementById("paymentAlertCount"),
  printPreviewModal: document.getElementById("printPreviewModal"),
  printPreviewBody: document.getElementById("printPreviewBody"),
  printPreviewTitle: document.getElementById("printPreviewTitle"),
  printPreviewPrint: document.getElementById("printPreviewPrint"),
  passwordChangeModal: document.getElementById("passwordChangeModal"),
  passwordChangeForm: document.getElementById("passwordChangeForm"),
  currentPasswordChange: document.getElementById("currentPasswordChange"),
  newPasswordChange: document.getElementById("newPasswordChange"),
  confirmPasswordChange: document.getElementById("confirmPasswordChange"),
  passwordChangeError: document.getElementById("passwordChangeError"),
  studentsTable: document.getElementById("studentsTable"),
  studentCount: document.getElementById("studentCount"),
  studentPhotoPreview: document.getElementById("studentPhotoPreview"),
  studentDocumentList: document.getElementById("studentDocumentList"),
  onlineRequestsTable: document.getElementById("onlineRequestsTable"),
  onlineRequestCount: document.getElementById("onlineRequestCount"),
  coursesTable: document.getElementById("coursesTable"),
  courseCount: document.getElementById("courseCount"),
  groupsTable: document.getElementById("groupsTable"),
  groupCount: document.getElementById("groupCount"),
  enrollmentsTable: document.getElementById("enrollmentsTable"),
  enrollmentCount: document.getElementById("enrollmentCount"),
  paymentsTable: document.getElementById("paymentsTable"),
  paymentCount: document.getElementById("paymentCount"),
  paymentBalance: document.getElementById("paymentBalance"),
  paymentAuditTable: document.getElementById("paymentAuditTable"),
  paymentAuditCount: document.getElementById("paymentAuditCount"),
  cashTable: document.getElementById("cashTable"),
  cashCount: document.getElementById("cashCount"),
  cashBalance: document.getElementById("cashBalance"),
  dashboardFinanceBars: document.getElementById("dashboardFinanceBars"),
  dashboardTuitionRing: document.getElementById("dashboardTuitionRing"),
  dashboardTuitionDetails: document.getElementById("dashboardTuitionDetails"),
  dashboardCourseBars: document.getElementById("dashboardCourseBars"),
  attendanceList: document.getElementById("attendanceList"),
  attendanceTable: document.getElementById("attendanceTable"),
  attendanceTotal: document.getElementById("attendanceTotal"),
  attendanceCount: document.getElementById("attendanceCount"),
  trainerAttendanceList: document.getElementById("trainerAttendanceList"),
  trainerAttendanceTable: document.getElementById("trainerAttendanceTable"),
  trainerAttendanceTotal: document.getElementById("trainerAttendanceTotal"),
  trainerAttendanceCount: document.getElementById("trainerAttendanceCount"),
  trainersTable: document.getElementById("trainersTable"),
  trainerCount: document.getElementById("trainerCount"),
  trainerPhotoPreview: document.getElementById("trainerPhotoPreview"),
  trainerDocumentList: document.getElementById("trainerDocumentList"),
  staffTable: document.getElementById("staffTable"),
  staffCount: document.getElementById("staffCount"),
  staffPhotoPreview: document.getElementById("staffPhotoPreview"),
  staffDocumentList: document.getElementById("staffDocumentList"),
  staffPaymentStaff: document.getElementById("staffPaymentStaff"),
  staffPaymentsTable: document.getElementById("staffPaymentsTable"),
  staffPaymentCount: document.getElementById("staffPaymentCount"),
  staffPaymentTotal: document.getElementById("staffPaymentTotal"),
  gradeEntryList: document.getElementById("gradeEntryList"),
  evaluationsTable: document.getElementById("evaluationsTable"),
  evaluationCount: document.getElementById("evaluationCount"),
  financialReport: document.getElementById("financialReport"),
  reportBalancesTable: document.getElementById("reportBalancesTable"),
  courseDistribution: document.getElementById("courseDistribution"),
  monthlyScheduleTable: document.getElementById("monthlyScheduleTable"),
  monthlyScheduleCount: document.getElementById("monthlyScheduleCount"),
  documentGeneratorTemplate: document.getElementById("documentGeneratorTemplate"),
  documentGeneratorStudent: document.getElementById("documentGeneratorStudent"),
  documentGeneratorBeneficiary: document.getElementById("documentGeneratorBeneficiary"),
  individualReportStudent: document.getElementById("individualReportStudent"),
  individualReportSummary: document.getElementById("individualReportSummary"),
  individualMotifTable: document.getElementById("individualMotifTable"),
  printIndividualReport: document.getElementById("printIndividualReport"),
  previewIndividualReportPdf: document.getElementById("previewIndividualReportPdf"),
  printStudentTranscript: document.getElementById("printStudentTranscript"),
  printArea: document.getElementById("printArea"),
  currentUserName: document.getElementById("currentUserName"),
  loginError: document.getElementById("loginError"),
  passwordResetBox: document.getElementById("passwordResetBox"),
  passwordResetEmail: document.getElementById("passwordResetEmail"),
  passwordResetMessage: document.getElementById("passwordResetMessage"),
  centerLogoPreview: document.getElementById("centerLogoPreview"),
  centerStampPreview: document.getElementById("centerStampPreview"),
  paymentMotifsSettings: document.getElementById("paymentMotifsSettings"),
  courseFeesSettings: document.getElementById("courseFeesSettings"),
  documentTemplateList: document.getElementById("documentTemplateList"),
  documentTemplateEditKey: document.getElementById("documentTemplateEditKey"),
  documentTemplateTitle: document.getElementById("documentTemplateTitle"),
  documentTemplateCategory: document.getElementById("documentTemplateCategory"),
  documentTemplateAudience: document.getElementById("documentTemplateAudience"),
  documentTemplateStatus: document.getElementById("documentTemplateStatus"),
  documentTemplateContent: document.getElementById("documentTemplateContent"),
  userAccessSettings: document.getElementById("userAccessSettings"),
  passwordResetRequests: document.getElementById("passwordResetRequests"),
  loginHistoryTable: document.getElementById("loginHistoryTable"),
  loginHistoryCount: document.getElementById("loginHistoryCount"),
  auditLogTable: document.getElementById("auditLogTable"),
  auditLogCount: document.getElementById("auditLogCount"),
  requiredDocumentsSettings: document.getElementById("requiredDocumentsSettings"),
  cleanupModeStatus: document.getElementById("cleanupModeStatus")
};

function loadState() {
  if (SERVER_MODE) {
    return seedState();
  }
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return seedState();
  }
  try {
    return { ...seedState(), ...JSON.parse(raw) };
  } catch {
    return seedState();
  }
}

function saveTimestamp() {
  return new Intl.DateTimeFormat("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).format(new Date());
}

function setSaveStatus(text, status = "") {
  if (!ids.saveStatus) return;
  ids.saveStatus.textContent = text;
  ids.saveStatus.className = `save-status ${status}`.trim();
}

function markSaved() {
  lastSavedAt = saveTimestamp();
  hasPendingChanges = false;
  setSaveStatus(`SauvegardÃ© ${lastSavedAt}`, "saved");
}

function cloneStateSnapshot(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function isCleanupModeActive() {
  return isAdmin() && Number(sessionStorage.getItem(CLEANUP_MODE_KEY) || 0) > Date.now();
}

function setCleanupModeStatus() {
  if (!ids.cleanupModeStatus) return;
  if (!isAdmin()) {
    ids.cleanupModeStatus.textContent = "RÃ©servÃ© Ã  l'administrateur";
    return;
  }
  if (!isCleanupModeActive()) {
    ids.cleanupModeStatus.textContent = "Nettoyage test dÃ©sactivÃ©";
    return;
  }
  const until = new Date(Number(sessionStorage.getItem(CLEANUP_MODE_KEY)));
  ids.cleanupModeStatus.textContent = `Nettoyage test actif jusqu'Ã  ${new Intl.DateTimeFormat("fr-FR", {
    hour: "2-digit",
    minute: "2-digit"
  }).format(until)}`;
}

function enableCleanupMode() {
  if (!isAdmin()) {
    showToast("AccÃ¨s rÃ©servÃ© Ã  l'administrateur");
    return;
  }
  const confirmation = prompt("Mode nettoyage test : tapez NETTOYAGE pour autoriser les suppressions liÃ©es pendant 30 minutes.");
  if (confirmation !== "NETTOYAGE") {
    showToast("Nettoyage test non activÃ©");
    return;
  }
  sessionStorage.setItem(CLEANUP_MODE_KEY, String(Date.now() + 30 * 60 * 1000));
  setCleanupModeStatus();
  updateStudentMatriculeLock();
  showToast("Nettoyage test actif pendant 30 minutes");
}

function updateStudentMatriculeLock() {
  const input = document.getElementById("studentMatricule");
  const form = document.getElementById("studentForm");
  if (!input || !form) return;
  const canEdit = !!form.dataset.editId && isCleanupModeActive();
  input.readOnly = !canEdit;
  input.title = canEdit
    ? "Nettoyage test actif : matricule modifiable"
    : "Matricule gÃ©nÃ©rÃ© automatiquement";
}

function applyServerState(nextState) {
  state = { ...seedState(), ...(nextState || {}) };
  serverRevision = String(state.updatedAt || "");
  lastSyncedState = cloneStateSnapshot(state);
}

function stopServerSync() {
  if (syncTimer) {
    window.clearInterval(syncTimer);
    syncTimer = null;
  }
}

function startServerSync() {
  if (!SERVER_MODE) return;
  stopServerSync();
  syncTimer = window.setInterval(() => {
    refreshServerState({ silent: true });
  }, 15000);
}

function isEditingField() {
  const active = document.activeElement;
  return !!active && ["INPUT", "SELECT", "TEXTAREA"].includes(active.tagName);
}

async function refreshServerState({ silent = false } = {}) {
  if (!SERVER_MODE || !currentUser || hasPendingChanges || isEditingField()) return;
  try {
    const latest = await apiRequest("/api/state");
    const latestRevision = String(latest.updatedAt || "");
    if (latestRevision && latestRevision !== serverRevision) {
      applyServerState(latest);
      render();
      markSaved();
      if (!silent) showToast("DerniÃ¨re version chargÃ©e");
    }
  } catch {
    if (!silent) showToast("Actualisation impossible");
  }
}

function handleSaveConflict(error) {
  if (error.status !== 409) return false;
  if (error.payload?.state) {
    applyServerState(error.payload.state);
    render();
  }
  hasPendingChanges = false;
  setSaveStatus("DonnÃ©es actualisÃ©es", "error");
  showToast("Une autre personne a modifiÃ© les donnÃ©es. DerniÃ¨re version rechargÃ©e, recommence l'action.");
  return true;
}

async function persistStateCore({ notify = false } = {}) {
  if (!SERVER_MODE) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    markSaved();
    refreshDashboardAfterDataChange();
    if (notify) showToast("DonnÃ©es sauvegardÃ©es");
    return true;
  }

  if (!currentUser) return false;
  const saveVersion = localChangeVersion;
  const snapshot = cloneStateSnapshot(state);
  const snapshotRevision = serverRevision;
  setSaveStatus("Sauvegarde en cours...", "saving");
  try {
    const result = await apiRequest("/api/state", {
      method: "PUT",
      body: JSON.stringify({
        ...snapshot,
        clientRevision: snapshotRevision
      })
    });
    if (result.state) {
      if (localChangeVersion === saveVersion) {
        applyServerState(result.state);
        render();
      } else {
        serverRevision = String(result.updatedAt || result.state.updatedAt || serverRevision);
        lastSyncedState = cloneStateSnapshot(result.state);
      }
    } else {
      serverRevision = String(result.updatedAt || state.updatedAt || serverRevision);
      if (localChangeVersion === saveVersion) {
        state.updatedAt = serverRevision || state.updatedAt;
      }
    }
    if (localChangeVersion === saveVersion) {
      markSaved();
      refreshDashboardAfterDataChange();
    } else {
      hasPendingChanges = true;
      setSaveStatus("Modifications en attente...", "saving");
    }
    if (notify) showToast("DonnÃ©es sauvegardÃ©es");
    return true;
  } catch (error) {
    if (handleSaveConflict(error)) return false;
    const message = error?.message || "Sauvegarde serveur impossible";
    setSaveStatus("Sauvegarde impossible", "error");
    showToast(message);
    return false;
  }
}

function persistStateNow(options = {}) {
  const task = saveChain.then(() => persistStateCore(options));
  saveChain = task.catch(() => false);
  return task;
}

function saveState(options = {}) {
  const { immediate = false, notify = false } = options;
  window.clearTimeout(saveTimer);
  localChangeVersion += 1;
  hasPendingChanges = true;
  if (immediate) {
    return persistStateNow({ notify });
  }
  setSaveStatus("Modifications en attente...", "saving");
  saveTimer = window.setTimeout(() => {
    persistStateNow({ notify });
  }, 250);
}

async function apiRequest(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      },
      ...options
    });
  } catch {
    throw new Error("Serveur inaccessible. Lancez l'application avec le serveur Node.js puis ouvrez http://localhost:3000.");
  }

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || "Erreur serveur");
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

async function loadServerState() {
  applyServerState(await apiRequest("/api/state"));
  markSaved();
}

async function loadPublicCenterIdentity() {
  if (!SERVER_MODE) return;
  try {
    const result = await apiRequest("/api/public-center");
    if (result.center) {
      state.center = { ...state.center, ...result.center };
      renderCenterIdentity();
    }
  } catch {
    renderCenterIdentity();
  }
}

function ensurePaymentMotifs() {
  const defaults = defaultPaymentMotifs();
  if (!Array.isArray(state.paymentMotifs)) {
    state.paymentMotifs = defaults;
    return;
  }

  defaults.forEach(defaultMotif => {
    const existing = state.paymentMotifs.find(motif => motif.key === defaultMotif.key);
    if (!existing) {
      if (defaultMotif.key === "scolarite") {
        state.paymentMotifs.unshift(defaultMotif);
      } else {
        state.paymentMotifs.push(defaultMotif);
      }
      return;
    }
    existing.label ||= defaultMotif.label;
    existing.amount = Number(existing.amount || 0);
  });
}

function ensureDocumentTemplates() {
  const defaults = defaultDocumentTemplates();
  if (!Array.isArray(state.documentTemplates)) {
    state.documentTemplates = defaults;
    return;
  }

  defaults.forEach(defaultTemplate => {
    const existing = state.documentTemplates.find(template => template.key === defaultTemplate.key);
    if (!existing) {
      state.documentTemplates.push(defaultTemplate);
      return;
    }
    existing.title ||= defaultTemplate.title;
    existing.category ||= defaultTemplate.category;
    existing.audience ||= defaultTemplate.audience;
    existing.status ||= "active";
    existing.locked = existing.locked !== false;
    existing.content ||= defaultTemplate.content;
  });
}

function ensureCollections() {
  state.trainers = Array.isArray(state.trainers) ? state.trainers : [];
  state.evaluations = Array.isArray(state.evaluations) ? state.evaluations : [];
  state.cashEntries = Array.isArray(state.cashEntries) ? state.cashEntries : [];
  state.paymentAuditLog = Array.isArray(state.paymentAuditLog) ? state.paymentAuditLog : [];
  state.attendanceSessions = Array.isArray(state.attendanceSessions) ? state.attendanceSessions : [];
  state.trainerAttendanceSessions = Array.isArray(state.trainerAttendanceSessions) ? state.trainerAttendanceSessions : [];
  state.users = Array.isArray(state.users) ? state.users : [];
  state.passwordResetRequests = Array.isArray(state.passwordResetRequests) ? state.passwordResetRequests : [];
  state.onlineRegistrationRequests = Array.isArray(state.onlineRegistrationRequests) ? state.onlineRegistrationRequests : [];
  state.studentAccounts = Array.isArray(state.studentAccounts) ? state.studentAccounts : [];
  state.onlinePayments = Array.isArray(state.onlinePayments) ? state.onlinePayments : [];
  state.notifications = Array.isArray(state.notifications) ? state.notifications : [];
  state.loginHistory = Array.isArray(state.loginHistory) ? state.loginHistory : [];
  state.auditLog = Array.isArray(state.auditLog) ? state.auditLog : [];
  state.requiredDocuments = normalizeRequiredDocuments(state.requiredDocuments);
  state.staffMembers = Array.isArray(state.staffMembers) ? state.staffMembers : [];
  state.staffPayments = Array.isArray(state.staffPayments) ? state.staffPayments : [];
  state.groups = Array.isArray(state.groups) ? state.groups : [];
  ensureDocumentTemplates();
  state.users.forEach(user => {
    user.email = migrateEmailDomain(user.email);
  });
  state.trainers.forEach(trainer => {
    trainer.email = migrateEmailDomain(trainer.email);
  });
  [...state.students, ...state.trainers, ...state.staffMembers].forEach(person => {
    if (!person) return;
    person.photoData ||= "";
    person.documents = Array.isArray(person.documents) ? person.documents : [];
  });
  state.groups.forEach(group => {
    group.sessionType ||= "jour";
  });
}

function normalizeRequiredDocuments(value = {}) {
  const defaults = seedState().requiredDocuments;
  return {
    student: Array.isArray(value.student) && value.student.length ? value.student : defaults.student,
    trainer: Array.isArray(value.trainer) && value.trainer.length ? value.trainer : defaults.trainer,
    staff: Array.isArray(value.staff) && value.staff.length ? value.staff : defaults.staff
  };
}

function migrateEmailDomain(email) {
  return String(email || "").replace(/@erexit\.local$/i, "@cftperexit.com");
}

function isAdmin() {
  if (SERVER_MODE) return roleCode(currentUser?.role) === "administrateur";
  return roleCode(document.getElementById("roleSelect")?.value) === "administrateur";
}

function defaultPermissionsForRole(role) {
  const code = roleCode(role);
  if (code === "administrateur" || code === "admin") return [...ACCESS_VIEWS];
  if (code === "directeur") {
    return ["dashboard", "onlineRequests", "students", "courses", "groups", "enrollments", "payments", "cash", "attendance", "trainers", "staff", "grades", "reports"];
  }
  if (code === "secretaire") {
    return ["dashboard", "onlineRequests", "students", "courses", "groups", "enrollments", "attendance", "trainers"];
  }
  if (code === "comptable") {
    return ["dashboard", "students", "courses", "groups", "enrollments", "payments", "cash", "staff", "reports"];
  }
  if (code === "formateur") {
    return ["dashboard", "students", "courses", "groups", "attendance", "grades"];
  }
  if (code === "accueil") {
    return ["dashboard", "onlineRequests", "students", "courses", "groups", "enrollments"];
  }
  if (code === "etudiant") {
    return [];
  }
  return ["dashboard"];
}

function permissionsForUser(user = currentUser) {
  if (!SERVER_MODE) return [...ACCESS_VIEWS];
  if (!user) return [];
  if (roleCode(user.role) === "administrateur" || roleCode(user.role) === "admin") return [...ACCESS_VIEWS];
  const permissions = Array.isArray(user.permissions) && user.permissions.length
    ? user.permissions
    : defaultPermissionsForRole(user.role);
  return permissions.filter(view => MANAGED_ACCESS_VIEWS.includes(view));
}

function canAccessView(view) {
  if (!SERVER_MODE) return true;
  if (view === "settings") return isAdmin();
  return isAdmin() || permissionsForUser().includes(view);
}

function canControlPayments() {
  return isAdmin();
}

function currentOperatorName() {
  return currentUser?.name || document.getElementById("roleSelect")?.value || "Administrateur";
}

function firstAllowedView() {
  return ACCESS_VIEWS.find(view => canAccessView(view)) || "dashboard";
}

function getPaymentMotif(key) {
  ensurePaymentMotifs();
  return state.paymentMotifs.find(motif => motif.key === key);
}

function yearFromDate(value = today()) {
  return String(value || today()).slice(0, 4);
}

function randomFiveDigits() {
  return String(Math.floor(Math.random() * 100000)).padStart(5, "0");
}

function generateMatricule(year = yearFromDate()) {
  let matricule = "";
  do {
    matricule = `ERX-${year}-${randomFiveDigits()}`;
  } while (state.students.some(student => student.matricule === matricule));
  return matricule;
}

function nextId(collection) {
  return collection.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1;
}

function formatMoney(value) {
  return `${new Intl.NumberFormat("fr-FR").format(Number(value) || 0)} FCFA`;
}

function amountToWords(value) {
  const units = ["zero", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"];
  const tens = ["", "", "vingt", "trente", "quarante", "cinquante", "soixante"];
  const underHundred = number => {
    if (number < 17) return units[number];
    if (number < 20) return `dix-${units[number - 10]}`;
    if (number < 70) {
      const ten = Math.floor(number / 10);
      const unit = number % 10;
      return unit === 0 ? tens[ten] : `${tens[ten]}-${unit === 1 ? "et-" : ""}${units[unit]}`;
    }
    if (number < 80) return `soixante-${underHundred(number - 60)}`;
    if (number < 100) return number === 80 ? "quatre-vingts" : `quatre-vingt-${underHundred(number - 80)}`;
    return "";
  };
  const underThousand = number => {
    if (number < 100) return underHundred(number);
    const hundred = Math.floor(number / 100);
    const rest = number % 100;
    const prefix = hundred === 1 ? "cent" : `${units[hundred]} cent`;
    return rest ? `${prefix} ${underHundred(rest)}` : prefix;
  };
  const integer = Math.max(0, Math.floor(Number(value) || 0));
  if (integer === 0) return "zero franc CFA";
  const groups = [
    { value: 1000000000, label: "milliard" },
    { value: 1000000, label: "million" },
    { value: 1000, label: "mille" }
  ];
  let remaining = integer;
  const parts = [];
  groups.forEach(group => {
    const count = Math.floor(remaining / group.value);
    if (!count) return;
    parts.push(group.label === "mille" && count === 1 ? "mille" : `${underThousand(count)} ${group.label}${count > 1 && group.label !== "mille" ? "s" : ""}`);
    remaining %= group.value;
  });
  if (remaining) parts.push(underThousand(remaining));
  return `${parts.join(" ")} franc${integer > 1 ? "s" : ""} CFA`;
}

function formatNumber(value) {
  return new Intl.NumberFormat("fr-FR").format(Number(value) || 0);
}

function statValueHtml(item) {
  if (item.type === "money") {
    return `
      <strong class="stat-value money">
        <span class="money-number">${formatNumber(item.value)}</span>
        <span class="money-currency">FCFA</span>
      </strong>
    `;
  }
  return `<strong class="stat-value count">${formatNumber(item.value)}</strong>`;
}

function formatCompactMoney(value) {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1000000) return `${formatNumber(Math.round(amount / 100000) / 10)} M`;
  if (abs >= 1000) return `${formatNumber(Math.round(amount / 1000))} k`;
  return formatNumber(amount);
}

function formatPrintAmount(value) {
  return new Intl.NumberFormat("fr-FR").format(Number(value) || 0);
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Lecture du fichier impossible"));
    reader.readAsDataURL(file);
  });
}

function formatFileSize(bytes = 0) {
  const size = Number(bytes) || 0;
  if (size >= 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} Mo`;
  if (size >= 1024) return `${Math.round(size / 1024)} Ko`;
  return `${size} o`;
}

function cloneDocuments(documents = []) {
  return JSON.parse(JSON.stringify(Array.isArray(documents) ? documents : []));
}

function resetPersonFileDraft(kind, person = {}) {
  personFileDrafts[kind] = {
    photoData: person.photoData || "",
    documents: cloneDocuments(person.documents)
  };
  renderPersonFileDraft(kind);
}

function personFilesPayload(kind) {
  return {
    photoData: personFileDrafts[kind]?.photoData || "",
    documents: cloneDocuments(personFileDrafts[kind]?.documents || [])
  };
}

function personPhotoHtml(person, label = "Photo") {
  const src = normalizeLogoData(person?.photoData || "");
  return src
    ? `<img class="person-avatar" src="${escapeHtml(src)}" alt="${escapeHtml(label)}">`
    : `<span class="person-avatar placeholder">${escapeHtml(label.slice(0, 2).toUpperCase())}</span>`;
}

function personDocumentSummary(person) {
  const count = Array.isArray(person?.documents) ? person.documents.length : 0;
  return count ? `${count} fichier(s)` : "Aucun fichier";
}

function requiredDocumentsFor(kind) {
  return normalizeRequiredDocuments(state.requiredDocuments)[kind] || [];
}

function documentLabelMatchesRequirement(documentItem, requiredLabel) {
  const required = normalizeSearchText(requiredLabel);
  const documentLabel = normalizeSearchText([
    documentItem?.type,
    documentItem?.name,
    documentItem?.originalName
  ].filter(Boolean).join(" "));
  if (!required) return true;
  if (!documentLabel) return false;
  if (documentLabel.includes(required) || required.includes(documentLabel)) return true;

  const aliases = [
    ["piece d'identite", ["cni", "carte identite", "carte d'identite", "identite", "passeport"]],
    ["contrat signe", ["contrat", "contrat de formation", "contrat travail"]],
    ["diplome ou cv", ["diplome", "cv", "curriculum"]],
    ["photo", ["photo", "portrait"]]
  ];
  return aliases.some(([canonical, words]) => (
    required.includes(canonical) && words.some(word => documentLabel.includes(word))
  ));
}

function personDocumentCompletion(person, kind) {
  const required = requiredDocumentsFor(kind);
  if (!required.length) return { missing: [], completed: true };
  const docs = Array.isArray(person?.documents) ? person.documents : [];
  const hasPhotoRequirement = required.some(label => normalizeSearchText(label).includes("photo"));
  const missing = required.filter(label => {
    const normalized = normalizeSearchText(label);
    if (normalized.includes("photo") && person?.photoData) return false;
    return !docs.some(documentItem => documentLabelMatchesRequirement(documentItem, label));
  });
  if (hasPhotoRequirement && !person?.photoData && !missing.some(label => normalizeSearchText(label).includes("photo"))) {
    missing.push("Photo");
  }
  return { missing, completed: missing.length === 0 };
}

function missingDocumentsText(completion) {
  const missing = completion?.missing || [];
  return missing.length ? `Manquant : ${missing.join(", ")}` : "Tous les documents obligatoires sont prÃ©sents";
}

function documentCompletionBadge(person, kind) {
  const completion = personDocumentCompletion(person, kind);
  return completion.completed
    ? `<span class="status active">Dossier complet</span>`
    : `<span class="status inactive">Dossier incomplet</span><div class="missing-documents">${escapeHtml(missingDocumentsText(completion))}</div>`;
}

function renderPersonFileDraft(kind) {
  const draft = personFileDrafts[kind];
  const preview = ids[`${kind}PhotoPreview`];
  const list = ids[`${kind}DocumentList`];
  if (preview) {
    const src = normalizeLogoData(draft.photoData);
    preview.innerHTML = src ? `<img src="${escapeHtml(src)}" alt="">` : "Photo";
  }
  if (list) {
    list.innerHTML = draft.documents.map((documentItem, index) => `
      <article class="attached-document-item">
        <div>
          <strong>${escapeHtml(documentItem.type || documentItem.name || "Document")}</strong>
          <span>${escapeHtml(documentItem.originalName || documentItem.name || "Fichier")} Â· ${formatFileSize(documentItem.size)}</span>
        </div>
        <div class="row-actions">
          <a class="chip-button" href="${escapeHtml(documentItem.url || documentItem.data || "#")}" download="${escapeHtml(documentItem.name || "document")}" target="_blank" rel="noopener">Ouvrir</a>
          <button class="chip-button" type="button" data-action="rename-person-document" data-kind="${escapeHtml(kind)}" data-index="${index}">Renommer</button>
          <button class="chip-button danger" type="button" data-action="delete-person-document" data-kind="${escapeHtml(kind)}" data-index="${index}">Retirer</button>
        </div>
      </article>
    `).join("") || `<p class="muted">Aucun document ajoutÃ©.</p>`;
  }
}

async function importPersonPhoto(kind) {
  const input = document.getElementById(`${kind}PhotoInput`);
  const file = input?.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Choisissez une image pour la photo");
    input.value = "";
    return;
  }
  try {
    const dataUrl = await imageToPngDataUrl(file, 420);
    personFileDrafts[kind].photoData = await uploadDataUrlToServer({
      dataUrl,
      name: file.name || `${kind}-photo.png`,
      folder: `${kind}/photos`
    });
    renderPersonFileDraft(kind);
  } catch {
    showToast("Photo illisible");
  } finally {
    input.value = "";
  }
}

function removePersonPhoto(kind) {
  personFileDrafts[kind].photoData = "";
  renderPersonFileDraft(kind);
}

async function uploadDataUrlToServer({ dataUrl, name, folder }) {
  if (!SERVER_MODE) return dataUrl;
  const result = await apiRequest("/api/upload", {
    method: "POST",
    body: JSON.stringify({ data: dataUrl, name, folder })
  });
  return result.url || dataUrl;
}

async function addPersonDocument(kind) {
  const fileInput = document.getElementById(`${kind}DocumentFile`);
  const typeInput = document.getElementById(`${kind}DocumentType`);
  const file = fileInput?.files?.[0];
  const documentLabel = typeInput?.value.trim() || "";
  if (!documentLabel) {
    showToast("Nommez le document avant de l'ajouter");
    typeInput?.focus();
    return;
  }
  if (!file) {
    showToast("Choisissez un fichier");
    return;
  }
  const maxSize = 4 * 1024 * 1024;
  if (file.size > maxSize) {
    showToast("Fichier trop lourd : maximum 4 Mo");
    return;
  }
  try {
    const dataUrl = await readFileAsDataUrl(file);
    const storedUrl = await uploadDataUrlToServer({
      dataUrl,
      name: file.name,
      folder: `${kind}/documents`
    });
    personFileDrafts[kind].documents.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type: documentLabel,
      name: file.name,
      originalName: file.name,
      size: file.size,
      mime: file.type || "application/octet-stream",
      ...(SERVER_MODE ? { url: storedUrl } : { data: storedUrl }),
      addedAt: new Date().toISOString(),
      addedBy: currentOperatorName()
    });
    if (typeInput) typeInput.value = "";
    if (fileInput) fileInput.value = "";
    renderPersonFileDraft(kind);
    showToast("Document ajoutÃ© au dossier");
  } catch {
    showToast("Ajout du fichier impossible");
  }
}

function deletePersonDocument(kind, index) {
  const draft = personFileDrafts[kind];
  if (!draft) return;
  draft.documents.splice(Number(index), 1);
  renderPersonFileDraft(kind);
}

function renamePersonDocument(kind, index) {
  const draft = personFileDrafts[kind];
  const documentItem = draft?.documents?.[Number(index)];
  if (!documentItem) return;
  const nextName = prompt("Nom du document", documentItem.type || documentItem.name || "");
  if (!nextName || !nextName.trim()) {
    showToast("Nom du document obligatoire");
    return;
  }
  documentItem.type = nextName.trim();
  renderPersonFileDraft(kind);
}

function formatDate(value) {
  if (!value) return "-";
  const text = String(value).trim();
  const date = text.includes("T") || text.includes(" ")
    ? new Date(text)
    : new Date(`${text}T00:00:00`);
  if (Number.isNaN(date.getTime())) return text || "-";
  return new Intl.DateTimeFormat("fr-FR").format(date);
}

function daysSince(value) {
  if (!value) return Infinity;
  const date = new Date(`${String(value).slice(0, 10)}T00:00:00`);
  if (Number.isNaN(date.getTime())) return Infinity;
  return Math.floor((new Date(`${today()}T00:00:00`) - date) / DAY_MS);
}

function formatDateTime(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return String(value || "-");
  return new Intl.DateTimeFormat("fr-FR", {
    dateStyle: "short",
    timeStyle: "medium"
  }).format(date);
}

function statusClass(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, "-");
}

function documentTitleFromPrintArea() {
  const heading = ids.printArea?.querySelector(".receipt-type, h1, h2, .print-header h1");
  return heading?.textContent?.trim() || "Document";
}

function showPrintPreview(title = documentTitleFromPrintArea()) {
  if (!ids.printPreviewModal || !ids.printPreviewBody || !ids.printArea) {
    window.print();
    return;
  }
  ids.printPreviewTitle.textContent = title || "Document";
  ids.printPreviewBody.innerHTML = ids.printArea.innerHTML;
  ids.printPreviewModal.hidden = false;
  document.body.classList.add("print-preview-open");
}

function closePrintPreview() {
  if (!ids.printPreviewModal || !ids.printPreviewBody) return;
  ids.printPreviewModal.hidden = true;
  ids.printPreviewBody.innerHTML = "";
  document.body.classList.remove("print-preview-open");
}

function printPreviewDocument() {
  window.print();
}

function fullName(student) {
  if (!student) return "Ã‰tudiant supprimÃ©";
  return `${String(student.lastName || "").toUpperCase()} ${student.firstName || ""}`.trim();
}

function findById(collection, id) {
  return collection.find(item => Number(item.id) === Number(id));
}

function getStudent(id) {
  return findById(state.students, id);
}

function getCourse(id) {
  return findById(state.courses, id);
}

function getGroup(id) {
  return findById(state.groups, id);
}

function getEnrollment(id) {
  return findById(state.enrollments, id);
}

function getTrainer(id) {
  return findById(state.trainers, id);
}

function getStaffMember(id) {
  return findById(state.staffMembers, id);
}

function getEvaluation(id) {
  return findById(state.evaluations, id);
}

function groupSessionLabel(group) {
  const type = String(group?.sessionType || "jour");
  if (type === "soir") return "Cours du soir";
  if (type === "ligne") return "Cours en ligne";
  return "Cours du jour";
}

function normalizeSearchText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function trainerName(trainer) {
  if (!trainer) return "Formateur non precise";
  return `${String(trainer.lastName || "").toUpperCase()} ${trainer.firstName || ""}`.trim();
}

function staffName(member) {
  if (!member) return "Personnel supprimÃ©";
  return `${String(member.lastName || "").toUpperCase()} ${member.firstName || ""}`.trim();
}

function payrollBeneficiaryValue(type, id) {
  return `${type}:${id}`;
}

function parsePayrollBeneficiary(value) {
  const [type, id] = String(value || "").split(":");
  return {
    type: type === "trainer" ? "trainer" : "staff",
    id: Number(id || 0)
  };
}

function payrollBeneficiary(payment) {
  const type = payment.payeeType === "trainer" ? "trainer" : "staff";
  const id = Number(payment.payeeId || payment.staffId || 0);
  const person = type === "trainer" ? getTrainer(id) : getStaffMember(id);
  return {
    type,
    id,
    person,
    name: type === "trainer" ? trainerName(person) : staffName(person),
    role: type === "trainer" ? "Formateur" : (person?.role || "Personnel"),
    phone: person?.phone || "",
    email: person?.email || "",
    baseSalary: type === "trainer" ? Number(person?.salary || 0) : Number(person?.salary || 0)
  };
}

function courseCost(course) {
  if (!course) return 0;
  return Number(course.trainingFee || 0);
}

function paymentsForEnrollment(enrollmentId) {
  return state.payments.filter(payment => Number(payment.enrollmentId) === Number(enrollmentId));
}

function isTuitionMotifKey(key) {
  return TUITION_MOTIF_KEYS.includes(String(key || "").toLowerCase());
}

function isMakeupMotifKey(key) {
  return String(key || "").toLowerCase() === MAKEUP_MOTIF_KEY;
}

function isTuitionPayment(payment) {
  const key = String(payment.reasonKey || "").toLowerCase();
  if (isTuitionMotifKey(key)) return true;
  const reason = normalizeSearchText(payment.reason);
  return ["scolarite", "frais de scolarite", "formation", "frais formation", "frais de formation", "mensualite"]
    .some(label => reason === label);
}

function tuitionPaymentsForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).filter(isTuitionPayment);
}

function annexPaymentsForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).filter(payment => !isTuitionPayment(payment));
}

function lastPaymentDateForEnrollment(enrollmentId, predicate = () => true) {
  return paymentsForEnrollment(enrollmentId)
    .filter(predicate)
    .map(payment => payment.date)
    .filter(Boolean)
    .sort()
    .at(-1) || "";
}

function paidAmount(enrollmentId) {
  return tuitionPaymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function paidAmountExcluding(enrollmentId, excludedPaymentId) {
  return tuitionPaymentsForEnrollment(enrollmentId)
    .filter(payment => Number(payment.id) !== Number(excludedPaymentId))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function annexPaidAmount(enrollmentId) {
  return annexPaymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function totalPaidAmountForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function isDesistedEnrollment(enrollment) {
  if (!enrollment) return false;
  const student = getStudent(enrollment.studentId);
  return String(enrollment.status || "").toLowerCase() === "desiste" ||
    String(student?.status || "").toLowerCase() === "desiste";
}

function isInactiveTuitionEnrollment(enrollment) {
  return ["annulee", "desiste"].includes(String(enrollment?.status || "").toLowerCase()) || isDesistedEnrollment(enrollment);
}

function isAbandonedEnrollment(enrollment) {
  if (!enrollment) return false;
  const student = getStudent(enrollment.studentId);
  return String(enrollment.status || "").toLowerCase() === "abandon" ||
    String(student?.status || "").toLowerCase() === "abandon";
}

function suppressPaymentTrackingForEnrollment(enrollment) {
  return ["annulee", "terminee", "desiste"].includes(String(enrollment?.status || "").toLowerCase()) ||
    isDesistedEnrollment(enrollment) ||
    isAbandonedEnrollment(enrollment);
}

function tuitionExpectedForEnrollment(enrollment) {
  return suppressPaymentTrackingForEnrollment(enrollment) ? 0 : Number(enrollment?.finalAmount || 0);
}

function balanceForEnrollment(enrollment) {
  if (!enrollment) return 0;
  return Math.max(0, tuitionExpectedForEnrollment(enrollment) - paidAmount(enrollment.id));
}

function balanceForEnrollmentExcluding(enrollment, excludedPaymentId) {
  if (!enrollment) return 0;
  return Math.max(0, tuitionExpectedForEnrollment(enrollment) - paidAmountExcluding(enrollment.id, excludedPaymentId));
}

function paymentsTotal() {
  return state.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function tuitionPaymentsTotal() {
  return state.payments.filter(isTuitionPayment).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function annexPaymentsTotal() {
  return state.payments.filter(payment => !isTuitionPayment(payment)).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function cashIncomeTotal() {
  return state.cashEntries
    .filter(entry => entry.type === "income")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function cashExpenseTotal() {
  const cashExpenses = state.cashEntries
    .filter(entry => entry.type === "expense")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  return cashExpenses + staffPaymentsTotal();
}

function staffPaymentsTotal() {
  return state.staffPayments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function netCashTotal() {
  return paymentsTotal() + cashIncomeTotal() - cashExpenseTotal();
}

function cashLedgerEntries() {
  const studentPaymentEntries = state.payments.map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : null;
    return {
      id: `payment-${payment.id}`,
      source: "payment",
      date: payment.date,
      type: "income",
      category: isTuitionPayment(payment) ? "Paiement scolaritÃ©" : "Paiement frais annexes",
      amount: Number(payment.amount || 0),
      method: payment.method || "-",
      description: `${payment.receiptNumber || "-"} - ${fullName(student)} - ${payment.reason || "Paiement Ã©tudiant"}`,
      recordedBy: payment.receivedBy || payment.recordedBy || "",
      locked: true
    };
  });

  const manualEntries = state.cashEntries.map(entry => ({
    id: `cash-${entry.id}`,
    source: "cash",
    rawId: entry.id,
    date: entry.date,
    type: entry.type === "expense" ? "expense" : "income",
    category: entry.category || "-",
    amount: Number(entry.amount || 0),
    method: entry.method || "-",
    description: entry.description || "",
    recordedBy: entry.recordedBy || "",
    closedAt: entry.closedAt || "",
    closedBy: entry.closedBy || "",
    locked: !!entry.closedAt
  }));

  const payrollEntries = state.staffPayments.map(payment => {
    const beneficiary = payrollBeneficiary(payment);
    return {
      id: `payroll-${payment.id}`,
      source: "payroll",
      date: payment.date,
      type: "expense",
      category: payment.reason || "Paiement personnel",
      amount: Number(payment.amount || 0),
      method: payment.method || "-",
      description: `${beneficiary.name} - ${beneficiary.role}${payment.period ? ` - ${payment.period}` : ""}${payment.note ? ` - ${payment.note}` : ""}`,
      recordedBy: payment.recordedBy || "",
      locked: true
    };
  });

  return [...studentPaymentEntries, ...manualEntries, ...payrollEntries]
    .sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")) || String(b.id).localeCompare(String(a.id)));
}

function studentsForGroup(groupId) {
  const seen = new Set();
  return state.enrollments
    .filter(enrollment => Number(enrollment.groupId) === Number(groupId) && !isInactiveTuitionEnrollment(enrollment))
    .map(enrollment => getStudent(enrollment.studentId))
    .filter(student => {
      if (!student || seen.has(Number(student.id))) return false;
      seen.add(Number(student.id));
      return true;
    });
}

function formatAverage(evaluation) {
  const grades = Array.isArray(evaluation.grades) ? evaluation.grades : [];
  const scored = grades.filter(grade => grade.score !== "" && grade.score !== null && !Number.isNaN(Number(grade.score)));
  if (!scored.length) return "-";
  const total = scored.reduce((sum, grade) => sum + Number(grade.score || 0), 0);
  const average = total / scored.length;
  return `${average.toFixed(2)} / ${Number(evaluation.maxScore || 20)}`;
}

function passingScoreFor(maxScore = 20) {
  return Number(maxScore || 20) * PASSING_SCORE_20 / 20;
}

function gradeNeedsMakeup(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return false;
  return Number(score) < passingScoreFor(maxScore);
}

function gradeStatusLabel(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return "Non notÃ©";
  return gradeNeedsMakeup(score, maxScore) ? "Non validÃ©" : "ValidÃ©";
}

function evaluationMakeupStats(evaluation) {
  const maxScore = Number(evaluation?.maxScore || 20);
  const count = (evaluation?.grades || []).filter(grade => gradeNeedsMakeup(grade.score, maxScore)).length;
  return {
    count,
    amount: count * MAKEUP_FEE
  };
}

function centerContactLine() {
  const center = state.center || {};
  return [center.address, center.phone, center.email].filter(Boolean).join(" - ");
}

function printHeaderHtml(title) {
  const center = state.center || {};
  const logoSrc = normalizeLogoData(center.logoData);
  const stampSrc = normalizeLogoData(center.stampData);
  return `
    <div class="print-header">
      ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="Logo ${escapeHtml(center.name || "CFP EREXIT")}">` : ""}
      <div>
        <h1>${escapeHtml(center.name || "CFP EREXIT")}</h1>
        <p>${escapeHtml(center.subtitle || "Centre de Formation Professionnelle")}</p>
        <p>${escapeHtml(centerContactLine())}</p>
      </div>
    </div>
    <hr>
    <h2>${escapeHtml(title)}</h2>
  `;
}

function normalizeLogoData(value) {
  const logo = String(value || "").trim();
  if (logo.startsWith("/") || logo.startsWith("http://") || logo.startsWith("https://") || logo.startsWith("blob:")) {
    return logo;
  }
  const match = logo.match(/^(data:image\/[a-zA-Z0-9.+-]+;base64,)(.+)$/);
  if (!match) return logo.startsWith("data:image/svg+xml") ? logo : "";

  let payload = match[2].replace(/\s+/g, "").replace(/=+$/g, "");
  while (payload.length % 4 === 1) {
    payload = payload.slice(0, -1);
  }
  const padding = ["", "", "==", "="][payload.length % 4];
  payload += padding;
  return `${match[1]}${payload}`;
}

function imageToPngDataUrl(file, maxSize = 512) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      const context = canvas.getContext("2d");
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/png"));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Image illisible"));
    };
    image.src = url;
  });
}

function svgToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || "");
      if (!text.includes("<svg")) {
        reject(new Error("SVG invalide"));
        return;
      }
      resolve(`data:image/svg+xml;charset=utf-8,${encodeURIComponent(text)}`);
    };
    reader.onerror = () => reject(new Error("Lecture impossible"));
    reader.readAsText(file);
  });
}

function showToast(message) {
  ids.toast.textContent = message;
  ids.toast.classList.add("show");
  window.setTimeout(() => ids.toast.classList.remove("show"), 2200);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setView(view) {
  if (!canAccessView(view)) {
    showToast("AccÃ¨s non autorisÃ©");
    view = firstAllowedView();
  }
  currentView = view;
  applyViewState();
  render();
}

function applyViewState() {
  document.querySelectorAll(".view").forEach(section => {
    section.classList.toggle("active", section.dataset.view === currentView);
  });
  document.querySelectorAll("[data-view-target]").forEach(button => {
    const target = button.dataset.viewTarget;
    const allowed = canAccessView(target);
    button.hidden = !allowed;
    button.disabled = !allowed;
    button.classList.toggle("active", target === currentView);
  });
  ids.pageTitle.textContent = VIEW_LABELS[currentView] || "Tableau de bord";
}

function render() {
  ensureCollections();
  ensurePaymentMotifs();
  if (!canAccessView(currentView)) {
    currentView = firstAllowedView();
  }
  applyViewState();
  [
    ["identitÃ©", renderCenterIdentity],
    ["session", renderSession],
    ["sÃ©lecteurs", syncSelects],
    ["tableau de bord", renderDashboard],
    ["demandes en ligne", renderOnlineRequests],
    ["Ã©tudiants", renderStudents],
    ["formations", renderCourses],
    ["promotions", renderGroups],
    ["inscriptions", renderEnrollments],
    ["paiements", renderPayments],
    ["caisse", renderCash],
    ["prÃ©sences", renderAttendance],
    ["prÃ©sences professeurs", renderTrainerAttendance],
    ["formateurs", renderTrainers],
    ["personnel", renderStaff],
    ["rapports", renderReports],
    ["notes", renderEvaluations],
    ["paramÃ¨tres", renderSettings]
  ].forEach(([label, step]) => {
    try {
      step();
    } catch (error) {
      console.error(`Erreur rendu ${label} :`, error);
    }
  });
  applyTablePagination();
}

function renderSession() {
  const roleSelect = document.getElementById("roleSelect");
  const logoutButton = document.getElementById("logoutButton");

  if (!SERVER_MODE) {
    ids.currentUserName.textContent = "Mode local";
    logoutButton.hidden = true;
    roleSelect.disabled = false;
    return;
  }

  ids.currentUserName.textContent = currentUser
    ? `${currentUser.name} - ${currentUser.role}`
    : "Non connectÃ©";
  logoutButton.hidden = !currentUser;
  roleSelect.disabled = true;
  if (currentUser?.role) {
    roleSelect.value = currentUser.role;
  }
}

function applyTablePagination() {
  document.querySelectorAll(".table-pagination").forEach(control => control.remove());
  document.querySelectorAll(".view tbody[id] tr").forEach(row => {
    row.hidden = false;
  });
}

function renderAndPaginate(step, tableIds = []) {
  tableIds.forEach(tableId => {
    tablePages[tableId] = 1;
  });
  step();
  applyTablePagination();
}

function refreshDashboardAfterDataChange() {
  try {
    renderDashboard();
    renderCash();
    renderReports();
    applyTablePagination();
  } catch (error) {
    console.error("Erreur actualisation tableau de bord :", error);
  }
}

function paginateTableBody(tbody) {
  const rows = [...tbody.children].filter(row => row.tagName === "TR");
  const tableId = tbody.id;
  const tableWrap = tbody.closest(".table-wrap");
  if (!tableId || !tableWrap) return;

  let controls = tableWrap.nextElementSibling;
  if (!controls || controls.dataset.paginationFor !== tableId) {
    controls = document.createElement("div");
    controls.className = "table-pagination";
    controls.dataset.paginationFor = tableId;
    tableWrap.insertAdjacentElement("afterend", controls);
  }

  if (rows.length <= TABLE_PAGE_SIZE || rows.some(row => row.querySelector("td[colspan]"))) {
    rows.forEach(row => { row.hidden = false; });
    controls.hidden = true;
    controls.innerHTML = "";
    tablePages[tableId] = 1;
    return;
  }

  const totalPages = Math.max(1, Math.ceil(rows.length / TABLE_PAGE_SIZE));
  const page = Math.min(Math.max(1, tablePages[tableId] || 1), totalPages);
  tablePages[tableId] = page;
  const start = (page - 1) * TABLE_PAGE_SIZE;
  const end = start + TABLE_PAGE_SIZE;

  rows.forEach((row, index) => {
    row.hidden = index < start || index >= end;
  });

  controls.hidden = false;
  controls.innerHTML = `
    <span>${start + 1}-${Math.min(end, rows.length)} sur ${rows.length}</span>
    <div>
      <button class="chip-button" type="button" data-table-page="${tableId}" data-page-direction="prev" ${page <= 1 ? "disabled" : ""}>PrÃ©cÃ©dent</button>
      <strong>Page ${page} / ${totalPages}</strong>
      <button class="chip-button" type="button" data-table-page="${tableId}" data-page-direction="next" ${page >= totalPages ? "disabled" : ""}>Suivant</button>
    </div>
  `;
}

function handleTablePaginationClick(event) {
  const button = event.target.closest("[data-table-page]");
  if (!button) return;
  const tableId = button.dataset.tablePage;
  const direction = button.dataset.pageDirection;
  tablePages[tableId] = Math.max(1, (tablePages[tableId] || 1) + (direction === "next" ? 1 : -1));
  const tbody = document.getElementById(tableId);
  if (tbody) paginateTableBody(tbody);
}

function renderCenterIdentity() {
  const center = state.center || {};
  const name = center.name || "CFP EREXIT";
  const subtitle = center.subtitle || "Centre de Formation Professionnelle";
  const logoSrc = normalizeLogoData(center.logoData);
  if (logoSrc && logoSrc !== center.logoData) {
    state.center = { ...center, logoData: logoSrc };
    saveState();
  }
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0])
    .join("")
    .toUpperCase() || "CE";

  document.querySelectorAll(".brand-mark, .choice-mark").forEach(mark => {
    const fallback = mark.classList.contains("choice-mark") ? mark.textContent.trim() || initials : initials;
    mark.innerHTML = logoSrc
      ? `<img src="${escapeHtml(logoSrc)}" alt="" aria-hidden="true">`
      : escapeHtml(fallback);
  });

  document.querySelectorAll(".brand h1").forEach(title => {
    title.textContent = name;
  });

  const sidebarSubtitle = document.querySelector(".sidebar .brand p");
  if (sidebarSubtitle) {
    sidebarSubtitle.textContent = subtitle;
  }

  if (ids.centerLogoPreview) {
    ids.centerLogoPreview.innerHTML = logoSrc
      ? `<img src="${escapeHtml(logoSrc)}" alt="" aria-hidden="true">`
      : escapeHtml(initials);
  }
  if (ids.centerStampPreview) {
    const stampSrc = normalizeLogoData(center.stampData);
    ids.centerStampPreview.innerHTML = stampSrc
      ? `<img src="${escapeHtml(stampSrc)}" alt="" aria-hidden="true">`
      : "Cachet";
  }
}

function renderDashboard() {
  const monthKey = today().slice(0, 7);
  const totalStudents = state.students.length;
  const onlineRequests = state.onlineRegistrationRequests || [];
  const newOnlineRequests = onlineRequests.filter(item => ["nouvelle", "verification", "complement"].includes(String(item.status || "nouvelle"))).length;
  const pendingOnlinePayments = (state.onlinePayments || []).filter(item => String(item.status || "") === "en attente").length;
  const confirmedOnlinePayments = (state.onlinePayments || []).filter(item => String(item.status || "") === "reussi").length;
  const preRegisteredStudents = state.students.filter(student => student.status === "preinscrit").length;
  const abandonedStudents = state.students.filter(student => ["abandon", "desiste"].includes(String(student.status || "").toLowerCase())).length;
  const validatedEnrollments = state.enrollments.filter(enrollment => enrollment.status === "validee").length;
  const activeGroups = state.groups.filter(group => group.status === "active").length;
  const totalExpected = state.enrollments.reduce((sum, enrollment) => sum + tuitionExpectedForEnrollment(enrollment), 0);
  const monthPayments = state.payments
    .filter(payment => String(payment.date || "").slice(0, 7) === monthKey)
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const todayExpenses = cashLedgerEntries()
    .filter(entry => entry.type === "expense" && entry.date === today())
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const monthExpenses = cashLedgerEntries()
    .filter(entry => entry.type === "expense" && String(entry.date || "").slice(0, 7) === monthKey)
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const incompleteDocumentCount = state.students.filter(student => !personDocumentCompletion(student, "student").completed).length;
  const activeStudents = state.students.filter(student => student.status === "actif").length;
  const activeCourses = state.courses.filter(course => course.status === "active").length;
  const totalPaid = paymentsTotal();
  const tuitionPaid = tuitionPaymentsTotal();
  const annexPaid = annexPaymentsTotal();
  const totalExpenses = cashExpenseTotal();
  const totalDue = state.enrollments.reduce((sum, enrollment) => sum + balanceForEnrollment(enrollment), 0);
  const todayPayments = state.payments
    .filter(payment => payment.date === today())
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);

  ids.statsGrid.innerHTML = [
    { label: "Total etudiants", value: totalStudents, tone: "blue" },
    { label: "Demandes en ligne", value: newOnlineRequests, tone: "gold" },
    { label: "Paiements web attente", value: pendingOnlinePayments, tone: "orange" },
    { label: "Paiements web valides", value: confirmedOnlinePayments, tone: "green" },
    { label: "Preinscrits", value: preRegisteredStudents, tone: "gold" },
    { label: "Inscrits valides", value: validatedEnrollments, tone: "green" },
    { label: "Abandons / desist.", value: abandonedStudents, tone: "red" },
    { label: "Promotions actives", value: activeGroups, tone: "sky" },
    { label: "Scolarite attendue", value: totalExpected, type: "money", tone: "indigo" },
    { label: "Encaissement jour", value: todayPayments, type: "money", tone: "green" },
    { label: "Encaissement mois", value: monthPayments, type: "money", tone: "green" },
    { label: "Depenses jour", value: todayExpenses, type: "money", tone: "orange" },
    { label: "Depenses mois", value: monthExpenses, type: "money", tone: "orange" },
    { label: "Dossiers incomplets", value: incompleteDocumentCount, tone: "red" },
    { label: "Ã‰tudiants actifs", value: activeStudents, tone: "blue" },
    { label: "Formations actives", value: activeCourses, tone: "green" },
    { label: "Inscriptions", value: state.enrollments.length, tone: "gold" },
    { label: "ScolaritÃ© reÃ§ue", value: tuitionPaid, type: "money", tone: "green" },
    { label: "Frais annexes", value: annexPaid, type: "money", tone: "sky" },
    { label: "Paiements reÃ§us", value: totalPaid, type: "money", tone: "indigo" },
    { label: "DÃ©penses", value: totalExpenses, type: "money", tone: "orange" },
    { label: "Solde caisse", value: netCashTotal(), type: "money", tone: "green" },
    { label: "Reste scolaritÃ©", value: totalDue, type: "money", tone: "red" }
  ].map(item => `
    <article class="stat-card tone-${item.tone}">
      <span>${escapeHtml(item.label)}</span>
      ${statValueHtml(item)}
    </article>
  `).join("");

  const recentPayments = [...state.payments]
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .slice(0, 5);

  ids.recentPaymentsTable.innerHTML = recentPayments.map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    const controlInfo = payment.correctedAt
      ? `<div class="muted">Corrige le ${escapeHtml(formatDate(payment.correctedAt))}</div>`
      : "";
    return `
      <tr>
        <td>${escapeHtml(payment.receiptNumber)}${controlInfo}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td class="amount-positive">${formatMoney(payment.amount)}</td>
        <td>${formatDate(payment.date)}</td>
      </tr>
    `;
  }).join("") || emptyRow(4, "Aucun paiement");

  ids.balancesTable.innerHTML = balances()
    .slice(0, 6)
    .map(item => `
      <tr>
        <td>${escapeHtml(item.student)}</td>
        <td>
          <strong>${escapeHtml(item.course)}</strong>
          <div class="muted">${escapeHtml(item.sessionType)}</div>
        </td>
        <td class="amount-danger">${formatMoney(item.balance)}</td>
      </tr>
    `).join("") || emptyRow(3, "Aucun impayÃ©");

  const alerts = paymentAlerts();
  const urgentAlerts = alerts.filter(alert => alert.severity === "danger").length;
  ids.paymentAlertCount.textContent = `${alerts.length} alerte(s)${urgentAlerts ? `, ${urgentAlerts} urgente(s)` : ""}`;
  ids.paymentAlertsTable.innerHTML = alerts.slice(0, 8).map(alert => `
    <tr>
      <td>
        <strong>${escapeHtml(alert.student)}</strong>
        <div class="muted">${escapeHtml(alert.detail)} - ${escapeHtml(alert.sessionType)}</div>
      </td>
      <td><span class="alert-pill ${alert.severity}">${escapeHtml(alert.message)}</span></td>
      <td class="${alert.severity === "danger" ? "amount-danger" : ""}">${formatMoney(alert.amount)}</td>
      <td>${alert.lastPaymentDate ? formatDate(alert.lastPaymentDate) : "Aucun"}</td>
      <td>
        <button class="chip-button success" type="button" data-action="pay-alert" data-id="${alert.enrollmentId}" data-reason="${escapeHtml(alert.reasonKey)}">Encaisser</button>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucune alerte");

  renderDashboardAnalytics({
    tuitionPaid,
    annexPaid,
    totalExpenses,
    totalDue
  });

  if (todayPayments > 0) {
    document.title = `CFP EREXIT - ${formatMoney(todayPayments)} aujourd'hui`;
  } else {
    document.title = "CFP EREXIT Manager";
  }
}

function renderDashboardAnalytics({ tuitionPaid, annexPaid, totalExpenses, totalDue }) {
  if (!ids.dashboardFinanceBars || !ids.dashboardTuitionRing || !ids.dashboardCourseBars) return;
  const safeAmount = value => Number.isFinite(Number(value)) ? Number(value) : 0;
  const totalExpected = (Array.isArray(state.enrollments) ? state.enrollments : [])
    .reduce((sum, enrollment) => sum + safeAmount(tuitionExpectedForEnrollment(enrollment)), 0);
  const recoveryRate = totalExpected > 0 ? Math.round((tuitionPaid / totalExpected) * 100) : 0;
  const clampedRate = Math.max(0, Math.min(100, recoveryRate));
  const financeItems = [
    { label: "ScolaritÃ©", value: safeAmount(tuitionPaid), className: "tuition" },
    { label: "Annexes", value: safeAmount(annexPaid), className: "annex" },
    { label: "DÃ©penses", value: safeAmount(totalExpenses), className: "expense" },
    { label: "Reste", value: safeAmount(totalDue), className: "balance" }
  ];
  const maxFinance = Math.max(1, ...financeItems.map(item => item.value));

  ids.dashboardFinanceBars.innerHTML = `
    <h4>Flux financiers</h4>
    ${financeItems.map(item => `
      <div class="analytics-bar-row">
        <div>
          <strong>${escapeHtml(item.label)}</strong>
          <span>${formatMoney(item.value)}</span>
        </div>
        <div class="analytics-track">
          <div class="analytics-fill ${item.className}" style="width: ${(item.value / maxFinance) * 100}%"></div>
        </div>
        <em>${formatCompactMoney(item.value)}</em>
      </div>
    `).join("")}
  `;

  ids.dashboardTuitionRing.style.setProperty("--progress", `${clampedRate}%`);
  ids.dashboardTuitionRing.innerHTML = `
    <strong>${clampedRate}%</strong>
    <span>recouvrÃ©</span>
  `;
  ids.dashboardTuitionDetails.innerHTML = `
    <strong>Recouvrement scolaritÃ©</strong>
    <span>${formatMoney(tuitionPaid)} encaissÃ©s</span>
    <span>${formatMoney(totalExpected)} attendus</span>
  `;

  const courses = Array.isArray(state.courses) ? state.courses.filter(Boolean) : [];
  const enrollments = Array.isArray(state.enrollments) ? state.enrollments.filter(Boolean) : [];
  const courseItems = courses.map(course => {
    const courseEnrollments = enrollments.filter(enrollment => Number(enrollment.courseId) === Number(course.id) && !isInactiveTuitionEnrollment(enrollment));
    return {
      label: course.code || course.name,
      value: courseEnrollments.length
    };
  }).filter(item => item.value > 0);
  const maxCourse = Math.max(1, ...courseItems.map(item => item.value));
  ids.dashboardCourseBars.innerHTML = `
    <h4>Inscriptions par formation</h4>
    ${courseItems.map(item => `
      <div class="course-analytics-row">
        <span>${escapeHtml(item.label)}</span>
        <div class="analytics-track">
          <div class="analytics-fill course" style="width: ${(item.value / maxCourse) * 100}%"></div>
        </div>
        <strong>${item.value}</strong>
      </div>
    `).join("") || `<p class="muted">Aucune inscription</p>`}
  `;
}

function onlineRequestStatusLabel(status) {
  const labels = {
    nouvelle: "Nouvelle demande",
    verification: "En verification",
    complement: "Complement demande",
    acceptee: "Acceptee",
    refusee: "Refusee",
    convertie: "Convertie en inscription"
  };
  return labels[status] || status || "Nouvelle demande";
}

function renderOnlineRequests() {
  if (!ids.onlineRequestsTable) return;
  const query = document.getElementById("onlineRequestSearch")?.value.trim().toLowerCase() || "";
  const statusFilter = document.getElementById("onlineRequestStatusFilter")?.value || "";
  const requests = [...(state.onlineRegistrationRequests || [])]
    .filter(item => {
      const course = getCourse(item.courseId);
      const haystack = [
        item.requestNumber,
        item.lastName,
        item.firstName,
        item.phone,
        item.email,
        item.source,
        item.message,
        course?.name,
        course?.code
      ].join(" ").toLowerCase();
      return (!query || haystack.includes(query)) && (!statusFilter || item.status === statusFilter);
    })
    .sort((a, b) => String(b.submittedAt || "").localeCompare(String(a.submittedAt || "")));

  ids.onlineRequestCount.textContent = `${requests.length} sur ${(state.onlineRegistrationRequests || []).length}`;
  ids.onlineRequestsTable.innerHTML = requests.map(item => {
    const course = getCourse(item.courseId);
    const canConvert = !["convertie", "refusee"].includes(String(item.status || ""));
    return `
      <tr>
        <td>
          <strong>${escapeHtml(item.requestNumber || `DEM-${item.id}`)}</strong>
          <div class="muted">${formatDateTime(new Date(item.submittedAt || Date.now()))}</div>
          <div class="muted">Source : ${escapeHtml(item.source || "-")}</div>
        </td>
        <td>
          <strong>${escapeHtml([item.lastName, item.firstName].filter(Boolean).join(" "))}</strong>
          <div class="muted">${escapeHtml([item.gender, item.birthDate ? formatDate(item.birthDate) : "", item.nationality].filter(Boolean).join(" - "))}</div>
          <div class="muted">${escapeHtml([item.address, item.district, item.city, item.country].filter(Boolean).join(", "))}</div>
        </td>
        <td>
          <strong>${escapeHtml(course?.name || "-")}</strong>
          <div class="muted">${escapeHtml(item.preferredCourseType || "Type de cours non precise")}</div>
          <div class="muted">${escapeHtml(item.message || "")}</div>
        </td>
        <td>
          ${escapeHtml(item.phone || "-")}
          <div class="muted">${escapeHtml(item.email || "")}</div>
          <div class="muted">Urgence : ${escapeHtml([item.emergencyName, item.emergencyPhone].filter(Boolean).join(" - ") || "-")}</div>
        </td>
        <td><span class="status ${statusClass(item.status)}">${escapeHtml(onlineRequestStatusLabel(item.status))}</span></td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="online-request-status" data-id="${item.id}" data-status="verification">Verifier</button>
            <button class="chip-button" type="button" data-action="online-request-status" data-id="${item.id}" data-status="complement">Complement</button>
            ${canConvert ? `<button class="chip-button success" type="button" data-action="convert-online-request" data-id="${item.id}">Convertir</button>` : ""}
            <button class="chip-button danger" type="button" data-action="online-request-status" data-id="${item.id}" data-status="refusee">Refuser</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(6, "Aucune demande en ligne");
}

function studentCourseIds(studentId) {
  const ids = new Set();
  state.enrollments
    .filter(enrollment => Number(enrollment.studentId) === Number(studentId))
    .forEach(enrollment => {
      if (enrollment.courseId) ids.add(Number(enrollment.courseId));
    });
  return ids;
}

function renderStudents() {
  const query = document.getElementById("studentSearch").value.trim().toLowerCase();
  const status = document.getElementById("studentStatusFilter").value;
  const courseFilter = document.getElementById("studentCourseFilter")?.value || "";
  const filtered = state.students.filter(student => {
    const courseIds = studentCourseIds(student.id);
    const desiredCourseId = Number(student.desiredCourseId || 0);
    const haystack = [
      student.matricule,
      student.firstName,
      student.lastName,
      student.phone,
      student.email,
      student.address,
      student.district,
      student.city,
      student.nationality,
      student.studyLevel,
      student.profession,
      student.source,
      student.observation
    ]
      .join(" ")
      .toLowerCase();
    const matchesCourse = !courseFilter || courseIds.has(Number(courseFilter)) || desiredCourseId === Number(courseFilter);
    return (!query || haystack.includes(query)) && (!status || student.status === status) && matchesCourse;
  });

  ids.studentCount.textContent = `${filtered.length} sur ${state.students.length}`;
  ids.studentsTable.innerHTML = filtered.map(student => `
    <tr>
      <td>${escapeHtml(student.matricule)}</td>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(student, "ET")}
          <div>
            <strong>${escapeHtml(fullName(student))}</strong>
            <div class="muted">${escapeHtml(student.email || student.address || "")}</div>
            <div class="person-details-line">
              ${escapeHtml([
                student.gender ? `Sexe ${student.gender}` : "",
                student.birthDate ? `NÃ©(e) le ${formatDate(student.birthDate)}` : "",
                student.emergencyPhone ? `Personne Ã  contacter ${student.emergencyPhone}` : ""
              ].filter(Boolean).join(" Â· ") || "Informations Ã  complÃ©ter")}
            </div>
            <div class="muted">${escapeHtml([
              student.birthPlace ? `Lieu: ${student.birthPlace}` : "",
              student.nationality ? `Nationalite: ${student.nationality}` : "",
              student.desiredCourseId ? `Formation souhaitee: ${getCourse(student.desiredCourseId)?.name || ""}` : "",
              student.source ? `Source: ${student.source}` : "",
              student.paymentResponsible ? `Paiement: ${student.paymentResponsible}` : ""
            ].filter(Boolean).join(" - "))}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(student))}</div>
            <div>${documentCompletionBadge(student, "student")}</div>
          </div>
        </div>
      </td>
      <td>${escapeHtml(student.phone || "-")}</td>
      <td><span class="status ${statusClass(student.status)}">${escapeHtml(student.status)}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button success" type="button" data-action="enroll-student" data-id="${student.id}">Inscrire</button>
          <button class="chip-button" type="button" data-action="edit-student" data-id="${student.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-student" data-id="${student.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun Ã©tudiant");
}

function renderCourses() {
  const query = document.getElementById("courseSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("courseStatusFilter")?.value || "";
  const courses = state.courses.filter(course => {
    const haystack = [course.code, course.name, course.duration, course.description].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || course.status === status);
  });
  ids.courseCount.textContent = `${courses.length} sur ${state.courses.length}`;
  ids.coursesTable.innerHTML = courses.map(course => `
    <tr>
      <td>${escapeHtml(course.code)}</td>
      <td>
        <strong>${escapeHtml(course.name)}</strong>
        <div class="muted">${escapeHtml(course.description || "")}</div>
      </td>
      <td>${escapeHtml(course.duration || "-")}</td>
      <td>${formatMoney(courseCost(course))}</td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-course" data-id="${course.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-course" data-id="${course.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucune formation");
}

function renderGroups() {
  const courseFilter = document.getElementById("groupCourseFilter")?.value || "";
  const sessionFilter = document.getElementById("groupSessionFilter")?.value || "";
  const statusFilter = document.getElementById("groupStatusFilter")?.value || "";
  const groups = state.groups.filter(group =>
    (!courseFilter || String(group.courseId) === courseFilter) &&
    (!sessionFilter || String(group.sessionType || "jour") === sessionFilter) &&
    (!statusFilter || String(group.status || "") === statusFilter)
  );
  ids.groupCount.textContent = `${groups.length} sur ${state.groups.length}`;
  ids.groupsTable.innerHTML = groups.map(group => {
    const course = getCourse(group.courseId);
    const trainer = getTrainer(group.trainerId);
    const count = state.enrollments.filter(enrollment => Number(enrollment.groupId) === Number(group.id)).length;
    return `
      <tr>
        <td>
          <strong>${escapeHtml(group.name)}</strong>
          <div class="muted">${escapeHtml(trainerName(trainer) || group.trainer || "Formateur non prÃ©cisÃ©")}</div>
        </td>
        <td>${escapeHtml(course?.name || "-")}</td>
        <td><span class="status ${String(group.sessionType || "jour") === "soir" ? "termine" : String(group.sessionType || "jour") === "ligne" ? "excuse" : "active"}">${escapeHtml(groupSessionLabel(group))}</span></td>
        <td>${count}${group.capacity ? ` / ${group.capacity}` : ""}</td>
        <td>${formatDate(group.startDate)} - ${formatDate(group.endDate)}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="edit-group" data-id="${group.id}">Modifier</button>
            <button class="chip-button danger" type="button" data-action="delete-group" data-id="${group.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(6, "Aucune promotion");
}

function renderEnrollments() {
  const query = document.getElementById("enrollmentSearch")?.value.trim().toLowerCase() || "";
  const courseFilter = document.getElementById("enrollmentCourseFilter")?.value || "";
  const statusFilter = document.getElementById("enrollmentStatusFilter")?.value || "";
  const balanceFilter = document.getElementById("enrollmentBalanceFilter")?.value || "";
  const enrollments = state.enrollments.filter(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    const balance = balanceForEnrollment(enrollment);
    const haystack = [fullName(student), student?.matricule, course?.name, course?.code, group?.name].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) &&
      (!courseFilter || String(enrollment.courseId) === courseFilter) &&
      (!statusFilter || enrollment.status === statusFilter) &&
      (!balanceFilter || (balanceFilter === "due" ? balance > 0 : balance <= 0));
  });
  ids.enrollmentCount.textContent = `${enrollments.length} sur ${state.enrollments.length}`;
  ids.enrollmentsTable.innerHTML = enrollments.map(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    const paid = paidAmount(enrollment.id);
    const annexPaid = annexPaidAmount(enrollment.id);
    const balance = balanceForEnrollment(enrollment);
    return `
      <tr>
        <td>${escapeHtml(fullName(student))}</td>
        <td>${escapeHtml(course?.name || "-")}</td>
        <td>
          <strong>${escapeHtml(group?.name || "-")}</strong>
          <div class="muted">${escapeHtml(groupSessionLabel(group))}</div>
        </td>
        <td class="amount-positive">${formatMoney(paid)}</td>
        <td>${formatMoney(annexPaid)}</td>
        <td>
          <span class="status ${statusClass(enrollment.status)}">${escapeHtml(enrollment.status || "-")}</span>
          <div class="${balance > 0 ? "amount-danger" : "amount-positive"}">${formatMoney(balance)}</div>
        </td>
        <td>
          <div class="actions">
            <button class="chip-button success" type="button" data-action="pay-enrollment" data-id="${enrollment.id}">Payer</button>
            <button class="chip-button" type="button" data-action="print-enrollment" data-id="${enrollment.id}">Fiche</button>
            <button class="chip-button" type="button" data-action="print-attestation" data-id="${enrollment.id}">Attestation</button>
            <button class="chip-button" type="button" data-action="print-contract" data-id="${enrollment.id}">Contrat</button>
            <button class="chip-button" type="button" data-action="edit-enrollment" data-id="${enrollment.id}">Modifier</button>
            <button class="chip-button danger" type="button" data-action="delete-enrollment" data-id="${enrollment.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(7, "Aucune inscription");
}

function renderPayments() {
  const allowControl = canControlPayments();
  const query = document.getElementById("paymentSearch")?.value.trim().toLowerCase() || "";
  const category = document.getElementById("paymentCategoryFilter")?.value || "";
  const method = document.getElementById("paymentMethodFilter")?.value || "";
  const month = document.getElementById("paymentMonthFilter")?.value || "";
  const payments = state.payments.filter(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    const tuition = isTuitionPayment(payment);
    const haystack = [payment.receiptNumber, fullName(student), payment.reason, payment.method, payment.date].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) &&
      (!category || (category === "tuition" ? tuition : !tuition)) &&
      (!method || payment.method === method) &&
      (!month || String(payment.date).startsWith(month));
  });
  ids.paymentCount.textContent = `${payments.length} sur ${state.payments.length}`;
  ids.paymentsTable.innerHTML = [...payments].reverse().map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return `
      <tr>
        <td>${escapeHtml(payment.receiptNumber)}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td>${escapeHtml(payment.reason || "-")}</td>
        <td><span class="status ${isTuitionPayment(payment) ? "active" : "termine"}">${isTuitionPayment(payment) ? "ScolaritÃ©" : "Annexe"}</span></td>
        <td class="amount-positive">${formatMoney(payment.amount)}</td>
        <td>${escapeHtml(payment.method)}</td>
        <td>${formatDate(payment.date)}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-receipt" data-id="${payment.id}">ReÃ§u</button>
            ${allowControl ? `<button class="chip-button" type="button" data-action="edit-payment" data-id="${payment.id}">Modifier</button>` : ""}
            ${allowControl ? `<button class="chip-button danger" type="button" data-action="delete-payment" data-id="${payment.id}">Supprimer</button>` : ""}
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(8, "Aucun paiement");
  const auditItems = [...state.paymentAuditLog].reverse();
  ids.paymentAuditCount.textContent = `${auditItems.length} action(s)`;
  ids.paymentAuditTable.innerHTML = auditItems.map(item => {
    const source = item.before || item.after || {};
    const enrollment = getEnrollment(source.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return `
      <tr>
        <td>${formatDate(String(item.date || "").slice(0, 10))}</td>
        <td><span class="status ${item.action === "Suppression" ? "annulee" : "en-attente"}">${escapeHtml(item.action || "-")}</span></td>
        <td>${escapeHtml(item.receiptNumber || source.receiptNumber || "-")}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td>
          <strong>${escapeHtml(source.reason || "-")}</strong>
          <div class="muted">${escapeHtml(source.method || "")} ${source.date ? `- ${formatDate(source.date)}` : ""}</div>
        </td>
        <td class="amount-danger">${formatMoney(source.amount || 0)}</td>
        <td>${escapeHtml(item.operator || "-")}</td>
        <td>${escapeHtml(item.controlReason || "-")}</td>
      </tr>
    `;
  }).join("") || emptyRow(8, "Aucune correction");
  updatePaymentBalance();
}

function renderCash() {
  const entries = cashLedgerEntries();
  ids.cashBalance.textContent = `Solde : ${formatMoney(netCashTotal())}`;
  ids.cashCount.textContent = `${entries.length} opÃ©ration(s)`;
  ids.cashTable.innerHTML = entries.map(entry => {
    const isIncome = entry.type === "income";
    return `
      <tr>
        <td>${formatDate(entry.date)}</td>
        <td><span class="status ${isIncome ? "active" : "annulee"}">${isIncome ? "EntrÃ©e" : "DÃ©pense"}</span></td>
        <td>
          <strong>${escapeHtml(entry.category || "-")}</strong>
          <div class="muted">${escapeHtml(entry.description || "")}</div>
          ${entry.locked && entry.source !== "cash" ? `<div class="muted">Mouvement automatique</div>` : ""}
          ${entry.closedAt ? `<div class="muted">Cloturee par ${escapeHtml(entry.closedBy || "-")} le ${escapeHtml(formatDateTime(entry.closedAt))}</div>` : ""}
        </td>
        <td class="${isIncome ? "amount-positive" : "amount-danger"}">${formatMoney(entry.amount)}</td>
        <td>${escapeHtml(entry.method || "-")}</td>
        <td>
          <div class="actions">
            ${entry.locked && entry.source !== "cash"
              ? `<span class="status en-attente">Auto</span>`
              : entry.closedAt && !isAdmin()
                ? `<span class="status termine">Cloturee</span>`
              : `<button class="chip-button danger" type="button" data-action="delete-cash-entry" data-id="${entry.rawId}">Supprimer</button>`}
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(6, "Aucune opÃ©ration de caisse");
}

function renderAttendance() {
  const groupId = Number(document.getElementById("attendanceGroup").value);
  const enrolled = state.enrollments
    .filter(enrollment => Number(enrollment.groupId) === groupId && !isInactiveTuitionEnrollment(enrollment))
    .map(enrollment => getStudent(enrollment.studentId))
    .filter(Boolean);

  ids.attendanceTotal.textContent = `${enrolled.length} Ã©tudiant(s)`;
  ids.attendanceList.innerHTML = enrolled.map(student => `
    <div class="attendance-row">
      <div class="student-line">
        <strong>${escapeHtml(fullName(student))}</strong>
        <span>${escapeHtml(student.matricule)}</span>
      </div>
      <select data-attendance-student="${student.id}">
        <option value="present">PrÃ©sent</option>
        <option value="absent">Absent</option>
        <option value="retard">Retard</option>
        <option value="excuse">ExcusÃ©</option>
      </select>
    </div>
  `).join("") || `<p class="muted">Aucun Ã©tudiant inscrit dans cette promotion.</p>`;

  ids.attendanceCount.textContent = `${state.attendanceSessions.length} sÃ©ance(s)`;
  ids.attendanceTable.innerHTML = [...state.attendanceSessions].reverse().map(session => {
    const group = getGroup(session.groupId);
    const present = session.records.filter(record => record.status === "present").length;
    const absent = session.records.filter(record => record.status === "absent").length;
    const late = session.records.filter(record => record.status === "retard").length;
    return `
      <tr>
        <td>${formatDate(session.date)}</td>
        <td>
          <strong>${escapeHtml(group?.name || "-")}</strong>
          <div class="muted">${escapeHtml(session.topic || "")}</div>
        </td>
        <td>${present}</td>
        <td>${absent}</td>
        <td>${late}</td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucun appel enregistrÃ©");
}

function renderTrainerAttendance() {
  const trainers = state.trainers.filter(trainer => (trainer.status || "actif") !== "archive");

  ids.trainerAttendanceTotal.textContent = `${trainers.length} professeur(s)`;
  ids.trainerAttendanceList.innerHTML = trainers.map(trainer => `
    <div class="attendance-row">
      <div class="student-line">
        <strong>${escapeHtml(trainerName(trainer))}</strong>
        <span>${escapeHtml(trainer.modules || trainer.specialty || "")}</span>
      </div>
      <select data-attendance-trainer="${trainer.id}">
        <option value="present">PrÃ©sent</option>
        <option value="absent">Absent</option>
        <option value="retard">Retard</option>
        <option value="excuse">ExcusÃ©</option>
      </select>
    </div>
  `).join("") || `<p class="muted">Aucun professeur enregistrÃ©.</p>`;

  ids.trainerAttendanceCount.textContent = `${state.trainerAttendanceSessions.length} appel(s)`;
  ids.trainerAttendanceTable.innerHTML = [...state.trainerAttendanceSessions].reverse().map(session => {
    const present = session.records.filter(record => record.status === "present").length;
    const absent = session.records.filter(record => record.status === "absent").length;
    const late = session.records.filter(record => record.status === "retard").length;
    return `
      <tr>
        <td>${formatDate(session.date)}</td>
        <td>
          <strong>${session.records.length} professeur(s)</strong>
          <div class="muted">${escapeHtml(session.topic || "")}</div>
        </td>
        <td>${present}</td>
        <td>${absent}</td>
        <td>${late}</td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucun appel professeur enregistrÃ©");
}

function renderTrainers() {
  const query = document.getElementById("trainerSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("trainerStatusFilter")?.value || "";
  const trainers = state.trainers.filter(trainer => {
    const haystack = [trainer.firstName, trainer.lastName, trainer.phone, trainer.email, trainer.specialty, trainer.modules].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || trainer.status === status);
  });
  ids.trainerCount.textContent = `${trainers.length} sur ${state.trainers.length}`;
  ids.trainersTable.innerHTML = trainers.map(trainer => `
    <tr>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(trainer, "FO")}
          <div>
            <strong>${escapeHtml(trainerName(trainer))}</strong>
            <div class="muted">${escapeHtml(trainer.modules || "")}</div>
            <div class="person-details-line">${escapeHtml(trainer.specialty || trainer.phone || "Informations Ã  complÃ©ter")}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(trainer))}</div>
            <div>${documentCompletionBadge(trainer, "trainer")}</div>
          </div>
        </div>
      </td>
      <td>
        ${escapeHtml(trainer.phone || "-")}
        <div class="muted">${escapeHtml(trainer.email || "")}</div>
      </td>
      <td>${escapeHtml(trainer.specialty || "-")}</td>
      <td><span class="status ${statusClass(trainer.status)}">${escapeHtml(trainer.status || "actif")}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-trainer" data-id="${trainer.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-trainer" data-id="${trainer.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun formateur");
}

function renderStaff() {
  const query = document.getElementById("staffSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("staffStatusFilter")?.value || "";
  const members = state.staffMembers.filter(member => {
    const haystack = [member.firstName, member.lastName, member.role, member.phone, member.email].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || member.status === status);
  });
  const totalPaid = staffPaymentsTotal();
  ids.staffCount.textContent = `${members.length} membre(s)`;
  ids.staffPaymentTotal.textContent = formatMoney(totalPaid);
  ids.staffTable.innerHTML = members.map(member => `
    <tr>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(member, "PE")}
          <div>
            <strong>${escapeHtml(staffName(member))}</strong>
            <div class="muted">${escapeHtml(member.phone || member.email || "")}</div>
            <div class="person-details-line">${escapeHtml([member.role, member.email].filter(Boolean).join(" Â· ") || "Informations Ã  complÃ©ter")}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(member))}</div>
            <div>${documentCompletionBadge(member, "staff")}</div>
          </div>
        </div>
      </td>
      <td>${escapeHtml(member.role || "-")}</td>
      <td>${formatMoney(member.salary)}</td>
      <td><span class="status ${statusClass(member.status)}">${escapeHtml(member.status || "actif")}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-staff" data-id="${member.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-staff" data-id="${member.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun personnel");

  ids.staffPaymentCount.textContent = `${state.staffPayments.length} paiement(s)`;
  ids.staffPaymentsTable.innerHTML = [...state.staffPayments].reverse().map(payment => {
    const beneficiary = payrollBeneficiary(payment);
    return `
      <tr>
        <td>${formatDate(payment.date)}</td>
        <td>
          <strong>${escapeHtml(beneficiary.name)}</strong>
          <div class="muted">${escapeHtml(beneficiary.role)}</div>
          <div class="muted">${escapeHtml(payment.note || "")}</div>
        </td>
        <td>${escapeHtml(payment.period || "-")}</td>
        <td>${escapeHtml(payment.reason || "-")}</td>
        <td class="amount-danger">${formatMoney(payment.amount)}</td>
        <td>${escapeHtml(payment.method || "-")}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-payroll-slip" data-id="${payment.id}">Fiche de paie</button>
            <button class="chip-button danger" type="button" data-action="delete-staff-payment" data-id="${payment.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(7, "Aucun paiement personnel");
}

function renderEvaluations() {
  updateEvaluationStudents();
  ids.evaluationCount.textContent = `${state.evaluations.length} evaluation(s)`;
  ids.evaluationsTable.innerHTML = [...state.evaluations].reverse().map(evaluation => {
    const group = getGroup(evaluation.groupId);
    const trainer = getTrainer(evaluation.trainerId);
    const makeup = evaluationMakeupStats(evaluation);
    return `
      <tr>
        <td>
          <strong>${escapeHtml(evaluation.title)}</strong>
          <div class="muted">${escapeHtml(evaluation.type || "-")} - ${escapeHtml(trainerName(trainer))}</div>
        </td>
        <td>${escapeHtml(group?.name || "-")}</td>
        <td>${formatDate(evaluation.date)}</td>
        <td>
          ${formatAverage(evaluation)}
          <div class="muted">${makeup.count} rattrapage(s) - ${formatMoney(makeup.amount)}</div>
        </td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-grades" data-id="${evaluation.id}">PV notes</button>
            <button class="chip-button" type="button" data-action="edit-evaluation" data-id="${evaluation.id}">Modifier</button>
            <button class="chip-button danger" type="button" data-action="delete-evaluation" data-id="${evaluation.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucune evaluation");
}

function renderReports() {
  const totalPaid = paymentsTotal();
  const tuitionPaid = tuitionPaymentsTotal();
  const annexPaid = annexPaymentsTotal();
  const otherIncome = cashIncomeTotal();
  const totalExpenses = cashExpenseTotal();
  const month = today().slice(0, 7);
  const monthPaid = state.payments
    .filter(payment => String(payment.date).startsWith(month))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const monthOtherIncome = state.cashEntries
    .filter(entry => entry.type === "income" && String(entry.date).startsWith(month))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const monthExpenses = state.cashEntries
    .filter(entry => entry.type === "expense" && String(entry.date).startsWith(month))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalExpected = state.enrollments.reduce((sum, enrollment) => sum + tuitionExpectedForEnrollment(enrollment), 0);
  const totalBalance = state.enrollments.reduce((sum, enrollment) => sum + balanceForEnrollment(enrollment), 0);

  ids.financialReport.innerHTML = [
    ["ScolaritÃ© attendue", formatMoney(totalExpected)],
    ["ScolaritÃ© encaissÃ©e", formatMoney(tuitionPaid)],
    ["Frais annexes encaissÃ©s", formatMoney(annexPaid)],
    ["Total paiements Ã©tudiants", formatMoney(totalPaid)],
    ["Autres entrÃ©es", formatMoney(otherIncome)],
    ["DÃ©penses", formatMoney(totalExpenses)],
    ["Solde net caisse", formatMoney(netCashTotal())],
    ["Encaissement du mois", formatMoney(monthPaid + monthOtherIncome)],
    ["DÃ©penses du mois", formatMoney(monthExpenses)],
    ["Reste scolaritÃ©", formatMoney(totalBalance)]
  ].map(([label, value]) => `
    <article class="mini-card">
      <span>${label}</span>
      <strong>${value}</strong>
    </article>
  `).join("");

  ids.reportBalancesTable.innerHTML = balances().map(item => `
    <tr>
      <td>${escapeHtml(item.student)}</td>
      <td>
        <strong>${escapeHtml(item.course)}</strong>
        <div class="muted">${escapeHtml(item.sessionType)} - Exigible ${formatMoney(item.tuitionExpected)}</div>
      </td>
      <td class="amount-positive">${formatMoney(item.paid)}</td>
      <td class="amount-danger">${formatMoney(item.balance)}</td>
    </tr>
  `).join("") || emptyRow(4, "Aucun impayÃ©");

  const counts = state.courses.map(course => ({
    name: course.name,
    count: state.enrollments.filter(enrollment => Number(enrollment.courseId) === Number(course.id) && !isInactiveTuitionEnrollment(enrollment)).length
  }));
  const max = Math.max(1, ...counts.map(item => item.count));
  ids.courseDistribution.innerHTML = counts.map(item => `
    <div class="bar-row">
      <strong>${escapeHtml(item.name)}</strong>
      <div class="bar-track"><div class="bar-fill" style="width: ${(item.count / max) * 100}%"></div></div>
      <span>${item.count}</span>
    </div>
  `).join("");

  const scheduleRows = monthlyScheduleRows();
  ids.monthlyScheduleCount.textContent = `${scheduleRows.length} Ã©chÃ©ance(s)`;
  ids.monthlyScheduleTable.innerHTML = scheduleRows.map(row => `
    <tr>
      <td>${escapeHtml(row.month)}</td>
      <td>${escapeHtml(row.student)}</td>
      <td>${escapeHtml(row.course)}</td>
      <td>${formatMoney(row.expected)}</td>
      <td class="amount-positive">${formatMoney(row.paid)}</td>
      <td class="${row.balance > 0 ? "amount-danger" : "amount-positive"}">${formatMoney(row.balance)}</td>
    </tr>
  `).join("") || emptyRow(6, "Aucune Ã©chÃ©ance");

  renderDocumentGenerator();
  renderIndividualReport();
}

function addMonths(dateValue, count) {
  const date = new Date(`${dateValue || today()}T00:00:00`);
  date.setMonth(date.getMonth() + count);
  return date.toISOString().slice(0, 7);
}

function monthlyScheduleRows() {
  const rows = [];
  state.enrollments
    .filter(enrollment => !suppressPaymentTrackingForEnrollment(enrollment))
    .forEach(enrollment => {
      const course = getCourse(enrollment.courseId);
      const monthly = Number(course?.monthlyFee || 0);
      const finalAmount = tuitionExpectedForEnrollment(enrollment);
      if (!monthly || !finalAmount) return;
      const student = getStudent(enrollment.studentId);
      const totalMonths = Math.max(1, Math.ceil(finalAmount / monthly));
      const tuitionPaid = paidAmount(enrollment.id);
      for (let index = 0; index < totalMonths; index += 1) {
        const expected = Math.min(monthly, finalAmount - (monthly * index));
        const cumulativeExpected = Math.min(finalAmount, monthly * (index + 1));
        const cumulativeBalance = Math.max(0, cumulativeExpected - tuitionPaid);
        rows.push({
          month: addMonths(enrollment.date, index),
          student: fullName(student),
          course: course?.name || "-",
          expected,
          paid: Math.min(tuitionPaid, cumulativeExpected),
          balance: cumulativeBalance
        });
      }
    });
  return rows.sort((a, b) => String(a.month).localeCompare(String(b.month)) || a.student.localeCompare(b.student));
}

function renderIndividualReport() {
  if (!ids.individualReportStudent || !ids.individualReportSummary || !ids.individualMotifTable) return;
  const { enrollments, payments, tuitionExpected, tuitionPaid, annexPaid, totalPaid, balance, paymentsByMotif } = individualStudentReportData();

  ids.individualReportSummary.innerHTML = [
    ["ScolaritÃ© due", formatMoney(tuitionExpected)],
    ["ScolaritÃ© payÃ©e", formatMoney(tuitionPaid)],
    ["Reste scolaritÃ©", formatMoney(balance)],
    ["Frais annexes payÃ©s", formatMoney(annexPaid)],
    ["Total payÃ©", formatMoney(totalPaid)]
  ].map(([label, value]) => `
    <article class="mini-card">
      <span>${label}</span>
      <strong>${value}</strong>
    </article>
  `).join("");

  const enrollmentRows = enrollments.map(enrollment => {
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    return `
      <tr>
        <td>
          <strong>${escapeHtml(course?.name || "-")}</strong>
          <div class="muted">${escapeHtml(group?.name || "-")} - ${escapeHtml(groupSessionLabel(group))}</div>
        </td>
        <td><span class="status ${statusClass(enrollment.status)}">${escapeHtml(enrollment.status || "-")}</span></td>
        <td>
          <strong>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</strong>
          <div class="muted">Paye ${formatMoney(paidAmount(enrollment.id))} - Reste ${formatMoney(balanceForEnrollment(enrollment))}</div>
        </td>
        <td>${formatDate(enrollment.date)}</td>
      </tr>
    `;
  });

  const paymentRows = payments.map(item => `
    <tr>
      <td>
        <strong>${escapeHtml(item.receiptNumber || "-")}</strong>
        <div class="muted">${escapeHtml(item.reason || "-")}</div>
      </td>
      <td><span class="status ${item.category === "ScolaritÃ©" ? "active" : "termine"}">${escapeHtml(item.category)}</span></td>
      <td class="amount-positive">${formatMoney(item.amount)}</td>
      <td>${formatDate(item.lastDate)}</td>
    </tr>
  `).join("") || emptyRow(4, "Aucun paiement pour cet Ã©tudiant");
  ids.individualMotifTable.innerHTML = enrollmentRows.join("") + paymentRows;
}

function individualStudentReportData(studentId = Number(ids.individualReportStudent?.value || state.students[0]?.id || 0)) {
  const student = getStudent(studentId);
  const enrollments = state.enrollments.filter(enrollment => Number(enrollment.studentId) === studentId);
  const payments = enrollments
    .flatMap(enrollment => paymentsForEnrollment(enrollment.id).map(payment => ({
      ...payment,
      enrollment,
      category: isTuitionPayment(payment) ? "Scolarite" : "Frais annexe",
      lastDate: payment.date
    })))
    .sort((a, b) => String(a.date).localeCompare(String(b.date)) || Number(a.id) - Number(b.id));
  const tuitionExpected = enrollments.reduce((sum, enrollment) => sum + tuitionExpectedForEnrollment(enrollment), 0);
  const tuitionPaid = enrollments.reduce((sum, enrollment) => sum + paidAmount(enrollment.id), 0);
  const annexPaid = enrollments.reduce((sum, enrollment) => sum + annexPaidAmount(enrollment.id), 0);
  const totalPaid = tuitionPaid + annexPaid;
  const balance = Math.max(0, tuitionExpected - tuitionPaid);
  const byMotif = new Map();

  payments.forEach(payment => {
    const key = payment.reasonKey || payment.reason || "motif";
    const current = byMotif.get(key) || {
      reason: payment.reason || key,
      category: isTuitionPayment(payment) ? "ScolaritÃ©" : "Frais annexe",
      amount: 0,
      lastDate: ""
    };
    current.amount += Number(payment.amount || 0);
    if (!current.lastDate || String(payment.date).localeCompare(String(current.lastDate)) > 0) {
      current.lastDate = payment.date;
    }
    byMotif.set(key, current);
  });

  return {
    student,
    enrollments,
    payments,
    paymentsByMotif: [...byMotif.values()],
    tuitionExpected,
    tuitionPaid,
    annexPaid,
    totalPaid,
    balance
  };
}

function activeDocumentTemplates() {
  ensureDocumentTemplates();
  return state.documentTemplates
    .filter(template => template.status !== "archive")
    .map(template => ({ ...template, id: template.key }))
    .sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title)));
}

function templateByKey(key) {
  ensureDocumentTemplates();
  return state.documentTemplates.find(template => template.key === key);
}

function latestEnrollmentForStudent(studentId) {
  return state.enrollments
    .filter(enrollment => Number(enrollment.studentId) === Number(studentId))
    .sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")) || Number(b.id) - Number(a.id))[0];
}

function documentTemplateContext({ enrollmentId = 0, studentId = 0, beneficiaryValue = "" } = {}) {
  const center = state.center || {};
  const enrollment = getEnrollment(enrollmentId) || latestEnrollmentForStudent(studentId) || state.enrollments[0];
  const student = getStudent(studentId) || getStudent(enrollment?.studentId);
  const course = getCourse(enrollment?.courseId);
  const group = getGroup(enrollment?.groupId);
  const parsedBeneficiary = parsePayrollBeneficiary(beneficiaryValue);
  const person = parsedBeneficiary.type === "trainer"
    ? getTrainer(parsedBeneficiary.id)
    : getStaffMember(parsedBeneficiary.id);
  const beneficiaryName = parsedBeneficiary.type === "trainer" ? trainerName(person) : staffName(person);
  const beneficiaryRole = parsedBeneficiary.type === "trainer" ? "Formateur" : (person?.role || "Personnel");

  return {
    centre_nom: center.name || "CFP EREXIT",
    centre_sous_titre: center.subtitle || "Centre de Formation Professionnelle",
    centre_telephone: center.phone || "",
    centre_email: center.email || "",
    centre_adresse: center.address || "",
    etudiant_nom: fullName(student),
    matricule: student?.matricule || "",
    telephone: student?.phone || person?.phone || "",
    email: student?.email || person?.email || "",
    formation: course?.name || "",
    promotion: group?.name || "",
    type_cours: groupSessionLabel(group),
    date_inscription: enrollment?.date ? formatDate(enrollment.date) : "",
    scolarite: enrollment ? formatMoney(tuitionExpectedForEnrollment(enrollment)) : "",
    scolarite_payee: enrollment ? formatMoney(paidAmount(enrollment.id)) : "",
    reste_scolarite: enrollment ? formatMoney(balanceForEnrollment(enrollment)) : "",
    beneficiaire_nom: beneficiaryName,
    fonction: beneficiaryRole,
    date: formatDate(today())
  };
}

function renderTemplateContent(content, context) {
  const resolved = String(content || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) => context[key] ?? "");
  return resolved
    .split(/\n{2,}/)
    .map(paragraph => `<p>${escapeHtml(paragraph).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

function renderDocumentGenerator() {
  if (!ids.documentGeneratorTemplate) return;
  const template = templateByKey(ids.documentGeneratorTemplate.value) || activeDocumentTemplates()[0];
  if (!template) return;
  const studentLabel = ids.documentGeneratorStudent?.closest("label");
  const beneficiaryLabel = ids.documentGeneratorBeneficiary?.closest("label");
  if (studentLabel) studentLabel.hidden = template.audience === "staff" || template.audience === "general";
  if (beneficiaryLabel) beneficiaryLabel.hidden = template.audience === "student" || template.audience === "general";
}

function printTemplateDocument(templateKey, options = {}) {
  const template = templateByKey(templateKey);
  if (!template) {
    showToast("ModÃ¨le introuvable");
    return;
  }
  const context = documentTemplateContext(options);
  const stampSrc = normalizeLogoData(state.center?.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(template.title)}
      <div class="custom-document-body">
        ${renderTemplateContent(template.content, context)}
      </div>
      <div class="document-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <strong>Signature et cachet</strong>
      </div>
    </section>
  `;
  showPrintPreview();
}

function printSelectedDocumentTemplate() {
  const templateKey = ids.documentGeneratorTemplate?.value;
  if (!templateKey) {
    showToast("Choisissez un modÃ¨le");
    return;
  }
  printTemplateDocument(templateKey, {
    studentId: Number(ids.documentGeneratorStudent?.value || 0),
    beneficiaryValue: ids.documentGeneratorBeneficiary?.value || ""
  });
}

function renderDocumentTemplates() {
  if (!ids.documentTemplateList) return;
  ensureDocumentTemplates();
  const templates = [...state.documentTemplates].sort((a, b) =>
    String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title))
  );
  ids.documentTemplateList.innerHTML = templates.map(template => `
    <article class="document-template-card ${template.status === "archive" ? "is-archived" : ""}">
      <div>
        <strong>${escapeHtml(template.title)}</strong>
        <span>${escapeHtml(template.category)} Â· ${documentAudienceLabel(template.audience)} Â· ${template.status === "archive" ? "ArchivÃ©" : "Actif"}</span>
      </div>
      <div class="row-actions">
        <button class="chip-button" type="button" data-action="edit-document-template" data-key="${escapeHtml(template.key)}">Modifier</button>
        <button class="chip-button danger" type="button" data-action="delete-document-template" data-key="${escapeHtml(template.key)}">${template.locked ? "Archiver" : "Supprimer"}</button>
      </div>
    </article>
  `).join("") || `<p class="muted">Aucun modÃ¨le de document.</p>`;
}

function documentAudienceLabel(audience) {
  if (audience === "staff") return "Personnel";
  if (audience === "general") return "GÃ©nÃ©ral";
  return "Ã‰tudiant";
}

function slugifyTemplateKey(value) {
  const base = normalizeSearchText(value)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "modele-document";
  let key = base;
  let index = 2;
  while (state.documentTemplates.some(template => template.key === key)) {
    key = `${base}-${index}`;
    index += 1;
  }
  return key;
}

function resetDocumentTemplateForm() {
  if (!ids.documentTemplateTitle) return;
  ids.documentTemplateEditKey.value = "";
  ids.documentTemplateTitle.value = "";
  ids.documentTemplateCategory.value = "Attestation";
  ids.documentTemplateAudience.value = "student";
  ids.documentTemplateStatus.value = "active";
  ids.documentTemplateContent.value = "";
}

function editDocumentTemplate(key) {
  const template = templateByKey(key);
  if (!template || !ids.documentTemplateTitle) return;
  ids.documentTemplateEditKey.value = template.key;
  ids.documentTemplateTitle.value = template.title || "";
  ids.documentTemplateCategory.value = template.category || "Attestation";
  ids.documentTemplateAudience.value = template.audience || "student";
  ids.documentTemplateStatus.value = template.status || "active";
  ids.documentTemplateContent.value = template.content || "";
  ids.documentTemplateTitle.focus();
}

function saveDocumentTemplate(event) {
  event.preventDefault();
  const editKey = ids.documentTemplateEditKey.value;
  const payload = {
    title: ids.documentTemplateTitle.value.trim(),
    category: ids.documentTemplateCategory.value,
    audience: ids.documentTemplateAudience.value,
    status: ids.documentTemplateStatus.value,
    content: ids.documentTemplateContent.value.trim()
  };
  if (!payload.title || !payload.content) return;

  const existing = templateByKey(editKey);
  if (existing) {
    Object.assign(existing, payload);
    showToast("ModÃ¨le modifiÃ©");
  } else {
    state.documentTemplates.push({
      key: slugifyTemplateKey(payload.title),
      locked: false,
      ...payload
    });
    showToast("ModÃ¨le ajoutÃ©");
  }

  saveState();
  resetDocumentTemplateForm();
  syncSelects();
  renderDocumentTemplates();
}

function deleteDocumentTemplate(key) {
  const template = templateByKey(key);
  if (!template) return;
  if (template.locked) {
    template.status = "archive";
    showToast("ModÃ¨le archivÃ©");
  } else {
    state.documentTemplates = state.documentTemplates.filter(item => item.key !== key);
    showToast("ModÃ¨le supprimÃ©");
  }
  saveState();
  resetDocumentTemplateForm();
  syncSelects();
  renderDocumentTemplates();
}

function renderSettings() {
  renderUserAccessSettings();
  renderLoginHistory();
  renderAuditLog();
  setCleanupModeStatus();
  if (!canAccessView("settings")) return;

  document.getElementById("centerName").value = state.center?.name || "CFP EREXIT";
  document.getElementById("centerSubtitle").value = state.center?.subtitle || "Centre de Formation Professionnelle";
  document.getElementById("centerPhone").value = state.center?.phone || "";
  document.getElementById("centerEmail").value = state.center?.email || "";
  document.getElementById("centerAddress").value = state.center?.address || "";
  ensurePaymentMotifs();
  ids.paymentMotifsSettings.innerHTML = state.paymentMotifs.map(motif => `
    <div class="motif-row">
      <input type="text" value="${escapeHtml(motif.label)}" data-motif-label="${escapeHtml(motif.key)}" required>
      <input type="number" min="0" step="500" value="${Number(motif.amount || 0)}" data-motif-amount="${escapeHtml(motif.key)}">
      <button class="chip-button danger" type="button" data-action="delete-motif" data-key="${escapeHtml(motif.key)}" ${motif.key === "scolarite" || motif.key === MAKEUP_MOTIF_KEY ? "disabled" : ""}>Supprimer</button>
    </div>
  `).join("");

  ids.courseFeesSettings.innerHTML = state.courses.map(course => `
    <div class="fee-row">
      <div>
        <strong>${escapeHtml(course.name)}</strong>
        <span>${escapeHtml(course.code || "")}</span>
      </div>
      <label>
        <span>Inscription</span>
        <input type="number" min="0" step="1" value="${Number(course.registrationFee || 0)}" data-course-registration-fee="${course.id}">
      </label>
      <label>
        <span>Formation</span>
        <input type="number" min="0" step="1" value="${Number(course.trainingFee || 0)}" data-course-training-fee="${course.id}">
      </label>
      <label>
        <span>MensualitÃ©</span>
        <input type="number" min="0" step="1" value="${Number(course.monthlyFee || 0)}" data-course-monthly-fee="${course.id}">
      </label>
    </div>
  `).join("") || `<p class="muted">Aucune formation enregistrÃ©e.</p>`;

  renderDocumentTemplates();
  renderRequiredDocumentsSettings();
}

function makeupSubjectsForEnrollment(enrollment) {
  if (!enrollment) return [];
  return state.evaluations.flatMap(evaluation => {
    if (Number(evaluation.groupId) !== Number(enrollment.groupId)) return [];
    const grade = (evaluation.grades || []).find(item => Number(item.studentId) === Number(enrollment.studentId));
    if (!grade || !gradeNeedsMakeup(grade.score, evaluation.maxScore || 20)) return [];
    return [{
      evaluationId: evaluation.id,
      title: evaluation.title || "MatiÃ¨re",
      score: grade.score,
      maxScore: evaluation.maxScore || 20
    }];
  });
}

function makeupPaidForEnrollment(enrollmentId, excludePaymentId = 0) {
  return paymentsForEnrollment(enrollmentId)
    .filter(payment => Number(payment.id) !== Number(excludePaymentId) && isMakeupMotifKey(payment.reasonKey))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function makeupDueForEnrollment(enrollment, excludePaymentId = 0) {
  const expected = makeupSubjectsForEnrollment(enrollment).length * MAKEUP_FEE;
  return Math.max(0, expected - makeupPaidForEnrollment(enrollment?.id, excludePaymentId));
}

function renderRequiredDocumentsSettings() {
  if (!ids.requiredDocumentsSettings) return;
  const labels = [
    ["student", "Ã‰tudiants"],
    ["trainer", "Formateurs"],
    ["staff", "Personnel"]
  ];
  const required = normalizeRequiredDocuments(state.requiredDocuments);
  ids.requiredDocumentsSettings.innerHTML = labels.map(([kind, label]) => `
    <label>
      <span>${escapeHtml(label)}</span>
      <textarea rows="3" data-required-documents="${kind}" placeholder="Un document par ligne">${escapeHtml(required[kind].join("\n"))}</textarea>
    </label>
  `).join("");
}

function renderAuditLog() {
  if (!ids.auditLogTable || !ids.auditLogCount) return;
  if (!isAdmin()) {
    ids.auditLogTable.innerHTML = "";
    ids.auditLogCount.textContent = "0 action(s)";
    return;
  }
  const rows = [...(state.auditLog || [])]
    .sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")))
    .slice(0, 120);
  ids.auditLogCount.textContent = `${rows.length} action(s)`;
  ids.auditLogTable.innerHTML = rows.map(entry => `
    <tr>
      <td>${escapeHtml(formatDateTime(new Date(entry.at || Date.now())))}</td>
      <td>${escapeHtml(entry.section || "-")}</td>
      <td>${escapeHtml(entry.action || "-")}</td>
      <td>${escapeHtml(entry.detail || "-")}</td>
      <td>${escapeHtml(entry.operator || entry.operatorEmail || "-")}</td>
    </tr>
  `).join("") || emptyRow(5, "Aucune action enregistrÃ©e.");
}

function renderLoginHistory() {
  if (!ids.loginHistoryTable || !ids.loginHistoryCount) return;
  if (!isAdmin()) {
    ids.loginHistoryTable.innerHTML = "";
    ids.loginHistoryCount.textContent = "0 action(s)";
    return;
  }

  const rows = [...(state.loginHistory || [])]
    .sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")))
    .slice(0, 80);
  ids.loginHistoryCount.textContent = `${rows.length} action(s)`;
  ids.loginHistoryTable.innerHTML = rows.map(entry => `
    <tr>
      <td>${escapeHtml(formatDateTime(new Date(entry.at || Date.now())))}</td>
      <td>${escapeHtml(entry.identifier || entry.email || "-")}</td>
      <td>${escapeHtml(entry.userName || "-")}</td>
      <td><span class="status ${entry.success ? "active" : "inactive"}">${entry.success ? "RÃ©ussie" : "RefusÃ©e"}</span></td>
      <td>${escapeHtml(entry.ip || "-")}</td>
    </tr>
  `).join("") || emptyRow(5, "Aucune connexion enregistrÃ©e.");
}

function renderUserAccessSettings() {
  if (!ids.userAccessSettings) return;
  if (!isAdmin()) {
    ids.userAccessSettings.innerHTML = "";
    if (ids.passwordResetRequests) ids.passwordResetRequests.innerHTML = "";
    return;
  }

  renderPasswordResetRequests();
  if (!state.users.length) {
    ids.userAccessSettings.innerHTML = `
      <p class="muted password-reset-empty">
        Liste des utilisateurs non chargee. Rechargez la page avant de modifier les acces.
      </p>
    `;
    return;
  }

  const users = state.users;
  ids.userAccessSettings.innerHTML = users.map(user => {
    const role = user.role || "SecrÃ©taire";
    const isUserAdmin = roleCode(role) === "administrateur" || roleCode(role) === "admin";
    const permissions = isUserAdmin ? ACCESS_VIEWS : permissionsForUser(user);
    const disabled = isUserAdmin ? "disabled" : "";
    return `
      <article class="access-card" data-user-access-row="${user.id || ""}">
        <div class="access-card-header">
          <strong>${escapeHtml(user.name || "Nouvel utilisateur")}</strong>
          ${isUserAdmin ? `<span class="status active">AccÃ¨s total</span>` : `<button class="chip-button danger" type="button" data-action="delete-user-access" data-id="${user.id || ""}">Desactiver</button>`}
        </div>
        <div class="access-user-grid">
          <label>
            <span>Nom</span>
            <input type="text" value="${escapeHtml(user.name || "")}" data-user-name="${user.id || ""}" required>
          </label>
          <label>
            <span>Identifiant</span>
            <input type="text" value="${escapeHtml(user.username || "")}" data-user-username="${user.id || ""}" required>
          </label>
          <label>
            <span>Email</span>
            <input type="email" value="${escapeHtml(user.email || "")}" data-user-email="${user.id || ""}" required>
          </label>
          <label>
            <span>Profil</span>
            <select data-user-role="${user.id || ""}" ${isUserAdmin ? "disabled" : ""}>
              ${(isUserAdmin ? ["Administrateur"] : ROLE_OPTIONS.filter(option => option !== "Administrateur")).map(option => `<option value="${escapeHtml(option)}" ${option === role ? "selected" : ""}>${escapeHtml(option)}</option>`).join("")}
            </select>
          </label>
          <label>
            <span>Statut</span>
            <select data-user-status="${user.id || ""}" ${isUserAdmin ? "disabled" : ""}>
              <option value="active" ${(user.status || "active") === "active" ? "selected" : ""}>Actif</option>
              <option value="inactive" ${user.status === "inactive" ? "selected" : ""}>Inactif</option>
              <option value="suspended" ${user.status === "suspended" ? "selected" : ""}>Suspendu</option>
            </select>
          </label>
          <label>
            <span>Nouveau mot de passe / rÃ©initialisation</span>
            <input type="password" data-user-password="${user.id || ""}" placeholder="${user.id ? "Laisser vide pour garder" : "Minimum 8 caractÃ¨res forts"}">
          </label>
          <label class="password-toggle-line">
            <input type="checkbox" data-toggle-password="${user.id || ""}">
            <span>Afficher</span>
          </label>
          ${user.mustChangePassword ? `<p class="muted">Changement de mot de passe requis.</p>` : ""}
        </div>
        <div class="access-checks">
          ${MANAGED_ACCESS_VIEWS.map(view => `
            <label>
              <input type="checkbox" value="${escapeHtml(view)}" data-user-permission="${user.id || ""}" ${permissions.includes(view) ? "checked" : ""} ${disabled}>
              <span>${escapeHtml(VIEW_LABELS[view])}</span>
            </label>
          `).join("")}
        </div>
      </article>
    `;
  }).join("");
}

function strongPassword(value = "") {
  const password = String(value || "");
  const weak = ["admin123", "secret123", "compta123", "formateur123", "changeme123", "123456", "password"];
  return password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /\d/.test(password) &&
    /[^A-Za-z0-9]/.test(password) &&
    !weak.includes(password.toLowerCase());
}

function showPasswordChangeModal() {
  if (!ids.passwordChangeModal || !ids.passwordChangeForm) return;
  ids.passwordChangeForm.reset();
  ids.passwordChangeError.textContent = "";
  ids.passwordChangeModal.hidden = false;
  window.setTimeout(() => ids.currentPasswordChange?.focus(), 80);
}

function hidePasswordChangeModal() {
  if (!ids.passwordChangeModal) return;
  ids.passwordChangeModal.hidden = true;
  ids.passwordChangeError.textContent = "";
}

function enforcePasswordChangeIfNeeded() {
  if (currentUser?.mustChangePassword) {
    showPasswordChangeModal();
  } else {
    hidePasswordChangeModal();
  }
}

async function changeOwnPassword(event) {
  event.preventDefault();
  ids.passwordChangeError.textContent = "";
  const currentPassword = ids.currentPasswordChange.value;
  const newPassword = ids.newPasswordChange.value;
  const confirmPassword = ids.confirmPasswordChange.value;

  if (newPassword !== confirmPassword) {
    ids.passwordChangeError.textContent = "Les deux nouveaux mots de passe ne correspondent pas.";
    return;
  }
  if (!strongPassword(newPassword)) {
    ids.passwordChangeError.textContent = "Mot de passe trop faible : 8 caracteres, majuscule, minuscule, chiffre et caractere special.";
    return;
  }

  const submitButton = event.currentTarget.querySelector("button[type='submit']");
  submitButton.disabled = true;
  try {
    const result = await apiRequest("/api/change-password", {
      method: "POST",
      body: JSON.stringify({ currentPassword, newPassword })
    });
    currentUser = result.user;
    hidePasswordChangeModal();
    renderSession();
    showToast("Mot de passe mis a jour");
  } catch (error) {
    ids.passwordChangeError.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
}

function activeTrainers() {
  return state.trainers.filter(trainer => (trainer.status || "actif") === "actif");
}

function normalizeUsername(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function roleCode(role = "") {
  return String(role || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function renderPasswordResetRequests() {
  if (!ids.passwordResetRequests) return;
  const pending = (state.passwordResetRequests || [])
    .filter(request => request.status !== "done")
    .sort((a, b) => String(b.requestedAt || "").localeCompare(String(a.requestedAt || "")));

  if (!pending.length) {
    ids.passwordResetRequests.innerHTML = `<p class="muted password-reset-empty">Aucune demande de rÃ©initialisation en attente.</p>`;
    return;
  }

  ids.passwordResetRequests.innerHTML = `
    <div class="password-reset-list">
      <h4>Demandes de rÃ©initialisation</h4>
      ${pending.map(request => {
        const user = state.users.find(item => item.email === request.email);
        return `
          <article class="password-reset-request">
            <div>
              <strong>${escapeHtml(user?.name || request.email)}</strong>
              <span>${escapeHtml(request.email)} Â· ${formatDateTime(new Date(request.requestedAt || Date.now()))}</span>
            </div>
            <button class="chip-button success" type="button" data-action="mark-password-reset-done" data-id="${request.id}">Marquer traitÃ©</button>
          </article>
        `;
      }).join("")}
    </div>
  `;
}

function balances() {
  return state.enrollments
    .map(enrollment => {
      const student = getStudent(enrollment.studentId);
      const course = getCourse(enrollment.courseId);
      const paid = paidAmount(enrollment.id);
      const balance = balanceForEnrollment(enrollment);
      const tuitionExpected = tuitionExpectedForEnrollment(enrollment);
      return {
        enrollment,
        student: fullName(student),
        course: course?.name || "-",
        sessionType: groupSessionLabel(getGroup(enrollment.groupId)),
        finalAmount: Number(enrollment.finalAmount || 0),
        tuitionExpected,
        paid,
        balance
      };
    })
    .filter(item => item.balance > 0)
    .sort((a, b) => b.balance - a.balance);
}

function requiredAnnexMotifs() {
  ensurePaymentMotifs();
  return state.paymentMotifs.filter(motif => !isTuitionMotifKey(motif.key) && Number(motif.amount || 0) > 0);
}

function paymentAlerts() {
  const alerts = [];
  const annexMotifs = requiredAnnexMotifs();

  state.enrollments
    .filter(enrollment => !suppressPaymentTrackingForEnrollment(enrollment))
    .forEach(enrollment => {
      const student = getStudent(enrollment.studentId);
      const course = getCourse(enrollment.courseId);
      const group = getGroup(enrollment.groupId);
      const studentLabel = fullName(student);
      const courseLabel = course?.name || "-";
      const lastTuitionDate = lastPaymentDateForEnrollment(enrollment.id, isTuitionPayment);
      const tuitionBalance = balanceForEnrollment(enrollment);

      if (tuitionBalance > 0) {
        const days = daysSince(lastTuitionDate || enrollment.date);
        const noTuitionPayment = !lastTuitionDate;
        const severity = noTuitionPayment || days >= 30 ? "danger" : days >= 20 ? "warning" : "info";
        alerts.push({
          enrollmentId: enrollment.id,
          reasonKey: "scolarite",
          severity,
          priority: severity === "danger" ? 1 : severity === "warning" ? 2 : 3,
          student: studentLabel,
          detail: courseLabel,
          message: noTuitionPayment ? "Premier paiement scolaritÃ© attendu" : days >= 30 ? "ScolaritÃ© en retard" : days >= 20 ? "Relance scolaritÃ© proche" : "Reste scolaritÃ© Ã  suivre",
          amount: tuitionBalance,
          lastPaymentDate: lastTuitionDate,
          referenceDate: lastTuitionDate || enrollment.date,
          sessionType: groupSessionLabel(group)
        });
      }

      annexMotifs.forEach(motif => {
        const paid = paymentsForEnrollment(enrollment.id)
          .some(payment => String(payment.reasonKey || "") === motif.key);
        if (paid) return;
        const days = daysSince(enrollment.date);
        alerts.push({
          enrollmentId: enrollment.id,
          reasonKey: motif.key,
          severity: days >= 30 ? "warning" : "info",
          priority: days >= 30 ? 2 : 4,
          student: studentLabel,
          detail: courseLabel,
          message: `Frais annexe non payÃ© : ${motif.label}`,
          amount: Number(motif.amount || 0),
          lastPaymentDate: "",
          referenceDate: enrollment.date,
          sessionType: groupSessionLabel(group)
        });
      });
    });

  return alerts.sort((a, b) =>
    a.priority - b.priority ||
    b.amount - a.amount ||
    String(a.referenceDate).localeCompare(String(b.referenceDate))
  );
}

function emptyRow(colspan, label) {
  return `<tr><td colspan="${colspan}" class="muted">${label}</td></tr>`;
}

function syncSelects() {
  fillSelect("groupCourse", state.courses, course => course.name, "Choisir une formation");
  fillSelect("groupTrainer", activeTrainers(), trainer => trainerName(trainer), "Choisir un formateur");
  fillSelectWithAll("groupCourseFilter", state.courses, course => course.name, "Toutes formations");
  fillSelectWithAll("enrollmentCourseFilter", state.courses, course => course.name, "Toutes formations");
  fillSelectWithAll("studentCourseFilter", state.courses, course => course.name, "Toutes les formations");
  fillSelect("studentDesiredCourse", state.courses, course => course.name, "Choisir une formation");
  fillSelect("enrollmentStudent", state.students, student => `${fullName(student)} - ${student.matricule}`, "Choisir un Ã©tudiant");
  fillSelect("enrollmentCourse", state.courses, course => course.name, "Choisir une formation");
  syncEnrollmentGroups();
  fillSelect("paymentEnrollment", state.enrollments.filter(enrollment => !suppressPaymentTrackingForEnrollment(enrollment)), enrollmentLabel, "Choisir une inscription / Ã©tudiant");
  syncPaymentReasons();
  fillSelect("attendanceGroup", state.groups, group => group.name);
  fillSelect("evaluationGroup", state.groups, group => group.name);
  fillSelect("evaluationTrainer", state.trainers, trainer => trainerName(trainer));
  const payrollOptions = [
    ...state.staffMembers
      .filter(member => member.status !== "archive")
      .map(member => ({ id: payrollBeneficiaryValue("staff", member.id), label: `${staffName(member)} - ${member.role || "Personnel"}` })),
    ...state.trainers
      .filter(trainer => trainer.status !== "archive")
      .map(trainer => ({ id: payrollBeneficiaryValue("trainer", trainer.id), label: `${trainerName(trainer)} - Formateur` }))
  ];
  fillSelect("staffPaymentStaff", payrollOptions, option => option.label);
  fillSelect("individualReportStudent", state.students, student => `${fullName(student)} - ${student.matricule}`);
  fillSelect("documentGeneratorStudent", state.students, student => `${fullName(student)} - ${student.matricule}`);
  fillSelect("documentGeneratorTemplate", activeDocumentTemplates(), template => `${template.title} - ${template.category}`);
  fillSelect("documentGeneratorBeneficiary", payrollOptions, option => option.label);

  document.getElementById("enrollmentDate").value ||= today();
  document.getElementById("paymentDate").value ||= today();
  document.getElementById("cashDate").value ||= today();
  document.getElementById("attendanceDate").value ||= today();
  document.getElementById("trainerAttendanceDate").value ||= today();
  document.getElementById("staffPaymentDate").value ||= today();
  document.getElementById("staffPaymentPeriod").value ||= today().slice(0, 7);
  document.getElementById("evaluationDate").value ||= today();
}

function fillSelect(id, items, labeler, placeholder = "") {
  const select = document.getElementById(id);
  if (!select) return;
  const oldValue = select.value;
  select.innerHTML = `${placeholder ? `<option value="">${escapeHtml(placeholder)}</option>` : ""}` +
    items.map(item => `<option value="${item.id}">${escapeHtml(labeler(item))}</option>`).join("");
  if (items.some(item => String(item.id) === oldValue)) {
    select.value = oldValue;
  } else if (placeholder) {
    select.value = "";
  }
}

function fillSelectWithAll(id, items, labeler, allLabel) {
  const select = document.getElementById(id);
  if (!select) return;
  const oldValue = select.value;
  select.innerHTML = `<option value="">${escapeHtml(allLabel)}</option>` +
    items.map(item => `<option value="${item.id}">${escapeHtml(labeler(item))}</option>`).join("");
  if ([...select.options].some(option => option.value === oldValue)) {
    select.value = oldValue;
  }
}

function syncPaymentReasons() {
  ensurePaymentMotifs();
  const select = document.getElementById("paymentReason");
  const oldValue = select.value;
  select.innerHTML = state.paymentMotifs
    .map(motif => `<option value="${escapeHtml(motif.key)}">${escapeHtml(motif.label)}</option>`)
    .join("");

  if ([...select.options].some(option => option.value === oldValue)) {
    select.value = oldValue;
  }
  updatePaymentReasonFields();
}

function syncEnrollmentGroups() {
  const courseId = Number(document.getElementById("enrollmentCourse").value || 0);
  if (!courseId) {
    fillSelect("enrollmentGroup", [], group => group.name, "Choisir d'abord une formation");
    return;
  }
  const groups = state.groups.filter(group => Number(group.courseId) === courseId);
  fillSelect("enrollmentGroup", groups, group => `${group.name} - ${groupSessionLabel(group)}`, "Choisir une promotion");
}

function updateEvaluationStudents(existingGrades = null) {
  const groupId = Number(document.getElementById("evaluationGroup").value);
  const grades = existingGrades || [];
  const gradeByStudent = new Map(grades.map(grade => [Number(grade.studentId), grade]));
  const students = studentsForGroup(groupId);

  ids.gradeEntryList.innerHTML = students.map(student => {
    const grade = gradeByStudent.get(Number(student.id)) || {};
    const needsMakeup = gradeNeedsMakeup(grade.score, Number(document.getElementById("evaluationMaxScore").value || 20));
    return `
      <div class="grade-entry-row">
        <div class="student-line">
          <strong>${escapeHtml(fullName(student))}</strong>
          <span>${escapeHtml(student.matricule)}</span>
          <span class="grade-rule ${needsMakeup ? "makeup" : ""}">${escapeHtml(gradeStatusLabel(grade.score, Number(document.getElementById("evaluationMaxScore").value || 20)))}${needsMakeup ? ` - ${formatMoney(MAKEUP_FEE)}` : ""}</span>
        </div>
        <input type="number" min="0" step="0.25" placeholder="Note" value="${escapeHtml(grade.score ?? "")}" data-grade-student="${student.id}">
        <input type="text" placeholder="Appreciation" value="${escapeHtml(grade.appreciation || "")}" data-grade-appreciation="${student.id}">
      </div>
    `;
  }).join("") || `<p class="muted">Aucun Ã©tudiant inscrit dans cette promotion.</p>`;
}

function enrollmentLabel(enrollment) {
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const balance = balanceForEnrollment(enrollment);
  return `${fullName(student)} - ${course?.name || "-"} - reste scolaritÃ© ${formatMoney(balance)}`;
}

function attendanceStatusLabel(status) {
  if (status === "present") return "PrÃ©sent";
  if (status === "absent") return "Absent";
  if (status === "retard") return "Retard";
  return status || "-";
}

function showLoginChoice() {
  ids.loginChoiceView.hidden = false;
  document.getElementById("loginForm").hidden = true;
  document.getElementById("studentPortalLoginForm").hidden = true;
  ids.loginError.textContent = "";
  ids.studentPortalLoginError.textContent = "";
  hidePasswordResetBox();
}

function showLoginFormPanel(type) {
  ids.loginChoiceView.hidden = true;
  document.getElementById("loginForm").hidden = type !== "personnel";
  document.getElementById("studentPortalLoginForm").hidden = type !== "student";
  ids.loginError.textContent = "";
  ids.studentPortalLoginError.textContent = "";
  hidePasswordResetBox();
  const focusTarget = type === "student" ? "studentPortalMatricule" : "loginEmail";
  window.setTimeout(() => document.getElementById(focusTarget)?.focus(), 60);
}

function showPasswordResetBox() {
  ids.loginError.textContent = "";
  ids.passwordResetMessage.textContent = "";
  const loginValue = document.getElementById("loginEmail").value.trim();
  ids.passwordResetEmail.value = loginValue.includes("@") ? loginValue : "";
  ids.passwordResetBox.hidden = false;
  window.setTimeout(() => ids.passwordResetEmail.focus(), 60);
}

function hidePasswordResetBox() {
  if (!ids.passwordResetBox) return;
  ids.passwordResetBox.hidden = true;
  ids.passwordResetMessage.textContent = "";
}

async function requestPasswordReset() {
  const email = ids.passwordResetEmail.value.trim().toLowerCase();
  ids.passwordResetMessage.textContent = "";
  if (!email) {
    ids.passwordResetMessage.textContent = "Saisissez l'email du compte.";
    return;
  }

  try {
    const result = await apiRequest("/api/password-reset-request", {
      method: "POST",
      body: JSON.stringify({ email })
    });
    ids.passwordResetMessage.textContent = result.message || "Demande envoyÃ©e Ã  l'administrateur.";
  } catch (error) {
    ids.passwordResetMessage.textContent = error.message;
  }
}

function showStudentPortal(data) {
  studentPortalData = data;
  currentUser = null;
  stopServerSync();
  hidePasswordChangeModal();
  if (ids.studentPortal) ids.studentPortal.hidden = false;
  document.body.classList.remove("loading", "needs-login");
  document.body.classList.add("student-portal-mode");
  renderStudentPortal(data);
}

function showLoginScreen() {
  studentPortalData = null;
  stopServerSync();
  hidePasswordChangeModal();
  if (ids.publicRegistration) ids.publicRegistration.hidden = true;
  if (ids.studentPortal) ids.studentPortal.hidden = true;
  showLoginChoice();
  document.body.classList.remove("loading", "student-portal-mode", "public-registration-mode");
  document.body.classList.add("needs-login");
}

function showPublicRegistration() {
  stopServerSync();
  hidePasswordChangeModal();
  if (ids.loginScreen) ids.loginScreen.hidden = true;
  if (ids.studentPortal) ids.studentPortal.hidden = true;
  if (ids.publicRegistration) ids.publicRegistration.hidden = false;
  document.body.classList.remove("loading", "needs-login", "student-portal-mode");
  document.body.classList.add("public-registration-mode");
}

function syncOnlineRegistrationGroups() {
  return;
}

async function loadOnlineRegistrationOptions() {
  const result = await apiRequest("/api/online-registration-options");
  onlineRegistrationOptions = {
    courses: Array.isArray(result.courses) ? result.courses : [],
    groups: []
  };
  if (ids.onlineCourse) {
    ids.onlineCourse.innerHTML = `<option value="">Choisir une formation</option>` +
      onlineRegistrationOptions.courses.map(course => (
        `<option value="${course.id}">${escapeHtml(course.name)}${course.code ? ` - ${escapeHtml(course.code)}` : ""}</option>`
      )).join("");
    ids.onlineCourse.value = "";
  }
}

function onlineRegistrationPayload() {
  return {
    lastName: document.getElementById("onlineLastName").value.trim().toUpperCase(),
    firstName: document.getElementById("onlineFirstName").value.trim(),
    gender: document.getElementById("onlineGender").value,
    birthDate: document.getElementById("onlineBirthDate").value,
    birthPlace: document.getElementById("onlineBirthPlace")?.value.trim() || "",
    nationality: document.getElementById("onlineNationality")?.value.trim() || "",
    phone: document.getElementById("onlinePhone").value.trim(),
    email: document.getElementById("onlineEmail").value.trim(),
    address: document.getElementById("onlineAddress").value.trim(),
    district: document.getElementById("onlineDistrict")?.value.trim() || "",
    city: document.getElementById("onlineCity")?.value.trim() || "",
    country: document.getElementById("onlineCountry")?.value.trim() || "",
    studyLevel: document.getElementById("onlineStudyLevel")?.value.trim() || "",
    profession: document.getElementById("onlineProfession")?.value.trim() || "",
    courseId: Number(document.getElementById("onlineCourse").value || 0),
    preferredCourseType: document.getElementById("onlinePreferredCourseType")?.value || "",
    emergencyName: document.getElementById("onlineEmergencyName").value.trim(),
    emergencyPhone: document.getElementById("onlineEmergencyPhone").value.trim(),
    paymentResponsible: document.getElementById("onlinePaymentResponsible")?.value.trim() || "",
    paymentResponsiblePhone: document.getElementById("onlinePaymentResponsiblePhone")?.value.trim() || "",
    source: document.getElementById("onlineSource")?.value || "site-web",
    message: document.getElementById("onlineMessage").value.trim()
  };
}

async function submitOnlineRegistration(event) {
  event.preventDefault();
  const form = event.currentTarget;
  ids.onlineRegistrationError.textContent = "";
  ids.onlineRegistrationSuccess.hidden = true;
  const submitButton = form.querySelector("button[type='submit']");
  if (submitButton) submitButton.disabled = true;

  try {
    const payload = onlineRegistrationPayload();
    if (!payload.lastName || !payload.firstName || !payload.phone || !payload.courseId) {
      throw new Error("Nom, prÃ©nom, tÃ©lÃ©phone et formation sont obligatoires.");
    }
    const result = await apiRequest("/api/online-registration", {
      method: "POST",
      body: JSON.stringify(payload)
    });
    form.reset();
    ids.onlineRegistrationSuccess.hidden = false;
    ids.onlineRegistrationSuccess.innerHTML = `
      Inscription envoyÃ©e avec succÃ¨s.<br>
      Numero de demande : <strong>${escapeHtml(result.requestNumber || "-")}</strong><br>
      AccÃ¨s Ã©tudiant : utilisez ce matricule avec votre numÃ©ro de tÃ©lÃ©phone.
    `;
  } catch (error) {
    ids.onlineRegistrationError.textContent = error.message;
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
}

function renderStudentPortal(data = studentPortalData) {
  if (!data || !ids.studentPortal) return;
  const student = data.student || {};
  const enrollments = data.enrollments || [];
  const payments = data.payments || [];
  const grades = data.grades || [];
  const attendance = data.attendance || [];
  const tuitionPaid = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.tuitionPaid || 0), 0);
  const annexPaid = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.annexPaid || 0), 0);
  const balance = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.balance || 0), 0);
  const numericGrades = grades
    .map(row => Number(row.score) * 20 / Number(row.maxScore || 20))
    .filter(score => Number.isFinite(score));
  const average = numericGrades.length
    ? `${(numericGrades.reduce((sum, score) => sum + score, 0) / numericGrades.length).toFixed(2)} / 20`
    : "-";
  const makeupGrades = grades.filter(row => row.needsMakeup);
  const makeupTotal = makeupGrades.length * MAKEUP_FEE;

  ids.studentPortalName.textContent = student.fullName || fullName(student);
  ids.studentPortalMeta.textContent = `${student.matricule || "-"} Â· ${student.status || "statut non prÃ©cisÃ©"}`;
  ids.studentPortalSummary.innerHTML = [
    ["ScolaritÃ© payÃ©e", formatMoney(tuitionPaid)],
    ["Frais annexes payÃ©s", formatMoney(annexPaid)],
    ["Reste scolaritÃ©", formatMoney(balance)],
    ["Moyenne notes", average],
    ["MatiÃ¨res non validÃ©es", String(makeupGrades.length)],
    ["Rattrapage Ã  prÃ©voir", formatMoney(makeupTotal)]
  ].map(([label, value]) => `
    <article class="stat-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </article>
  `).join("");

  const portalCompletion = student.documentCompletion || { completed: true, missing: [] };
  const portalPhoto = normalizeLogoData(student.photoData || "");
  ids.studentPortalInfo.innerHTML = `
    <div class="student-portal-profile">
      <div class="student-portal-photo">
        ${portalPhoto ? `<img src="${escapeHtml(portalPhoto)}" alt="Photo ${escapeHtml(student.fullName || fullName(student))}">` : "Photo"}
      </div>
      <div>
        <strong>${escapeHtml(student.fullName || fullName(student))}</strong>
        <span class="status ${portalCompletion.completed ? "active" : "inactive"}">
          ${portalCompletion.completed ? "Dossier complet" : "Dossier incomplet"}
        </span>
        <p class="missing-documents">${escapeHtml(missingDocumentsText(portalCompletion))}</p>
      </div>
    </div>
    ${[
      ["Matricule", student.matricule || "-"],
      ["Statut", student.status || "-"],
      ["TÃ©lÃ©phone", student.phone || "-"],
      ["Email", student.email || "-"],
      ["Adresse", student.address || "-"],
      ["Date de naissance", formatDate(student.birthDate)],
      ["Personne Ã  contacter", student.emergencyName || "-"],
      ["TÃ©lÃ©phone personne Ã  contacter", student.emergencyPhone || "-"],
      ["Documents", personDocumentSummary(student)]
    ].map(([label, value]) => `
      <div class="detail-row">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(value)}</strong>
      </div>
    `).join("")}
  `;

  ids.studentPortalEnrollments.innerHTML = enrollments.map(enrollment => `
    <tr>
      <td>
        <strong>${escapeHtml(enrollment.courseName || "-")}</strong><br>
        <span class="muted">${escapeHtml(enrollment.groupName || enrollment.courseCode || "-")}</span>
      </td>
      <td>${escapeHtml(enrollment.sessionType || "-")}</td>
      <td>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</td>
      <td>${formatMoney(enrollment.tuitionPaid)}</td>
      <td><strong>${formatMoney(enrollment.balance)}</strong></td>
    </tr>
  `).join("") || `<tr><td colspan="5">Aucune inscription enregistrÃ©e.</td></tr>`;

  ids.studentPortalPayments.innerHTML = payments.map(payment => `
    <tr>
      <td>${formatDate(payment.date)}</td>
      <td>${escapeHtml(payment.receiptNumber || "-")}</td>
      <td>
        ${escapeHtml(payment.reason || "-")}<br>
        <span class="muted">${escapeHtml(payment.category || "")}</span>
      </td>
      <td><strong>${formatMoney(payment.amount)}</strong></td>
      <td>${escapeHtml(payment.method || "-")}</td>
    </tr>
  `).join("") || `<tr><td colspan="5">Aucun paiement enregistrÃ©.</td></tr>`;

  const makeupSubjectsText = makeupGrades
    .map(row => row.title || "MatiÃ¨re sans titre")
    .join(", ");
  const makeupNotice = makeupGrades.length
    ? `<tr class="student-makeup-notice"><td colspan="5">
        <strong>Notification : ${makeupGrades.length} matiÃ¨re(s) non validÃ©e(s).</strong>
        Vous devez faire un rattrapage pour : ${escapeHtml(makeupSubjectsText)}.
        Montant Ã  prÃ©voir : ${formatMoney(makeupTotal)} au total (${formatMoney(MAKEUP_FEE)} par matiÃ¨re).
      </td></tr>`
    : "";
  const gradeRows = grades.map(row => `
    <tr>
      <td>${formatDate(row.date)}</td>
      <td>${escapeHtml(row.title || "-")}</td>
      <td>${escapeHtml(row.groupName || "-")}</td>
      <td>
        <strong>${row.score === "" ? "-" : `${escapeHtml(row.score)} / ${escapeHtml(row.maxScore || 20)}`}</strong><br>
        <span class="grade-rule ${row.needsMakeup ? "makeup" : ""}">${row.needsMakeup ? "MatiÃ¨re non validÃ©e" : escapeHtml(row.status || gradeStatusLabel(row.score, row.maxScore || 20))}</span>
      </td>
      <td>
        ${escapeHtml(row.needsMakeup ? "Non validÃ©" : (row.appreciation || ""))}
        ${row.needsMakeup ? `<div class="muted">Rattrapage requis : ${formatMoney(MAKEUP_FEE)} pour cette matiÃ¨re.</div>` : ""}
      </td>
    </tr>
  `).join("");
  ids.studentPortalGrades.innerHTML = makeupNotice + gradeRows || `<tr><td colspan="5">Aucune note enregistrÃ©e.</td></tr>`;

  ids.studentPortalAttendance.innerHTML = attendance.map(row => `
    <tr>
      <td>${formatDate(row.date)}</td>
      <td>${escapeHtml(row.groupName || "-")}</td>
      <td>${escapeHtml(row.topic || "-")}</td>
      <td><span class="status">${escapeHtml(attendanceStatusLabel(row.status))}</span></td>
    </tr>
  `).join("") || `<tr><td colspan="4">Aucune prÃ©sence enregistrÃ©e.</td></tr>`;
}

async function loginStudentPortal(event) {
  event.preventDefault();
  ids.studentPortalLoginError.textContent = "";
  const submitButton = event.currentTarget.querySelector("button[type='submit']");
  submitButton.disabled = true;

  try {
    if (!SERVER_MODE) {
      throw new Error("L'espace Ã©tudiant doit Ãªtre ouvert avec le serveur local.");
    }
    const data = await apiRequest("/api/student-portal", {
      method: "POST",
      body: JSON.stringify({
        matricule: document.getElementById("studentPortalMatricule").value,
        phone: document.getElementById("studentPortalPhone").value
      })
    });
    showStudentPortal(data);
  } catch (error) {
    ids.studentPortalLoginError.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
}

function logoutStudentPortal() {
  document.getElementById("studentPortalMatricule").value = "";
  document.getElementById("studentPortalPhone").value = "";
  showLoginScreen();
}

async function bootstrap() {
  wireEvents();
  resetStudentForm();
  resetGroupForm();
  resetEnrollmentForm();
  resetPaymentForm();
  resetTrainerForm();
  resetStaffForm();
  resetEvaluationForm();

  if (PUBLIC_REGISTRATION_MODE) {
    try {
      await loadPublicCenterIdentity();
      await loadOnlineRegistrationOptions();
      showPublicRegistration();
    } catch (error) {
      showPublicRegistration();
      if (ids.onlineRegistrationError) {
        ids.onlineRegistrationError.textContent = error.message || "Chargement impossible";
      }
    }
    return;
  }

  if (!SERVER_MODE) {
    document.body.classList.remove("loading", "needs-login");
    render();
    return;
  }

  try {
    if (sessionStorage.getItem(SESSION_RESUME_KEY) !== "1") {
      await apiRequest("/api/logout", { method: "POST" }).catch(() => {});
      await loadPublicCenterIdentity();
      showLoginScreen();
      return;
    }
    const session = await apiRequest("/api/me");
    currentUser = session.user;
    if (!currentUser) {
      await loadPublicCenterIdentity();
      showLoginScreen();
      return;
    }
    await loadServerState();
    startServerSync();
    if (ids.studentPortal) ids.studentPortal.hidden = true;
    document.body.classList.remove("loading", "needs-login", "student-portal-mode");
    render();
    enforcePasswordChangeIfNeeded();
  } catch {
    showLoginScreen();
    ids.loginError.textContent = "Serveur indisponible";
  }
}

async function login(event) {
  event.preventDefault();
  ids.loginError.textContent = "";
  const submitButton = event.currentTarget.querySelector("button[type='submit']");
  submitButton.disabled = true;
  let loginAccepted = false;

  try {
    const result = await apiRequest("/api/login", {
      method: "POST",
      body: JSON.stringify({
        identifier: document.getElementById("loginEmail").value,
        email: document.getElementById("loginEmail").value,
        password: document.getElementById("loginPassword").value
      })
    });
    loginAccepted = true;
    currentUser = result.user;
    sessionStorage.setItem(SESSION_RESUME_KEY, "1");
    await loadServerState();
    startServerSync();
    if (ids.studentPortal) ids.studentPortal.hidden = true;
    document.body.classList.remove("loading", "needs-login", "student-portal-mode");
    render();
    enforcePasswordChangeIfNeeded();
    showToast("Connexion rÃ©ussie");
  } catch (error) {
    ids.loginError.textContent = loginAccepted && error.status === 401
      ? "Connexion acceptee, mais la session n'est pas conservee. Verifiez l'URL utilisee et redemarrez le serveur avec la derniere version."
      : error.message;
  } finally {
    submitButton.disabled = false;
  }
}

async function logout() {
  if (SERVER_MODE) {
    stopServerSync();
    sessionStorage.removeItem(SESSION_RESUME_KEY);
    sessionStorage.removeItem(CLEANUP_MODE_KEY);
    await apiRequest("/api/logout", { method: "POST" }).catch(() => {});
    currentUser = null;
    showLoginScreen();
    renderSession();
  }
}

function wireEvents() {
  document.getElementById("loginForm").addEventListener("submit", login);
  ids.passwordChangeForm?.addEventListener("submit", changeOwnPassword);
  document.getElementById("studentPortalLoginForm").addEventListener("submit", loginStudentPortal);
  ids.onlineRegistrationForm?.addEventListener("submit", submitOnlineRegistration);
  ids.onlineCourse?.addEventListener("change", syncOnlineRegistrationGroups);
  document.getElementById("onlineLastName")?.addEventListener("input", event => {
    event.target.value = event.target.value.toUpperCase();
  });
  document.getElementById("forgotPasswordButton").addEventListener("click", showPasswordResetBox);
  document.getElementById("cancelPasswordReset").addEventListener("click", hidePasswordResetBox);
  document.getElementById("sendPasswordReset").addEventListener("click", requestPasswordReset);
  document.addEventListener("change", event => {
    const toggle = event.target.closest("[data-toggle-password]");
    if (!toggle) return;
    const input = document.querySelector(`[data-user-password="${CSS.escape(toggle.dataset.togglePassword)}"]`);
    if (input) input.type = toggle.checked ? "text" : "password";
  });
  document.querySelectorAll("[data-login-choice]").forEach(button => {
    button.addEventListener("click", () => showLoginFormPanel(button.dataset.loginChoice));
  });
  document.querySelectorAll("[data-login-back]").forEach(button => {
    button.addEventListener("click", showLoginChoice);
  });
  document.getElementById("studentPortalLogout").addEventListener("click", logoutStudentPortal);
  document.getElementById("logoutButton").addEventListener("click", logout);
  ids.printPreviewPrint?.addEventListener("click", printPreviewDocument);
  ids.printPreviewModal?.addEventListener("click", event => {
    if (event.target.closest("[data-action='close-print-preview']")) {
      closePrintPreview();
    }
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && ids.printPreviewModal && !ids.printPreviewModal.hidden) {
      closePrintPreview();
    }
  });

  document.querySelectorAll("[data-view-target]").forEach(button => {
    button.addEventListener("click", () => setView(button.dataset.viewTarget));
  });

  document.getElementById("backupButton").addEventListener("click", () => {
    saveState({ immediate: true, notify: true });
  });

  document.getElementById("studentSearch").addEventListener("input", () => renderAndPaginate(renderStudents, ["studentsTable"]));
  document.getElementById("studentStatusFilter").addEventListener("change", () => renderAndPaginate(renderStudents, ["studentsTable"]));
  document.getElementById("studentCourseFilter")?.addEventListener("change", () => renderAndPaginate(renderStudents, ["studentsTable"]));
  document.getElementById("onlineRequestSearch")?.addEventListener("input", () => renderAndPaginate(renderOnlineRequests, ["onlineRequestsTable"]));
  document.getElementById("onlineRequestStatusFilter")?.addEventListener("change", () => renderAndPaginate(renderOnlineRequests, ["onlineRequestsTable"]));
  ["courseSearch", "courseStatusFilter"].forEach(id => document.getElementById(id)?.addEventListener("input", () => renderAndPaginate(renderCourses, ["coursesTable"])));
  ["groupCourseFilter", "groupSessionFilter", "groupStatusFilter"].forEach(id => document.getElementById(id)?.addEventListener("change", () => renderAndPaginate(renderGroups, ["groupsTable"])));
  ["enrollmentSearch", "enrollmentCourseFilter", "enrollmentStatusFilter", "enrollmentBalanceFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "enrollmentSearch" ? "input" : "change", () => renderAndPaginate(renderEnrollments, ["enrollmentsTable"]));
  });
  ["paymentSearch", "paymentCategoryFilter", "paymentMethodFilter", "paymentMonthFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "paymentSearch" ? "input" : "change", () => renderAndPaginate(renderPayments, ["paymentsTable"]));
  });
  ["trainerSearch", "trainerStatusFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "trainerSearch" ? "input" : "change", () => renderAndPaginate(renderTrainers, ["trainersTable"]));
  });
  ["staffSearch", "staffStatusFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "staffSearch" ? "input" : "change", () => renderAndPaginate(renderStaff, ["staffTable", "staffPaymentsTable"]));
  });
  ["studentLastName", "trainerLastName", "staffLastName"].forEach(id => {
    document.getElementById(id)?.addEventListener("input", event => {
      event.target.value = event.target.value.toUpperCase();
    });
  });

  document.getElementById("studentForm").addEventListener("submit", saveStudent);
  document.getElementById("courseForm").addEventListener("submit", saveCourse);
  document.getElementById("groupForm").addEventListener("submit", saveGroup);
  document.getElementById("enrollmentForm").addEventListener("submit", saveEnrollment);
  document.getElementById("paymentForm").addEventListener("submit", savePayment);
  document.getElementById("cashForm").addEventListener("submit", saveCashEntry);
  document.getElementById("closeCashDay")?.addEventListener("click", closeCashDay);
  document.getElementById("attendanceForm").addEventListener("submit", saveAttendance);
  document.getElementById("trainerAttendanceForm").addEventListener("submit", saveTrainerAttendance);
  document.getElementById("trainerForm").addEventListener("submit", saveTrainer);
  document.getElementById("staffForm").addEventListener("submit", saveStaff);
  document.getElementById("staffPaymentForm").addEventListener("submit", saveStaffPayment);
  document.getElementById("evaluationForm").addEventListener("submit", saveEvaluation);
  document.getElementById("centerForm").addEventListener("submit", saveCenter);
  document.getElementById("motifSettingsForm").addEventListener("submit", savePaymentMotifs);
  document.getElementById("courseFeesSettingsForm").addEventListener("submit", saveCourseFeesSettings);
  document.getElementById("documentTemplateForm").addEventListener("submit", saveDocumentTemplate);
  document.getElementById("requiredDocumentsForm").addEventListener("submit", saveRequiredDocumentsSettings);
  document.getElementById("userAccessForm").addEventListener("submit", saveUserAccessSettings);

  document.getElementById("studentCancelEdit").addEventListener("click", resetStudentForm);
  document.getElementById("courseCancelEdit").addEventListener("click", resetCourseForm);
  document.getElementById("groupCancelEdit").addEventListener("click", resetGroupForm);
  document.getElementById("enrollmentCancelEdit").addEventListener("click", resetEnrollmentForm);
  document.getElementById("paymentCancelEdit").addEventListener("click", resetPaymentForm);
  document.getElementById("trainerCancelEdit").addEventListener("click", resetTrainerForm);
  document.getElementById("staffCancelEdit").addEventListener("click", resetStaffForm);
  document.getElementById("evaluationCancelEdit").addEventListener("click", resetEvaluationForm);

  ["student", "trainer", "staff"].forEach(kind => {
    document.getElementById(`${kind}PhotoInput`)?.addEventListener("change", () => importPersonPhoto(kind));
    document.getElementById(`${kind}RemovePhoto`)?.addEventListener("click", () => removePersonPhoto(kind));
    document.getElementById(`${kind}AddDocument`)?.addEventListener("click", () => addPersonDocument(kind));
  });

  document.getElementById("enrollmentCourse").addEventListener("change", () => {
    syncEnrollmentGroups();
    applyCourseCostToEnrollment();
  });
  document.getElementById("enrollmentDiscount").addEventListener("input", updateEnrollmentFinal);
  document.getElementById("enrollmentTotal").addEventListener("input", updateEnrollmentFinal);
  document.getElementById("studentLastName").addEventListener("input", event => {
    const start = event.target.selectionStart;
    const end = event.target.selectionEnd;
    event.target.value = event.target.value.toUpperCase();
    event.target.setSelectionRange(start, end);
  });
  document.getElementById("paymentEnrollment").addEventListener("change", () => {
    updatePaymentBalance();
    updatePaymentReasonFields();
  });
  document.getElementById("paymentReason").addEventListener("change", updatePaymentReasonFields);
  document.getElementById("attendanceGroup").addEventListener("change", () => renderAndPaginate(renderAttendance, ["attendanceTable"]));
  document.getElementById("evaluationGroup").addEventListener("change", () => updateEvaluationStudents());
  document.getElementById("evaluationMaxScore").addEventListener("input", () => updateEvaluationStudents());
  document.getElementById("documentGeneratorTemplate").addEventListener("change", renderDocumentGenerator);
  document.getElementById("individualReportStudent").addEventListener("change", renderIndividualReport);

  document.body.addEventListener("click", handleActionClick);
  document.body.addEventListener("click", handleTablePaginationClick);

  document.getElementById("exportPaymentsCsv").addEventListener("click", exportPaymentsCsv);
  document.getElementById("exportCashCsv").addEventListener("click", exportCashCsv);
  document.getElementById("exportStudentsCsv").addEventListener("click", exportStudentsCsv);
  document.getElementById("exportAllCsv").addEventListener("click", exportAllCsv);
  document.getElementById("enableCleanupMode").addEventListener("click", enableCleanupMode);
  document.getElementById("printBalances").addEventListener("click", printBalancesReport);
  ids.previewIndividualReportPdf?.addEventListener("click", printIndividualStudentReport);
  document.getElementById("printIndividualReport").addEventListener("click", printIndividualStudentReport);
  document.getElementById("printStudentTranscript").addEventListener("click", () => {
    printStudentTranscript(Number(ids.individualReportStudent.value));
  });
  document.getElementById("printCustomDocument").addEventListener("click", printSelectedDocumentTemplate);
  document.getElementById("addPaymentMotif").addEventListener("click", addPaymentMotif);
  document.getElementById("newDocumentTemplate").addEventListener("click", resetDocumentTemplateForm);
  document.getElementById("documentTemplateCancelEdit").addEventListener("click", resetDocumentTemplateForm);
  document.getElementById("addUserAccess").addEventListener("click", addUserAccess);
  document.getElementById("centerLogo").addEventListener("change", importCenterLogo);
  document.getElementById("removeCenterLogo").addEventListener("click", removeCenterLogo);
  document.getElementById("centerStamp").addEventListener("change", importCenterStamp);
  document.getElementById("removeCenterStamp").addEventListener("click", removeCenterStamp);
  document.getElementById("exportJson").addEventListener("click", exportJson);
  document.getElementById("importJson").addEventListener("change", importJson);
  document.getElementById("resetData").addEventListener("click", resetData);
}

function saveStudent(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const matricule = form.dataset.editId
    ? document.getElementById("studentMatricule").value.trim()
    : generateMatricule(yearFromDate());
  const payload = {
    matricule,
    firstName: document.getElementById("studentFirstName").value.trim(),
    lastName: document.getElementById("studentLastName").value.trim().toUpperCase(),
    gender: document.getElementById("studentGender").value,
    birthDate: document.getElementById("studentBirthDate").value,
    birthPlace: document.getElementById("studentBirthPlace")?.value.trim() || "",
    nationality: document.getElementById("studentNationality")?.value.trim() || "",
    phone: document.getElementById("studentPhone").value.trim(),
    email: document.getElementById("studentEmail").value.trim(),
    address: document.getElementById("studentAddress").value.trim(),
    district: document.getElementById("studentDistrict")?.value.trim() || "",
    city: document.getElementById("studentCity")?.value.trim() || "",
    country: document.getElementById("studentCountry")?.value.trim() || "",
    studyLevel: document.getElementById("studentStudyLevel")?.value.trim() || "",
    profession: document.getElementById("studentProfession")?.value.trim() || "",
    desiredCourseId: Number(document.getElementById("studentDesiredCourse")?.value || 0),
    fatherName: document.getElementById("studentFatherName")?.value.trim() || "",
    fatherPhone: document.getElementById("studentFatherPhone")?.value.trim() || "",
    motherName: document.getElementById("studentMotherName")?.value.trim() || "",
    motherPhone: document.getElementById("studentMotherPhone")?.value.trim() || "",
    emergencyName: document.getElementById("studentEmergencyName").value.trim(),
    emergencyPhone: document.getElementById("studentEmergencyPhone").value.trim(),
    paymentResponsible: document.getElementById("studentPaymentResponsible")?.value.trim() || "",
    paymentResponsiblePhone: document.getElementById("studentPaymentResponsiblePhone")?.value.trim() || "",
    source: document.getElementById("studentSource")?.value || "",
    observation: document.getElementById("studentObservation")?.value.trim() || "",
    status: document.getElementById("studentStatus").value,
    ...personFilesPayload("student")
  };

  if (state.students.some(student => Number(student.id) !== Number(form.dataset.editId || 0) && student.matricule === payload.matricule)) {
    showToast("Ce matricule est dÃ©jÃ  utilisÃ©");
    document.getElementById("studentMatricule").focus();
    return;
  }

  if (form.dataset.editId) {
    const student = getStudent(form.dataset.editId);
    Object.assign(student, payload);
    showToast("Ã‰tudiant modifiÃ©");
  } else {
    state.students.push({ id: nextId(state.students), ...payload });
    showToast("Ã‰tudiant ajoutÃ©");
  }

  saveState();
  resetStudentForm();
  render();
}

function saveCourse(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    code: document.getElementById("courseCode").value.trim(),
    name: document.getElementById("courseName").value.trim(),
    duration: document.getElementById("courseDuration").value.trim(),
    registrationFee: Number(document.getElementById("courseRegistrationFee").value || 0),
    trainingFee: Number(document.getElementById("courseTrainingFee").value || 0),
    monthlyFee: Number(document.getElementById("courseMonthlyFee").value || 0),
    description: document.getElementById("courseDescription").value.trim(),
    status: document.getElementById("courseStatus").value
  };

  if (form.dataset.editId) {
    const course = getCourse(form.dataset.editId);
    Object.assign(course, payload);
    showToast("Formation modifiÃ©e");
  } else {
    state.courses.push({ id: nextId(state.courses), ...payload });
    showToast("Formation ajoutÃ©e");
  }

  saveState();
  resetCourseForm();
  render();
}

function saveGroup(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const trainer = getTrainer(document.getElementById("groupTrainer").value);
  const payload = {
    name: document.getElementById("groupName").value.trim(),
    courseId: Number(document.getElementById("groupCourse").value),
    year: document.getElementById("groupYear").value.trim(),
    sessionType: document.getElementById("groupSessionType").value,
    trainerId: Number(document.getElementById("groupTrainer").value),
    trainer: trainerName(trainer),
    capacity: Number(document.getElementById("groupCapacity").value || 0),
    startDate: document.getElementById("groupStartDate").value,
    endDate: document.getElementById("groupEndDate").value,
    status: document.getElementById("groupStatus").value
  };

  if (!payload.courseId) {
    showToast("Choisissez une formation");
    document.getElementById("groupCourse").focus();
    return;
  }
  if (!payload.trainerId) {
    showToast("Choisissez un formateur enregistrÃ©");
    document.getElementById("groupTrainer").focus();
    return;
  }

  if (form.dataset.editId) {
    const group = getGroup(form.dataset.editId);
    Object.assign(group, payload);
    showToast("Promotion modifiÃ©e");
  } else {
    state.groups.push({ id: nextId(state.groups), ...payload });
    showToast("Promotion ajoutÃ©e");
  }

  saveState();
  resetGroupForm();
  render();
}

function saveEnrollment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    studentId: Number(document.getElementById("enrollmentStudent").value),
    courseId: Number(document.getElementById("enrollmentCourse").value),
    groupId: Number(document.getElementById("enrollmentGroup").value),
    date: document.getElementById("enrollmentDate").value,
    totalAmount: Number(document.getElementById("enrollmentTotal").value || 0),
    discountAmount: Number(document.getElementById("enrollmentDiscount").value || 0),
    finalAmount: Number(document.getElementById("enrollmentFinal").value || 0),
    monthlyFee: Number(document.getElementById("enrollmentMonthlyFee")?.value || 0),
    status: document.getElementById("enrollmentStatus").value
  };

  if (!payload.studentId) {
    showToast("Choisissez un Ã©tudiant");
    document.getElementById("enrollmentStudent").focus();
    return;
  }
  if (!payload.courseId) {
    showToast("Choisissez une formation");
    document.getElementById("enrollmentCourse").focus();
    return;
  }
  if (!payload.groupId) {
    showToast("Choisissez une promotion");
    document.getElementById("enrollmentGroup").focus();
    return;
  }
  const duplicate = state.enrollments.some(enrollment =>
    Number(enrollment.id) !== Number(form.dataset.editId || 0) &&
    Number(enrollment.studentId) === payload.studentId &&
    Number(enrollment.courseId) === payload.courseId &&
    Number(enrollment.groupId) === payload.groupId &&
    !["annulee", "desiste"].includes(enrollment.status)
  );
  if (duplicate) {
    showToast("Cet Ã©tudiant est dÃ©jÃ  inscrit dans cette promotion");
    return;
  }

  if (form.dataset.editId) {
    const enrollment = getEnrollment(form.dataset.editId);
    Object.assign(enrollment, payload);
    const student = getStudent(payload.studentId);
    if (student && payload.status === "validee" && student.status === "preinscrit") {
      student.status = "actif";
    }
    showToast("Inscription modifiÃ©e");
  } else {
    const firstEnrollment = !state.enrollments.some(enrollment => Number(enrollment.studentId) === payload.studentId);
    const student = getStudent(payload.studentId);
    if (student && firstEnrollment) {
      student.matricule = generateMatricule(yearFromDate(payload.date));
    }
    if (student && payload.status === "validee" && student.status === "preinscrit") {
      student.status = "actif";
    }
    state.enrollments.push({ id: nextId(state.enrollments), ...payload });
    showToast("Inscription enregistrÃ©e");
  }

  saveState();
  resetEnrollmentForm();
  render();
}

function controlledPaymentReason(actionLabel) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut corriger un paiement");
    return "";
  }
  const reason = prompt(`${actionLabel} : indiquez le motif du controle`);
  if (!reason || reason.trim().length < 4) {
    showToast("Motif de controle obligatoire");
    return "";
  }
  return reason.trim();
}

function paymentSnapshot(payment) {
  return JSON.parse(JSON.stringify(payment || {}));
}

function logPaymentControl(action, payment, controlReason, before = null, after = null) {
  state.paymentAuditLog.push({
    id: nextId(state.paymentAuditLog),
    date: new Date().toISOString(),
    action,
    paymentId: payment?.id || before?.id || after?.id || 0,
    receiptNumber: payment?.receiptNumber || before?.receiptNumber || after?.receiptNumber || "",
    operator: currentOperatorName(),
    controlReason,
    before,
    after
  });
}

function validatePaymentPayload(payload, editId = 0) {
  if (!payload.enrollmentId || payload.amount <= 0 || !payload.reason) {
    showToast("Paiement incomplet");
    return false;
  }
  const enrollment = getEnrollment(payload.enrollmentId);
  if (!enrollment || suppressPaymentTrackingForEnrollment(enrollment)) {
    showToast("Cette inscription n'est pas ouverte au paiement");
    return false;
  }
  if (isTuitionMotifKey(payload.reasonKey)) {
    const balance = editId
      ? balanceForEnrollmentExcluding(getEnrollment(payload.enrollmentId), editId)
      : balanceForEnrollment(getEnrollment(payload.enrollmentId));
    if (balance <= 0) {
      showToast("La scolarite est deja soldee");
      return false;
    }
    if (payload.amount > balance) {
      showToast("Le paiement depasse le reste de scolarite");
      return false;
    }
    return true;
  }

  if (isMakeupMotifKey(payload.reasonKey)) {
    const enrollment = getEnrollment(payload.enrollmentId);
    const due = makeupDueForEnrollment(enrollment, editId);
    if (due <= 0) {
      showToast("Aucun rattrapage Ã  payer pour cet Ã©tudiant");
      return false;
    }
    if (payload.amount % MAKEUP_FEE !== 0) {
      showToast(`Le rattrapage se paie par tranche de ${formatMoney(MAKEUP_FEE)}`);
      return false;
    }
    if (payload.amount > due) {
      showToast(`Le paiement dÃ©passe le reste rattrapage : ${formatMoney(due)}`);
      return false;
    }
    return true;
  }

  const alreadyPaid = paymentsForEnrollment(payload.enrollmentId)
    .some(payment => Number(payment.id) !== Number(editId) && String(payment.reasonKey || "") === payload.reasonKey);
  if (alreadyPaid) {
    showToast("Ce frais annexe est deja paye pour cet etudiant");
    return false;
  }
  return true;
}

async function savePayment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const editId = Number(form.dataset.editId || 0);
  const enrollmentId = Number(document.getElementById("paymentEnrollment").value);
  const reasonKey = document.getElementById("paymentReason").value;
  const reason = getPaymentMotif(reasonKey)?.label || reasonKey;
  const amount = Number(document.getElementById("paymentAmount").value || 0);
  const payload = {
    enrollmentId,
    amount,
    method: document.getElementById("paymentMethod").value,
    reason,
    reasonKey,
    date: document.getElementById("paymentDate").value,
    receivedBy: currentOperatorName()
  };

  if (!validatePaymentPayload(payload, editId)) return;

  const submitButton = form.querySelector("button[type='submit']");
  if (submitButton) submitButton.disabled = true;
  let shouldUnlockButton = true;
  try {
  let paymentToPrint = null;
  let successMessage = "";

  if (editId) {
    const payment = findById(state.payments, editId);
    if (!payment) return;
    if (isTuitionPayment(payment) !== isTuitionMotifKey(payload.reasonKey)) {
      showToast("La categorie du recu ne peut pas etre changee");
      return;
    }
    const controlReason = controlledPaymentReason("Modification du paiement");
    if (!controlReason) return;
    const before = paymentSnapshot(payment);
    Object.assign(payment, payload, {
      correctedAt: new Date().toISOString(),
      correctedBy: currentOperatorName(),
      correctionReason: controlReason
    });
    logPaymentControl("Modification", payment, controlReason, before, paymentSnapshot(payment));
    successMessage = "Paiement modifiÃ© et sauvegardÃ©";
  } else {
    const payment = {
      id: nextId(state.payments),
      receiptNumber: nextReceiptNumber(reasonKey),
      ...payload
    };
    state.payments.push(payment);
    paymentToPrint = payment.id;
    successMessage = "Paiement encaissÃ© et sauvegardÃ©";
  }

  const saved = await saveState({ immediate: true });
  if (!saved) return;
  resetPaymentForm();
  render();
  showToast(successMessage);
  if (paymentToPrint) printReceipt(paymentToPrint);
  shouldUnlockButton = false;
  } finally {
    if (shouldUnlockButton && submitButton) submitButton.disabled = false;
  }
}

async function saveCashEntry(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const amount = Number(document.getElementById("cashAmount").value || 0);
  const category = document.getElementById("cashCategory").value.trim();

  if (amount <= 0 || !category) {
    showToast("OpÃ©ration de caisse incomplÃ¨te");
    return;
  }

  const submitButton = form.querySelector("button[type='submit']");
  if (submitButton) submitButton.disabled = true;
  let shouldUnlockButton = true;
  try {
  state.cashEntries.push({
    id: nextId(state.cashEntries),
    type: document.getElementById("cashType").value,
    date: document.getElementById("cashDate").value,
    category,
    amount,
    method: document.getElementById("cashMethod").value,
    description: document.getElementById("cashDescription").value.trim(),
    recordedBy: document.getElementById("roleSelect").value
  });

  const saved = await saveState({ immediate: true });
  if (!saved) return;
  form.reset();
  document.getElementById("cashDate").value = today();
  render();
  showToast("OpÃ©ration enregistrÃ©e et sauvegardÃ©e");
  shouldUnlockButton = false;
  } finally {
    if (shouldUnlockButton && submitButton) submitButton.disabled = false;
  }
}

async function closeCashDay() {
  const date = today();
  const openEntries = state.cashEntries.filter(entry => entry.date === date && !entry.closedAt);
  if (!openEntries.length) {
    showToast("Aucune operation manuelle a cloturer aujourd'hui");
    return;
  }
  if (!confirm(`Cloturer ${openEntries.length} operation(s) de caisse du ${formatDate(date)} ?`)) return;
  const now = new Date().toISOString();
  openEntries.forEach(entry => {
    entry.closedAt = now;
    entry.closedBy = currentOperatorName();
  });
  const saved = await saveState({ immediate: true });
  if (!saved) return;
  renderCash();
  showToast("Journee de caisse cloturee");
}

function saveAttendance(event) {
  event.preventDefault();
  const groupId = Number(document.getElementById("attendanceGroup").value);
  const records = [...document.querySelectorAll("[data-attendance-student]")].map(select => ({
    studentId: Number(select.dataset.attendanceStudent),
    status: select.value
  }));

  if (!groupId || !records.length) {
    showToast("Aucun Ã©tudiant pour l'appel");
    return;
  }

  const session = {
    id: nextId(state.attendanceSessions),
    groupId,
    date: document.getElementById("attendanceDate").value,
    topic: document.getElementById("attendanceTopic").value.trim(),
    records
  };

  state.attendanceSessions.push(session);
  saveState();
  document.getElementById("attendanceTopic").value = "";
  render();
  showToast("Appel enregistrÃ©");
}

function saveTrainerAttendance(event) {
  event.preventDefault();
  const records = [...document.querySelectorAll("[data-attendance-trainer]")].map(select => ({
    trainerId: Number(select.dataset.attendanceTrainer),
    status: select.value
  }));

  if (!records.length) {
    showToast("Aucun professeur pour l'appel");
    return;
  }

  state.trainerAttendanceSessions.push({
    id: nextId(state.trainerAttendanceSessions),
    date: document.getElementById("trainerAttendanceDate").value,
    topic: document.getElementById("trainerAttendanceTopic").value.trim(),
    records
  });

  saveState();
  document.getElementById("trainerAttendanceTopic").value = "";
  render();
  showToast("Appel des professeurs enregistrÃ©");
}

function saveTrainer(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    firstName: document.getElementById("trainerFirstName").value.trim(),
    lastName: document.getElementById("trainerLastName").value.trim().toUpperCase(),
    phone: document.getElementById("trainerPhone").value.trim(),
    email: document.getElementById("trainerEmail").value.trim(),
    specialty: document.getElementById("trainerSpecialty").value.trim(),
    modules: document.getElementById("trainerModules").value.trim(),
    status: document.getElementById("trainerStatus").value,
    ...personFilesPayload("trainer")
  };

  if (form.dataset.editId) {
    const trainer = getTrainer(form.dataset.editId);
    Object.assign(trainer, payload);
    showToast("Formateur modifie");
  } else {
    state.trainers.push({ id: nextId(state.trainers), ...payload });
    showToast("Formateur ajoute");
  }

  saveState();
  resetTrainerForm();
  render();
}

function saveStaff(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    firstName: document.getElementById("staffFirstName").value.trim(),
    lastName: document.getElementById("staffLastName").value.trim().toUpperCase(),
    role: document.getElementById("staffRole").value.trim(),
    salary: Number(document.getElementById("staffSalary").value || 0),
    phone: document.getElementById("staffPhone").value.trim(),
    email: document.getElementById("staffEmail").value.trim(),
    status: document.getElementById("staffStatus").value,
    ...personFilesPayload("staff")
  };

  if (!payload.firstName || !payload.lastName || !payload.role) {
    showToast("Fiche personnel incomplete");
    return;
  }

  if (form.dataset.editId) {
    const member = getStaffMember(form.dataset.editId);
    if (!member) return;
    Object.assign(member, payload);
    showToast("Personnel modifie");
  } else {
    state.staffMembers.push({ id: nextId(state.staffMembers), ...payload });
    showToast("Personnel ajoute");
  }

  saveState();
  resetStaffForm();
  render();
}

async function saveStaffPayment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const beneficiary = parsePayrollBeneficiary(document.getElementById("staffPaymentStaff").value);
  const amount = Number(document.getElementById("staffPaymentAmount").value || 0);

  if (!beneficiary.id || amount <= 0) {
    showToast("Paiement personnel incomplet");
    return;
  }

  const submitButton = form.querySelector("button[type='submit']");
  if (submitButton) submitButton.disabled = true;
  let shouldUnlockButton = true;
  try {
  state.staffPayments.push({
    id: nextId(state.staffPayments),
    staffId: beneficiary.type === "staff" ? beneficiary.id : 0,
    payeeType: beneficiary.type,
    payeeId: beneficiary.id,
    period: document.getElementById("staffPaymentPeriod").value,
    date: document.getElementById("staffPaymentDate").value || today(),
    reason: document.getElementById("staffPaymentReason").value,
    amount,
    method: document.getElementById("staffPaymentMethod").value,
    note: document.getElementById("staffPaymentNote").value.trim(),
    recordedBy: currentUser?.name || document.getElementById("roleSelect")?.value || "Administrateur"
  });

  const saved = await saveState({ immediate: true });
  if (!saved) return;
  form.reset();
  document.getElementById("staffPaymentDate").value = today();
  document.getElementById("staffPaymentPeriod").value = today().slice(0, 7);
  render();
  showToast("Paiement personnel enregistrÃ© et sauvegardÃ©");
  shouldUnlockButton = false;
  } finally {
    if (shouldUnlockButton && submitButton) submitButton.disabled = false;
  }
}

function saveEvaluation(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const maxScore = Number(document.getElementById("evaluationMaxScore").value || 20);
  const grades = [...document.querySelectorAll("[data-grade-student]")].map(input => {
    const studentId = Number(input.dataset.gradeStudent);
    return {
      studentId,
      score: input.value === "" ? "" : Number(input.value),
      appreciation: document.querySelector(`[data-grade-appreciation="${studentId}"]`)?.value.trim() || ""
    };
  });

  const invalidGrade = grades.some(grade => grade.score !== "" && (Number(grade.score) < 0 || Number(grade.score) > maxScore));
  if (invalidGrade) {
    showToast("Une note depasse le bareme");
    return;
  }

  const payload = {
    groupId: Number(document.getElementById("evaluationGroup").value),
    trainerId: Number(document.getElementById("evaluationTrainer").value || 0),
    title: document.getElementById("evaluationTitle").value.trim(),
    type: document.getElementById("evaluationType").value,
    date: document.getElementById("evaluationDate").value,
    maxScore,
    grades
  };

  if (!payload.groupId || !payload.title) {
    showToast("Evaluation incomplete");
    return;
  }

  if (form.dataset.editId) {
    const evaluation = getEvaluation(form.dataset.editId);
    Object.assign(evaluation, payload);
    showToast("Evaluation modifiee");
  } else {
    state.evaluations.push({ id: nextId(state.evaluations), ...payload });
    showToast("Evaluation enregistree");
  }

  saveState();
  resetEvaluationForm();
  render();
}

function saveCenter(event) {
  event.preventDefault();
  state.center = {
    ...(state.center || {}),
    name: document.getElementById("centerName").value.trim() || "CFP EREXIT",
    subtitle: document.getElementById("centerSubtitle").value.trim() || "Centre de Formation Professionnelle",
    phone: document.getElementById("centerPhone").value.trim(),
    email: document.getElementById("centerEmail").value.trim(),
    address: document.getElementById("centerAddress").value.trim(),
    logoData: state.center?.logoData || "",
    stampData: state.center?.stampData || ""
  };
  saveState();
  renderCenterIdentity();
  showToast("Informations du centre enregistrÃ©es");
}

async function importCenterLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Format de logo invalide");
    event.target.value = "";
    return;
  }

  try {
    const logoData = file.type === "image/svg+xml"
      ? await svgToDataUrl(file)
      : await imageToPngDataUrl(file);
    state.center = {
      ...(state.center || {}),
      logoData
    };
    saveState();
    render();
    showToast("Logo enregistrÃ©");
  } catch {
    showToast("Logo illisible");
  } finally {
    event.target.value = "";
  }
}

function removeCenterLogo() {
  state.center = {
    ...(state.center || {}),
    logoData: ""
  };
  saveState();
  render();
  showToast("Logo retirÃ©");
}

async function importCenterStamp(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Format de signature/cachet invalide");
    event.target.value = "";
    return;
  }

  try {
    const stampData = file.type === "image/svg+xml"
      ? await svgToDataUrl(file)
      : await imageToPngDataUrl(file, 420);
    state.center = {
      ...(state.center || {}),
      stampData
    };
    saveState();
    render();
    showToast("Signature/cachet enregistrÃ©");
  } catch {
    showToast("Signature/cachet illisible");
  } finally {
    event.target.value = "";
  }
}

function removeCenterStamp() {
  state.center = {
    ...(state.center || {}),
    stampData: ""
  };
  saveState();
  render();
  showToast("Signature/cachet retirÃ©");
}

function savePaymentMotifs(event) {
  event.preventDefault();
  collectPaymentMotifInputs();
  saveState();
  syncPaymentReasons();
  render();
  showToast("Motifs enregistrÃ©s");
}

function saveCourseFeesSettings(event) {
  event.preventDefault();
  state.courses.forEach(course => {
    const registrationInput = document.querySelector(`[data-course-registration-fee="${course.id}"]`);
    const trainingInput = document.querySelector(`[data-course-training-fee="${course.id}"]`);
    const monthlyInput = document.querySelector(`[data-course-monthly-fee="${course.id}"]`);
    course.registrationFee = Number(registrationInput?.value || 0);
    course.trainingFee = Number(trainingInput?.value || 0);
    course.monthlyFee = Number(monthlyInput?.value || 0);
  });
  saveState();
  renderCourses();
  syncSelects();
  showToast("Frais des formations enregistrÃ©s");
}

function saveUserAccessSettings(event) {
  event.preventDefault();
  if (!isAdmin()) {
    showToast("AccÃ¨s rÃ©servÃ© Ã  l'administrateur");
    return;
  }
  if (!state.users.length) {
    showToast("Liste des utilisateurs non chargee. Rechargez la page.");
    return;
  }

  const users = [...document.querySelectorAll("[data-user-access-row]")].map(row => {
    const idText = row.dataset.userAccessRow;
    const id = Number(idText);
    const existing = state.users.find(user => Number(user.id) === id) || {};
    const roleInput = row.querySelector(`[data-user-role="${CSS.escape(idText)}"]`);
    const role = roleCode(existing.role) === "administrateur" ? "Administrateur" : (roleInput?.value || existing.role || "Secrétaire");
    const permissions = roleCode(role) === "administrateur"
      ? [...ACCESS_VIEWS]
      : [...row.querySelectorAll(`[data-user-permission="${CSS.escape(idText)}"]:checked`)].map(input => input.value);
    const password = row.querySelector(`[data-user-password="${CSS.escape(idText)}"]`)?.value.trim() || "";
    const isNewUser = !existing.email;
    return {
      id,
      name: row.querySelector(`[data-user-name="${CSS.escape(idText)}"]`)?.value.trim() || "Utilisateur",
      username: normalizeUsername(row.querySelector(`[data-user-username="${CSS.escape(idText)}"]`)?.value || existing.username || ""),
      email: row.querySelector(`[data-user-email="${CSS.escape(idText)}"]`)?.value.trim().toLowerCase() || existing.email || "",
      role,
      status: roleCode(role) === "administrateur" ? "active" : (row.querySelector(`[data-user-status="${CSS.escape(idText)}"]`)?.value || "active"),
      permissions,
      isNewUser,
      ...(password ? { password } : {})
    };
  });

  if (users.some(user => !user.email)) {
    showToast("Chaque utilisateur doit avoir un email");
    return;
  }
  if (users.some(user => !user.username)) {
    showToast("Chaque utilisateur doit avoir un identifiant");
    return;
  }
  if (users.some(user => user.isNewUser && !user.password)) {
    showToast("Mot de passe obligatoire pour un nouvel utilisateur");
    return;
  }
  const weakPassword = users.find(user => user.password && !strongPassword(user.password));
  if (weakPassword) {
    showToast("Mot de passe trop faible : 8 caractÃ¨res, majuscule, minuscule, chiffre et caractÃ¨re spÃ©cial");
    return;
  }
  const uniqueEmails = new Set(users.map(user => user.email));
  if (uniqueEmails.size !== users.length) {
    showToast("Deux utilisateurs ont le mÃªme email");
    return;
  }
  const uniqueUsernames = new Set(users.map(user => user.username));
  if (uniqueUsernames.size !== users.length) {
    showToast("Deux utilisateurs ont le mÃªme identifiant");
    return;
  }

  const changedPasswordEmails = users
    .filter(user => user.password)
    .map(user => user.email);
  state.users = users.map(({ isNewUser, ...user }) => user);
  if (changedPasswordEmails.length) {
    state.passwordResetRequests = (state.passwordResetRequests || []).map(request => (
      changedPasswordEmails.includes(request.email)
        ? { ...request, status: "done", resolvedAt: new Date().toISOString(), resolvedBy: currentOperatorName() }
        : request
    ));
  }
  saveState();
  renderSettings();
  showToast("AccÃ¨s utilisateurs enregistrÃ©s");
}

function saveRequiredDocumentsSettings(event) {
  event.preventDefault();
  if (!isAdmin()) return;
  state.requiredDocuments = {
    student: linesFromTextarea("student"),
    trainer: linesFromTextarea("trainer"),
    staff: linesFromTextarea("staff")
  };
  saveState();
  render();
  showToast("Documents obligatoires enregistrÃ©s");
}

function linesFromTextarea(kind) {
  const value = document.querySelector(`[data-required-documents="${kind}"]`)?.value || "";
  return value
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);
}

function collectPaymentMotifInputs() {
  ensurePaymentMotifs();
  state.paymentMotifs.forEach(motif => {
    const labelInput = document.querySelector(`[data-motif-label="${CSS.escape(motif.key)}"]`);
    const amountInput = document.querySelector(`[data-motif-amount="${CSS.escape(motif.key)}"]`);
    motif.label = labelInput?.value.trim() || motif.label || "Motif";
    motif.amount = Number(amountInput?.value || 0);
  });
}

function addPaymentMotif() {
  collectPaymentMotifInputs();
  state.paymentMotifs.push({
    key: `motif-${Date.now()}`,
    label: "Nouveau motif",
    amount: 0
  });
  saveState();
  renderSettings();
  syncPaymentReasons();
  showToast("Motif ajoutÃ©");
}

function addUserAccess() {
  if (!isAdmin()) return;
  collectCurrentUserAccessDraft();
  state.users.push({
    id: nextId(state.users),
    name: "Nouvel utilisateur",
    username: "",
    email: "",
    role: "SecrÃ©taire",
    status: "active",
    permissions: defaultPermissionsForRole("SecrÃ©taire")
  });
  renderSettings();
}

function collectCurrentUserAccessDraft() {
  if (!ids.userAccessSettings) return;
  const rows = [...document.querySelectorAll("[data-user-access-row]")];
  if (!rows.length) return;
  state.users = rows.map(row => {
    const idText = row.dataset.userAccessRow;
    const id = Number(idText);
    const existing = state.users.find(user => Number(user.id) === id) || {};
    const roleInput = row.querySelector(`[data-user-role="${CSS.escape(idText)}"]`);
    const role = roleCode(existing.role) === "administrateur" ? "Administrateur" : (roleInput?.value || existing.role || "Secrétaire");
    return {
      ...existing,
      id,
      name: row.querySelector(`[data-user-name="${CSS.escape(idText)}"]`)?.value.trim() || existing.name || "Utilisateur",
      username: normalizeUsername(row.querySelector(`[data-user-username="${CSS.escape(idText)}"]`)?.value || existing.username || ""),
      email: row.querySelector(`[data-user-email="${CSS.escape(idText)}"]`)?.value.trim().toLowerCase() || existing.email || "",
      role,
      status: roleCode(role) === "administrateur" ? "active" : (row.querySelector(`[data-user-status="${CSS.escape(idText)}"]`)?.value || existing.status || "active"),
      permissions: roleCode(role) === "administrateur"
        ? [...ACCESS_VIEWS]
        : [...row.querySelectorAll(`[data-user-permission="${CSS.escape(idText)}"]:checked`)].map(input => input.value)
    };
  });
}

function handleActionClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const id = Number(button.dataset.id);
  const action = button.dataset.action;

  if (action === "edit-student") editStudent(id);
  if (action === "enroll-student") prepareEnrollmentForStudent(id);
  if (action === "delete-student") deleteStudent(id);
  if (action === "edit-course") editCourse(id);
  if (action === "delete-course") deleteCourse(id);
  if (action === "edit-group") editGroup(id);
  if (action === "delete-group") deleteGroup(id);
  if (action === "edit-enrollment") editEnrollment(id);
  if (action === "delete-enrollment") deleteEnrollment(id);
  if (action === "pay-enrollment") startPayment(id);
  if (action === "pay-alert") startPayment(id, button.dataset.reason);
  if (action === "print-enrollment") printEnrollment(id);
  if (action === "print-attestation") printAttestation(id);
  if (action === "print-contract") printTrainingContract(id);
  if (action === "print-receipt") printReceipt(id);
  if (action === "edit-payment") editPayment(id);
  if (action === "delete-payment") deletePayment(id);
  if (action === "delete-cash-entry") deleteCashEntry(id);
  if (action === "edit-trainer") editTrainer(id);
  if (action === "delete-trainer") deleteTrainer(id);
  if (action === "edit-staff") editStaff(id);
  if (action === "delete-staff") deleteStaff(id);
  if (action === "delete-staff-payment") deleteStaffPayment(id);
  if (action === "print-payroll-slip") printPayrollSlip(id);
  if (action === "edit-evaluation") editEvaluation(id);
  if (action === "delete-evaluation") deleteEvaluation(id);
  if (action === "print-grades") printGradesReport(id);
  if (action === "delete-motif") deletePaymentMotif(button.dataset.key);
  if (action === "rename-person-document") renamePersonDocument(button.dataset.kind, button.dataset.index);
  if (action === "delete-person-document") deletePersonDocument(button.dataset.kind, button.dataset.index);
  if (action === "edit-document-template") editDocumentTemplate(button.dataset.key);
  if (action === "delete-document-template") deleteDocumentTemplate(button.dataset.key);
  if (action === "delete-user-access") deleteUserAccess(id);
  if (action === "mark-password-reset-done") markPasswordResetDone(id);
  if (action === "online-request-status") updateOnlineRequestStatus(id, button.dataset.status);
  if (action === "convert-online-request") convertOnlineRequest(id);
}

function updateOnlineRequestStatus(id, status) {
  const request = (state.onlineRegistrationRequests || []).find(item => Number(item.id) === Number(id));
  if (!request) return;
  request.status = status || request.status || "verification";
  request.statusLabel = onlineRequestStatusLabel(request.status);
  request.updatedAt = new Date().toISOString();
  request.updatedBy = currentOperatorName();
  state.notifications = [
    ...(state.notifications || []),
    {
      id: nextId(state.notifications || []),
      audience: "backoffice",
      type: "online-registration-status",
      title: "Statut de demande mis a jour",
      message: `${request.requestNumber || `DEM-${request.id}`} : ${onlineRequestStatusLabel(request.status)}`,
      status: "unread",
      createdAt: new Date().toISOString(),
      targetId: request.id
    }
  ];
  saveState();
  renderOnlineRequests();
  renderDashboard();
  showToast("Statut de la demande mis a jour");
}

function convertOnlineRequest(id) {
  const request = (state.onlineRegistrationRequests || []).find(item => Number(item.id) === Number(id));
  if (!request || String(request.status || "") === "convertie") return;
  const course = getCourse(request.courseId);
  if (!course) {
    showToast("Formation introuvable");
    return;
  }
  const preferredType = String(request.preferredCourseType || "").toLowerCase();
  const group = state.groups.find(item =>
    Number(item.courseId) === Number(request.courseId) &&
    String(item.status || "active") === "active" &&
    (!preferredType || String(item.sessionType || "").toLowerCase() === preferredType)
  ) || state.groups.find(item => Number(item.courseId) === Number(request.courseId) && String(item.status || "active") === "active");

  let student = request.existingStudentId ? getStudent(request.existingStudentId) : null;
  if (!student) {
    student = {
      id: nextId(state.students),
      matricule: generateMatricule(yearFromDate()),
      firstName: request.firstName || "",
      lastName: String(request.lastName || "").toUpperCase(),
      gender: request.gender || "",
      birthDate: request.birthDate || "",
      birthPlace: request.birthPlace || "",
      nationality: request.nationality || "",
      phone: request.phone || "",
      email: request.email || "",
      address: request.address || "",
      district: request.district || "",
      city: request.city || "",
      country: request.country || "",
      studyLevel: request.studyLevel || "",
      profession: request.profession || "",
      desiredCourseId: Number(request.courseId || 0),
      emergencyName: request.emergencyName || "",
      emergencyPhone: request.emergencyPhone || "",
      paymentResponsible: request.paymentResponsible || "",
      paymentResponsiblePhone: request.paymentResponsiblePhone || "",
      source: request.source || "site-web",
      observation: request.message || "",
      status: "preinscrit",
      photoData: "",
      documents: Array.isArray(request.documents) ? request.documents : []
    };
    state.students.push(student);
  }

  const duplicateEnrollment = state.enrollments.some(enrollment =>
    Number(enrollment.studentId) === Number(student.id) &&
    Number(enrollment.courseId) === Number(request.courseId) &&
    Number(enrollment.groupId || 0) === Number(group?.id || 0) &&
    !["annulee", "desiste"].includes(String(enrollment.status || ""))
  );
  if (duplicateEnrollment) {
    showToast("Une inscription existe deja pour cette formation/promotion");
    return;
  }

  const totalAmount = courseCost(course);
  const enrollment = {
    id: nextId(state.enrollments),
    studentId: student.id,
    courseId: Number(request.courseId),
    groupId: Number(group?.id || 0),
    sessionType: group?.sessionType || request.preferredCourseType || "",
    date: today(),
    totalAmount,
    discountAmount: 0,
    finalAmount: totalAmount,
    monthlyFee: Number(course.monthlyFee || 0),
    status: "en attente",
    source: "online",
    onlineRequestId: request.id,
    note: request.message || ""
  };
  state.enrollments.push(enrollment);
  state.studentAccounts = [
    ...(state.studentAccounts || []),
    {
      id: nextId(state.studentAccounts || []),
      studentId: student.id,
      matricule: student.matricule,
      email: student.email || "",
      phone: student.phone || "",
      authMode: "matricule-phone",
      status: "actif",
      mustChangePassword: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  request.status = "convertie";
  request.statusLabel = onlineRequestStatusLabel(request.status);
  request.studentId = student.id;
  request.enrollmentId = enrollment.id;
  request.convertedAt = new Date().toISOString();
  request.convertedBy = currentOperatorName();
  state.notifications = [
    ...(state.notifications || []),
    {
      id: nextId(state.notifications || []),
      audience: "student",
      studentId: student.id,
      type: "registration-converted",
      title: "Dossier accepte",
      message: `Votre dossier est converti. Matricule : ${student.matricule}`,
      status: "unread",
      createdAt: new Date().toISOString()
    }
  ];
  saveState();
  render();
  showToast(`Demande convertie : ${student.matricule}`);
}

function markPasswordResetDone(id) {
  state.passwordResetRequests = (state.passwordResetRequests || []).map(request => (
    Number(request.id) === Number(id)
      ? { ...request, status: "done", resolvedAt: new Date().toISOString(), resolvedBy: currentOperatorName() }
      : request
  ));
  saveState();
  renderUserAccessSettings();
  showToast("Demande marquÃ©e comme traitÃ©e");
}

function editStudent(id) {
  const student = getStudent(id);
  if (!student) return;
  const form = document.getElementById("studentForm");
  form.dataset.editId = id;
  document.getElementById("studentFormTitle").textContent = "Modifier Ã©tudiant";
  document.getElementById("studentMatricule").value = student.matricule || "";
  updateStudentMatriculeLock();
  document.getElementById("studentFirstName").value = student.firstName || "";
  document.getElementById("studentLastName").value = String(student.lastName || "").toUpperCase();
  document.getElementById("studentGender").value = student.gender || "";
  document.getElementById("studentBirthDate").value = student.birthDate || "";
  document.getElementById("studentBirthPlace").value = student.birthPlace || "";
  document.getElementById("studentNationality").value = student.nationality || "";
  document.getElementById("studentPhone").value = student.phone || "";
  document.getElementById("studentEmail").value = student.email || "";
  document.getElementById("studentAddress").value = student.address || "";
  document.getElementById("studentDistrict").value = student.district || "";
  document.getElementById("studentCity").value = student.city || "";
  document.getElementById("studentCountry").value = student.country || "";
  document.getElementById("studentStudyLevel").value = student.studyLevel || "";
  document.getElementById("studentProfession").value = student.profession || "";
  document.getElementById("studentDesiredCourse").value = student.desiredCourseId || "";
  document.getElementById("studentFatherName").value = student.fatherName || "";
  document.getElementById("studentFatherPhone").value = student.fatherPhone || "";
  document.getElementById("studentMotherName").value = student.motherName || "";
  document.getElementById("studentMotherPhone").value = student.motherPhone || "";
  document.getElementById("studentEmergencyName").value = student.emergencyName || "";
  document.getElementById("studentEmergencyPhone").value = student.emergencyPhone || "";
  document.getElementById("studentPaymentResponsible").value = student.paymentResponsible || "";
  document.getElementById("studentPaymentResponsiblePhone").value = student.paymentResponsiblePhone || "";
  document.getElementById("studentSource").value = student.source || "";
  document.getElementById("studentObservation").value = student.observation || "";
  document.getElementById("studentStatus").value = student.status || "actif";
  resetPersonFileDraft("student", student);
  setView("students");
}

function prepareEnrollmentForStudent(id) {
  const student = getStudent(id);
  if (!student) return;
  resetEnrollmentForm();
  setView("enrollments");
  document.getElementById("enrollmentStudent").value = String(student.id);
  if (student.desiredCourseId && getCourse(student.desiredCourseId)) {
    document.getElementById("enrollmentCourse").value = String(student.desiredCourseId);
    syncEnrollmentGroups();
    applyCourseCostToEnrollment();
  }
  document.getElementById("enrollmentStatus").value = "validee";
  document.getElementById("enrollmentCourse").focus();
  showToast(`Inscription preparee pour ${fullName(student)}`);
}

function editCourse(id) {
  const course = getCourse(id);
  if (!course) return;
  const form = document.getElementById("courseForm");
  form.dataset.editId = id;
  document.getElementById("courseFormTitle").textContent = "Modifier formation";
  document.getElementById("courseCode").value = course.code || "";
  document.getElementById("courseName").value = course.name || "";
  document.getElementById("courseDuration").value = course.duration || "";
  document.getElementById("courseRegistrationFee").value = course.registrationFee || 0;
  document.getElementById("courseTrainingFee").value = course.trainingFee || 0;
  document.getElementById("courseMonthlyFee").value = course.monthlyFee || 0;
  document.getElementById("courseDescription").value = course.description || "";
  document.getElementById("courseStatus").value = course.status || "active";
  setView("courses");
}

function editGroup(id) {
  const group = getGroup(id);
  if (!group) return;
  const form = document.getElementById("groupForm");
  form.dataset.editId = id;
  document.getElementById("groupFormTitle").textContent = "Modifier promotion";
  document.getElementById("groupName").value = group.name || "";
  document.getElementById("groupCourse").value = group.courseId;
  document.getElementById("groupYear").value = group.year || "";
  document.getElementById("groupSessionType").value = group.sessionType || "jour";
  const trainerSelect = document.getElementById("groupTrainer");
  const trainerId = Number(group.trainerId || 0);
  if (trainerId && [...trainerSelect.options].some(option => Number(option.value) === trainerId)) {
    trainerSelect.value = String(trainerId);
  } else {
    const trainerMatch = state.trainers.find(trainer => trainerName(trainer) === group.trainer);
    trainerSelect.value = trainerMatch ? String(trainerMatch.id) : "";
  }
  document.getElementById("groupCapacity").value = group.capacity || "";
  document.getElementById("groupStartDate").value = group.startDate || "";
  document.getElementById("groupEndDate").value = group.endDate || "";
  document.getElementById("groupStatus").value = group.status || "active";
  setView("groups");
}

function editEnrollment(id) {
  const enrollment = getEnrollment(id);
  if (!enrollment) return;
  const form = document.getElementById("enrollmentForm");
  form.dataset.editId = id;
  document.getElementById("enrollmentFormTitle").textContent = "Modifier inscription";
  document.getElementById("enrollmentStudent").value = enrollment.studentId;
  document.getElementById("enrollmentCourse").value = enrollment.courseId;
  syncEnrollmentGroups();
  document.getElementById("enrollmentGroup").value = enrollment.groupId;
  document.getElementById("enrollmentDate").value = enrollment.date || today();
  document.getElementById("enrollmentTotal").value = enrollment.totalAmount || 0;
  document.getElementById("enrollmentDiscount").value = enrollment.discountAmount || 0;
  document.getElementById("enrollmentFinal").value = enrollment.finalAmount || 0;
  document.getElementById("enrollmentMonthlyFee").value = enrollment.monthlyFee || getCourse(enrollment.courseId)?.monthlyFee || 0;
  document.getElementById("enrollmentStatus").value = enrollment.status || "validee";
  setView("enrollments");
}

function editPayment(id) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut corriger un paiement");
    return;
  }
  const payment = findById(state.payments, id);
  if (!payment) return;
  const form = document.getElementById("paymentForm");
  form.dataset.editId = id;
  setView("payments");
  document.getElementById("paymentFormTitle").textContent = `Modifier ${payment.receiptNumber || "paiement"}`;
  document.getElementById("paymentSubmitButton").textContent = "Enregistrer la correction";
  document.getElementById("paymentCancelEdit").hidden = false;
  document.getElementById("paymentEnrollment").value = payment.enrollmentId;
  document.getElementById("paymentReason").value = payment.reasonKey || "scolarite";
  updatePaymentBalance();
  updatePaymentReasonFields();
  document.getElementById("paymentAmount").value = payment.amount || 0;
  document.getElementById("paymentMethod").value = payment.method || "EspÃ¨ce";
  document.getElementById("paymentDate").value = payment.date || today();
  document.getElementById("paymentAmount").focus();
}

function editTrainer(id) {
  const trainer = getTrainer(id);
  if (!trainer) return;
  const form = document.getElementById("trainerForm");
  form.dataset.editId = id;
  document.getElementById("trainerFormTitle").textContent = "Modifier formateur";
  document.getElementById("trainerFirstName").value = trainer.firstName || "";
  document.getElementById("trainerLastName").value = String(trainer.lastName || "").toUpperCase();
  document.getElementById("trainerPhone").value = trainer.phone || "";
  document.getElementById("trainerEmail").value = trainer.email || "";
  document.getElementById("trainerSpecialty").value = trainer.specialty || "";
  document.getElementById("trainerModules").value = trainer.modules || "";
  document.getElementById("trainerStatus").value = trainer.status || "actif";
  resetPersonFileDraft("trainer", trainer);
  setView("trainers");
}

function editStaff(id) {
  const member = getStaffMember(id);
  if (!member) return;
  const form = document.getElementById("staffForm");
  form.dataset.editId = id;
  document.getElementById("staffFormTitle").textContent = "Modifier personnel";
  document.getElementById("staffFirstName").value = member.firstName || "";
  document.getElementById("staffLastName").value = String(member.lastName || "").toUpperCase();
  document.getElementById("staffRole").value = member.role || "";
  document.getElementById("staffSalary").value = member.salary || 0;
  document.getElementById("staffPhone").value = member.phone || "";
  document.getElementById("staffEmail").value = member.email || "";
  document.getElementById("staffStatus").value = member.status || "actif";
  resetPersonFileDraft("staff", member);
  setView("staff");
}

function editEvaluation(id) {
  const evaluation = getEvaluation(id);
  if (!evaluation) return;
  setView("grades");
  const form = document.getElementById("evaluationForm");
  form.dataset.editId = id;
  document.getElementById("evaluationFormTitle").textContent = "Modifier Ã©valuation";
  document.getElementById("evaluationTitle").value = evaluation.title || "";
  document.getElementById("evaluationGroup").value = evaluation.groupId;
  document.getElementById("evaluationTrainer").value = evaluation.trainerId || "";
  document.getElementById("evaluationType").value = evaluation.type || "devoir";
  document.getElementById("evaluationDate").value = evaluation.date || today();
  document.getElementById("evaluationMaxScore").value = evaluation.maxScore || 20;
  updateEvaluationStudents(evaluation.grades || []);
}

function cleanupStudentLinks(id) {
  const enrollmentIds = state.enrollments
    .filter(enrollment => Number(enrollment.studentId) === id)
    .map(enrollment => Number(enrollment.id));
  const enrollmentIdSet = new Set(enrollmentIds);
  const paymentCount = state.payments.filter(payment => enrollmentIdSet.has(Number(payment.enrollmentId))).length;
  state.payments = state.payments.filter(payment => !enrollmentIdSet.has(Number(payment.enrollmentId)));
  state.enrollments = state.enrollments.filter(enrollment => Number(enrollment.studentId) !== id);
  state.attendanceSessions = state.attendanceSessions.map(session => ({
    ...session,
    records: (session.records || []).filter(record => Number(record.studentId) !== id)
  }));
  state.evaluations = state.evaluations.map(evaluation => ({
    ...evaluation,
    grades: (evaluation.grades || []).filter(grade => Number(grade.studentId) !== id)
  }));
  return { enrollments: enrollmentIds.length, payments: paymentCount };
}

function enrollmentLinkedUsage(enrollment) {
  if (!enrollment) return { payments: 0, attendance: 0, grades: 0 };
  const enrollmentId = Number(enrollment.id);
  const studentId = Number(enrollment.studentId);
  const groupId = Number(enrollment.groupId);
  return {
    payments: state.payments.filter(payment => Number(payment.enrollmentId) === enrollmentId).length,
    attendance: state.attendanceSessions.reduce((count, session) => {
      if (Number(session.groupId) !== groupId) return count;
      return count + (session.records || []).filter(record => Number(record.studentId) === studentId).length;
    }, 0),
    grades: state.evaluations.reduce((count, evaluation) => {
      if (Number(evaluation.groupId) !== groupId) return count;
      return count + (evaluation.grades || []).filter(grade => Number(grade.studentId) === studentId).length;
    }, 0)
  };
}

function cleanupEnrollmentLinks(enrollment) {
  const enrollmentId = Number(enrollment.id);
  const studentId = Number(enrollment.studentId);
  const groupId = Number(enrollment.groupId);
  const usage = enrollmentLinkedUsage(enrollment);
  state.payments = state.payments.filter(payment => Number(payment.enrollmentId) !== enrollmentId);
  state.attendanceSessions = state.attendanceSessions.map(session => (
    Number(session.groupId) === groupId
      ? {
          ...session,
          records: (session.records || []).filter(record => Number(record.studentId) !== studentId)
        }
      : session
  ));
  state.evaluations = state.evaluations.map(evaluation => (
    Number(evaluation.groupId) === groupId
      ? {
          ...evaluation,
          grades: (evaluation.grades || []).filter(grade => Number(grade.studentId) !== studentId)
        }
      : evaluation
  ));
  return usage;
}

async function deleteEnrollment(id) {
  const enrollment = getEnrollment(id);
  if (!enrollment) return;
  const usage = enrollmentLinkedUsage(enrollment);
  const hasLinks = usage.payments || usage.attendance || usage.grades;
  if (hasLinks && !isCleanupModeActive()) {
    showToast("Suppression bloquee : inscription liee a des paiements, presences ou notes. Activez le nettoyage test dans Parametres.");
    return;
  }
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const message = hasLinks
    ? `Mode nettoyage test actif : supprimer l'inscription de ${fullName(student)} en ${course?.name || "formation"} avec ${usage.payments} paiement(s), ${usage.attendance} presence(s) et ${usage.grades} note(s) liee(s) ?`
    : `Supprimer l'inscription de ${fullName(student)} en ${course?.name || "formation"} ?`;
  if (!confirm(message)) return;
  const cleanup = hasLinks ? cleanupEnrollmentLinks(enrollment) : usage;
  state.enrollments = state.enrollments.filter(item => Number(item.id) !== Number(id));
  const saved = await saveState({ immediate: true });
  if (!saved) return;
  resetEnrollmentForm();
  render();
  showToast(hasLinks
    ? `Inscription supprimee avec ${cleanup.payments} paiement(s), ${cleanup.attendance} presence(s) et ${cleanup.grades} note(s)`
    : "Inscription supprimee");
}

async function deleteStudent(id) {
  const linkedEnrollments = state.enrollments.filter(enrollment => Number(enrollment.studentId) === id);
  if (linkedEnrollments.length && !isCleanupModeActive()) {
    showToast("Suppression bloquÃ©e : Ã©tudiant inscrit. Activez le nettoyage test dans ParamÃ¨tres.");
    return;
  }
  const message = linkedEnrollments.length
    ? "Mode nettoyage test actif : supprimer cet Ã©tudiant avec ses inscriptions, paiements, prÃ©sences et notes ?"
    : "Supprimer cet Ã©tudiant ?";
  if (!confirm(message)) return;
  const cleanup = linkedEnrollments.length ? cleanupStudentLinks(id) : { enrollments: 0, payments: 0 };
  state.students = state.students.filter(student => Number(student.id) !== id);
  const saved = await saveState({ immediate: true });
  if (!saved) return;
  render();
  showToast(cleanup.enrollments
    ? `Ã‰tudiant supprimÃ© avec ${cleanup.enrollments} inscription(s) et ${cleanup.payments} paiement(s)`
    : "Ã‰tudiant supprimÃ©");
}

function deleteCourse(id) {
  if (state.enrollments.some(enrollment => Number(enrollment.courseId) === id)) {
    showToast("Suppression bloquÃ©e : formation utilisÃ©e");
    return;
  }
  if (!confirm("Supprimer cette formation ?")) return;
  state.courses = state.courses.filter(course => Number(course.id) !== id);
  saveState();
  render();
  showToast("Formation supprimÃ©e");
}

function deleteGroup(id) {
  if (state.enrollments.some(enrollment => Number(enrollment.groupId) === id)) {
    showToast("Suppression bloquÃ©e : promotion utilisÃ©e");
    return;
  }
  if (!confirm("Supprimer cette promotion ?")) return;
  state.groups = state.groups.filter(group => Number(group.id) !== id);
  saveState();
  render();
  showToast("Promotion supprimÃ©e");
}

function deletePayment(id) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut supprimer un paiement");
    return;
  }
  const payment = findById(state.payments, id);
  if (!payment) return;
  const controlReason = controlledPaymentReason("Suppression du paiement");
  if (!controlReason) return;
  if (!confirm("Supprimer ce paiement ?")) return;
  logPaymentControl("Suppression", payment, controlReason, paymentSnapshot(payment), null);
  state.payments = state.payments.filter(payment => Number(payment.id) !== id);
  saveState();
  resetPaymentForm();
  render();
  showToast("Paiement supprime avec controle");
}

function deleteCashEntry(id) {
  const entry = findById(state.cashEntries, id);
  if (entry?.closedAt && !isAdmin()) {
    showToast("Operation cloturee : seul l'administrateur peut la supprimer");
    return;
  }
  if (!confirm("Supprimer cette opÃ©ration de caisse ?")) return;
  state.cashEntries = state.cashEntries.filter(entry => Number(entry.id) !== id);
  saveState();
  render();
  showToast("OpÃ©ration supprimÃ©e");
}

function deletePaymentMotif(key) {
  if (key === "scolarite" || key === MAKEUP_MOTIF_KEY) {
    showToast("Ce motif est obligatoire");
    return;
  }
  collectPaymentMotifInputs();
  if (state.payments.some(payment => payment.reasonKey === key)) {
    showToast("Suppression bloquÃ©e : motif dÃ©jÃ  utilisÃ©");
    return;
  }
  if (!confirm("Supprimer ce motif ?")) return;
  state.paymentMotifs = state.paymentMotifs.filter(motif => motif.key !== key);
  saveState();
  render();
  showToast("Motif supprimÃ©");
}

function deleteUserAccess(id) {
  if (!isAdmin()) return;
  if (!state.users.length) {
    showToast("Liste des utilisateurs non chargee. Rechargez la page.");
    return;
  }
  const user = state.users.find(item => Number(item.id) === id);
  if (!user || roleCode(user.role) === "administrateur" || roleCode(user.role) === "admin") {
    showToast("Le compte administrateur ne peut pas Ãªtre supprimÃ©");
    return;
  }
  collectCurrentUserAccessDraft();
  if (!confirm("Desactiver cet utilisateur ? Il ne pourra plus se connecter.")) return;
  state.users = state.users.map(item => (
    Number(item.id) === id
      ? { ...item, status: "inactive", updatedAt: new Date().toISOString() }
      : item
  ));
  saveState();
  renderSettings();
  showToast("Utilisateur desactive");
}

async function deleteTrainer(id) {
  const usedInEvaluations = state.evaluations.some(evaluation => Number(evaluation.trainerId) === id);
  const usedInPayroll = state.staffPayments.some(payment => payment.payeeType === "trainer" && Number(payment.payeeId) === id);
  if ((usedInEvaluations || usedInPayroll) && !isCleanupModeActive()) {
    showToast("Suppression bloquÃ©e : formateur utilisÃ©. Activez le nettoyage test dans ParamÃ¨tres.");
    return;
  }
  const message = usedInEvaluations || usedInPayroll
    ? "Mode nettoyage test actif : supprimer ce formateur et retirer ses Ã©valuations/paiements liÃ©s ?"
    : "Supprimer ce formateur ?";
  if (!confirm(message)) return;
  if (usedInEvaluations || usedInPayroll) {
    state.evaluations = state.evaluations.map(evaluation => (
      Number(evaluation.trainerId) === id ? { ...evaluation, trainerId: 0 } : evaluation
    ));
    state.staffPayments = state.staffPayments.filter(payment => !(payment.payeeType === "trainer" && Number(payment.payeeId) === id));
    state.trainerAttendanceSessions = state.trainerAttendanceSessions.map(session => ({
      ...session,
      records: (session.records || []).filter(record => Number(record.trainerId) !== id)
    }));
  }
  state.trainers = state.trainers.filter(trainer => Number(trainer.id) !== id);
  const saved = await saveState({ immediate: true });
  if (!saved) return;
  render();
  showToast("Formateur supprimÃ©");
}

async function deleteStaff(id) {
  const hasPayments = state.staffPayments.some(payment => (payment.payeeType || "staff") === "staff" && Number(payment.payeeId || payment.staffId) === id);
  if (hasPayments && !isCleanupModeActive()) {
    showToast("Suppression bloquÃ©e : paiements enregistrÃ©s. Activez le nettoyage test dans ParamÃ¨tres.");
    return;
  }
  const message = hasPayments
    ? "Mode nettoyage test actif : supprimer ce personnel et ses paiements liÃ©s ?"
    : "Supprimer ce personnel ?";
  if (!confirm(message)) return;
  if (hasPayments) {
    state.staffPayments = state.staffPayments.filter(payment => !((payment.payeeType || "staff") === "staff" && Number(payment.payeeId || payment.staffId) === id));
  }
  state.staffMembers = state.staffMembers.filter(member => Number(member.id) !== id);
  const saved = await saveState({ immediate: true });
  if (!saved) return;
  render();
  showToast("Personnel supprimÃ©");
}

function deleteStaffPayment(id) {
  if (!confirm("Supprimer ce paiement personnel ?")) return;
  state.staffPayments = state.staffPayments.filter(payment => Number(payment.id) !== id);
  saveState();
  render();
  showToast("Paiement personnel supprime");
}

function deleteEvaluation(id) {
  if (!confirm("Supprimer cette evaluation ?")) return;
  state.evaluations = state.evaluations.filter(evaluation => Number(evaluation.id) !== id);
  saveState();
  render();
  showToast("Evaluation supprimee");
}

function resetStudentForm() {
  const form = document.getElementById("studentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("studentFormTitle").textContent = "Nouvel Ã©tudiant";
  document.getElementById("studentMatricule").value = generateMatricule(yearFromDate());
  updateStudentMatriculeLock();
  document.getElementById("studentStatus").value = "actif";
  document.getElementById("studentNationality").value = "Togolaise";
  document.getElementById("studentCity").value = "Lome";
  document.getElementById("studentCountry").value = "Togo";
  document.getElementById("studentDesiredCourse").value = "";
  document.getElementById("studentSource").value = "";
  resetPersonFileDraft("student");
}

function resetCourseForm() {
  const form = document.getElementById("courseForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("courseFormTitle").textContent = "Nouvelle formation";
  document.getElementById("courseStatus").value = "active";
}

function resetGroupForm() {
  const form = document.getElementById("groupForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("groupFormTitle").textContent = "Nouvelle promotion";
  document.getElementById("groupYear").value = String(new Date().getFullYear());
  document.getElementById("groupSessionType").value = "jour";
  document.getElementById("groupCourse").value = "";
  document.getElementById("groupTrainer").value = "";
}

function resetEnrollmentForm() {
  const form = document.getElementById("enrollmentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("enrollmentFormTitle").textContent = "Nouvelle inscription";
  document.getElementById("enrollmentDate").value = today();
  document.getElementById("enrollmentDiscount").value = 0;
  syncSelects();
  document.getElementById("enrollmentStudent").value = "";
  document.getElementById("enrollmentCourse").value = "";
  syncEnrollmentGroups();
  document.getElementById("enrollmentTotal").value = "";
  document.getElementById("enrollmentFinal").value = "";
  document.getElementById("enrollmentMonthlyFee").value = "";
}

function resetPaymentForm() {
  const form = document.getElementById("paymentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("paymentFormTitle").textContent = "Nouveau paiement";
  document.getElementById("paymentSubmitButton").textContent = "Encaisser";
  document.getElementById("paymentCancelEdit").hidden = true;
  document.getElementById("paymentDate").value = today();
  syncSelects();
  document.getElementById("paymentEnrollment").value = "";
  updatePaymentBalance();
  updatePaymentReasonFields();
}

function resetTrainerForm() {
  const form = document.getElementById("trainerForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("trainerFormTitle").textContent = "Nouveau formateur";
  document.getElementById("trainerStatus").value = "actif";
  resetPersonFileDraft("trainer");
}

function resetStaffForm() {
  const form = document.getElementById("staffForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("staffFormTitle").textContent = "Nouveau personnel";
  document.getElementById("staffSalary").value = 0;
  document.getElementById("staffStatus").value = "actif";
  resetPersonFileDraft("staff");
}

function resetEvaluationForm() {
  const form = document.getElementById("evaluationForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("evaluationFormTitle").textContent = "Nouvelle Ã©valuation";
  document.getElementById("evaluationDate").value = today();
  document.getElementById("evaluationMaxScore").value = 20;
  syncSelects();
  updateEvaluationStudents();
}

function applyCourseCostToEnrollment() {
  const course = getCourse(document.getElementById("enrollmentCourse").value);
  if (!course) {
    document.getElementById("enrollmentTotal").value = "";
    document.getElementById("enrollmentFinal").value = "";
    document.getElementById("enrollmentMonthlyFee").value = "";
    return;
  }
  document.getElementById("enrollmentTotal").value = courseCost(course);
  document.getElementById("enrollmentMonthlyFee").value = Number(course.monthlyFee || 0);
  updateEnrollmentFinal();
}

function updateEnrollmentFinal() {
  const total = Number(document.getElementById("enrollmentTotal").value || 0);
  const discount = Number(document.getElementById("enrollmentDiscount").value || 0);
  document.getElementById("enrollmentFinal").value = Math.max(0, total - discount);
}

function updatePaymentBalance() {
  const enrollment = getEnrollment(document.getElementById("paymentEnrollment").value);
  const editId = Number(document.getElementById("paymentForm").dataset.editId || 0);
  if (!enrollment) {
    ids.paymentBalance.textContent = "Choisir une inscription";
    return;
  }
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  const balance = editId ? balanceForEnrollmentExcluding(enrollment, editId) : balanceForEnrollment(enrollment);
  const makeupDue = makeupDueForEnrollment(enrollment, editId);
  ids.paymentBalance.innerHTML = `
    ${escapeHtml(fullName(student))} - ${escapeHtml(course?.name || "-")} / ${escapeHtml(group?.name || "-")}
    | Total ${escapeHtml(formatMoney(tuitionExpectedForEnrollment(enrollment)))}
    | Paye ${escapeHtml(formatMoney(paidAmount(enrollment.id)))}
    | Reste ${escapeHtml(formatMoney(balance))}
    ${makeupDue ? `| Rattrapage ${escapeHtml(formatMoney(makeupDue))}` : ""}
  `;
}

function updatePaymentReasonFields() {
  const reason = document.getElementById("paymentReason").value;
  const amountInput = document.getElementById("paymentAmount");
  const motif = getPaymentMotif(reason);
  const selectedEnrollment = getEnrollment(document.getElementById("paymentEnrollment").value);
  if (!selectedEnrollment) {
    amountInput.value = "";
    amountInput.removeAttribute("readonly");
    amountInput.placeholder = "Choisissez d'abord une inscription";
    updatePaymentBalance();
    return;
  }
  if (isTuitionMotifKey(reason)) {
    const enrollment = selectedEnrollment;
    const course = enrollment ? getCourse(enrollment.courseId) : undefined;
    const editId = Number(document.getElementById("paymentForm").dataset.editId || 0);
    const balance = editId ? balanceForEnrollmentExcluding(enrollment, editId) : balanceForEnrollment(enrollment);
    const suggested = Number(course?.monthlyFee || 0) || balance;
    amountInput.value = balance > 0 ? Math.min(suggested, balance) : suggested;
    amountInput.removeAttribute("readonly");
    amountInput.step = "1";
    amountInput.placeholder = "Montant payÃ©";
    return;
  }
  if (isMakeupMotifKey(reason)) {
    const enrollment = selectedEnrollment;
    const editId = Number(document.getElementById("paymentForm").dataset.editId || 0);
    const due = makeupDueForEnrollment(enrollment, editId);
    amountInput.value = due > 0 ? Math.min(MAKEUP_FEE, due) : "";
    amountInput.removeAttribute("readonly");
    amountInput.step = String(MAKEUP_FEE);
    amountInput.placeholder = `Tranche de ${formatMoney(MAKEUP_FEE)}`;
    updatePaymentBalance();
    return;
  }
  amountInput.value = Number(motif?.amount || 0);
  amountInput.setAttribute("readonly", "readonly");
  amountInput.step = "1";
  amountInput.placeholder = "";
}

function startPayment(enrollmentId, reasonKey = "") {
  setView("payments");
  document.getElementById("paymentEnrollment").value = enrollmentId;
  if (reasonKey && [...document.getElementById("paymentReason").options].some(option => option.value === reasonKey)) {
    document.getElementById("paymentReason").value = reasonKey;
  }
  updatePaymentBalance();
  updatePaymentReasonFields();
  document.getElementById("paymentAmount").focus();
}

const amountInput = document.getElementById("paymentAmount");
if (amountInput) {
  amountInput.focus();
}

function receiptSeriesPrefix(reasonKey) {
  if (isTuitionMotifKey(reasonKey)) return "REC-SCO";
  if (isMakeupMotifKey(reasonKey)) return "REC-RAT";
  if (String(reasonKey || "") === "inscription") return "REC-INS";
  return "REC-ANN";
}

function nextReceiptNumber(reasonKey = "scolarite") {
  const year = new Date().getFullYear();
  const prefix = receiptSeriesPrefix(reasonKey);
  const pattern = new RegExp(`^${prefix}-${year}-(\\d+)$`);
  const receiptNumbers = [
    ...state.payments.map(payment => payment.receiptNumber),
    ...state.paymentAuditLog.flatMap(item => [item.receiptNumber, item.before?.receiptNumber, item.after?.receiptNumber])
  ].filter(Boolean);
  const maxNumber = receiptNumbers.reduce((max, receiptNumber) => {
    const match = String(receiptNumber).match(pattern);
    return match ? Math.max(max, Number(match[1]) || 0) : max;
  }, 0);
  return `${prefix}-${year}-${String(maxNumber + 1).padStart(3, "0")}`;
}

function printReceipt(paymentId) {
  const payment = findById(state.payments, paymentId);
  if (!payment) return;
  const enrollment = getEnrollment(payment.enrollmentId);
  const student = enrollment ? getStudent(enrollment.studentId) : undefined;
  const course = enrollment ? getCourse(enrollment.courseId) : undefined;
  const group = enrollment ? getGroup(enrollment.groupId) : undefined;
  const center = state.center || {};
  const logoSrc = normalizeLogoData(center.logoData);
  const stampSrc = normalizeLogoData(center.stampData);
  const tuitionPayment = isTuitionPayment(payment);
  const expected = tuitionPayment ? tuitionExpectedForEnrollment(enrollment) : Number(payment.amount || 0);
  const balance = tuitionPayment ? balanceForEnrollment(enrollment) : 0;
  const academicYear = group?.year || yearFromDate(enrollment?.date || payment.date);
  const receiptTitle = tuitionPayment ? "REÃ‡U DE SCOLARITÃ‰" : "REÃ‡U DE FRAIS ANNEXE";
  const summaryHeaders = tuitionPayment
    ? ["ANNEE", "Formation", "ScolaritÃ©", "Reste scolaritÃ©"]
    : ["ANNEE", "Formation", "Frais annexe", "Statut"];
  const summaryValues = tuitionPayment
    ? [academicYear, course?.code || "-", formatPrintAmount(expected), formatPrintAmount(balance)]
    : [academicYear, course?.code || "-", payment.reason || "Frais annexe", "PayÃ©"];
  const recorder = currentUser?.name || payment.receivedBy || document.getElementById("roleSelect").value;
  const receiptDateTime = formatDateTime(new Date());
  ids.printArea.innerHTML = `
    <section class="print-document receipt-document">
      <header class="receipt-header-grid">
        <div class="receipt-school">
          <h1>${escapeHtml(center.name || "CFP EREXIT")}</h1>
          <p>${escapeHtml(center.subtitle || "Centre de Formation Professionnelle")}</p>
        </div>
        <div class="receipt-republic">
          <h2>REPUBLIQUE TOGOLAISE</h2>
          <p>Travail - LibertÃ© - Patrie</p>
        </div>
      </header>

      <div class="receipt-logo-wrap">
        ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="">` : ""}
      </div>

      <div class="receipt-contact">
        <strong>${center.phone ? `TEL : ${escapeHtml(center.phone)}` : ""}</strong>
        <span>${escapeHtml(center.address || "")}</span>
        ${center.email ? `<span>${escapeHtml(center.email)}</span>` : ""}
      </div>

      <h2 class="receipt-type">${escapeHtml(receiptTitle)}</h2>

      <div class="receipt-topline">
        <div class="receipt-reference">RÃ‰FÃ‰RENCE : ${escapeHtml(payment.receiptNumber)}</div>
        <table class="receipt-summary-table">
          <thead>
            <tr>
              ${summaryHeaders.map(header => `<th>${escapeHtml(header)}</th>`).join("")}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${escapeHtml(summaryValues[0])}</td>
              <td>
                <strong>${escapeHtml(summaryValues[1])}</strong>
                <div>${escapeHtml(groupSessionLabel(group))}</div>
              </td>
              <td>${escapeHtml(summaryValues[2])}</td>
              <td>${escapeHtml(summaryValues[3])}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <h2 class="receipt-student">Ã‰TUDIANT : ${escapeHtml(fullName(student))}</h2>

      <table class="receipt-lines-table">
        <thead>
          <tr>
            <th>LibellÃ©</th>
            <th>Date paiement</th>
            <th>Montant payÃ©</th>
            <th>Mode de paiement</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${escapeHtml(payment.reason || "Paiement")}</td>
            <td>${formatDate(payment.date)}</td>
            <td>${formatPrintAmount(payment.amount)}</td>
            <td>${escapeHtml(payment.method || "-")}</td>
          </tr>
          <tr>
            <td colspan="2"><strong>TOTAL</strong></td>
            <td colspan="2"><strong>${formatPrintAmount(payment.amount)}</strong></td>
          </tr>
        </tbody>
      </table>

      <div class="receipt-extra">
        <p><strong>Matricule :</strong> ${escapeHtml(student?.matricule || "-")}</p>
        <p><strong>Categorie :</strong> ${tuitionPayment ? "Scolarite" : "Frais annexe"}</p>
        <p><strong>Statut du recu :</strong> ${escapeHtml(payment.status || "valide")}</p>
        <p><strong>Montant en lettres :</strong> ${escapeHtml(amountToWords(payment.amount))}</p>
      </div>

      <div class="receipt-responsibles">
        <div>
          <strong>Responsable saisie : ${escapeHtml(recorder)}</strong>
          <span>Ce ${escapeHtml(receiptDateTime)}</span>
        </div>
        <div>
          <strong>Responsable caisse : ${escapeHtml(payment.receivedBy || recorder)}</strong>
          <span>Ce ${escapeHtml(receiptDateTime)}</span>
        </div>
      </div>

      <div class="receipt-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <span>Signature et cachet</span>
      </div>

      <p class="receipt-note"><strong>NB :</strong> Aucun remboursement n'est acceptÃ© aprÃ¨s encaissement. Merci</p>
    </section>
  `;
  showPrintPreview();
}

function printPayrollSlip(paymentId) {
  const payment = state.staffPayments.find(item => Number(item.id) === Number(paymentId));
  if (!payment) return;
  const beneficiary = payrollBeneficiary(payment);
  const title = beneficiary.type === "trainer" ? "Fiche de paie formateur" : "Fiche de paie personnel";
  const center = state.center || {};
  const period = payment.period || today().slice(0, 7);
  const periodLabel = period.includes("-")
    ? new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric" }).format(new Date(`${period}-01T00:00:00`))
    : period;
  const reference = `PAY-${String(payment.id).padStart(5, "0")}`;
  const recorder = payment.recordedBy || currentOperatorName();

  ids.printArea.innerHTML = `
    <section class="print-document payroll-document">
      ${printHeaderHtml(title)}
      <table>
        <tbody>
          <tr><td>Employeur</td><td><strong>${escapeHtml(center.name || "CFP EREXIT")}</strong></td></tr>
          <tr><td>TÃ©lÃ©phone</td><td>${escapeHtml(center.phone || "-")}</td></tr>
          <tr><td>Email</td><td>${escapeHtml(center.email || "-")}</td></tr>
          <tr><td>Adresse</td><td>${escapeHtml(center.address || "-")}</td></tr>
        </tbody>
      </table>

      <h2>BÃ©nÃ©ficiaire</h2>
      <table>
        <tbody>
          <tr><td>BÃ©nÃ©ficiaire</td><td><strong>${escapeHtml(beneficiary.name)}</strong></td></tr>
          <tr><td>CatÃ©gorie</td><td>${escapeHtml(beneficiary.type === "trainer" ? "Formateur" : "Personnel")}</td></tr>
          <tr><td>Fonction / rÃ´le</td><td>${escapeHtml(beneficiary.role || "-")}</td></tr>
          <tr><td>TÃ©lÃ©phone</td><td>${escapeHtml(beneficiary.phone || "-")}</td></tr>
          <tr><td>Email</td><td>${escapeHtml(beneficiary.email || "-")}</td></tr>
          <tr><td>PÃ©riode</td><td>${escapeHtml(periodLabel)}</td></tr>
          <tr><td>Date de paiement</td><td>${formatDate(payment.date)}</td></tr>
          <tr><td>Mode de paiement</td><td>${escapeHtml(payment.method || "-")}</td></tr>
          <tr><td>RÃ©fÃ©rence interne</td><td>${escapeHtml(reference)}</td></tr>
        </tbody>
      </table>

      <table style="margin-top: 20px;">
        <thead>
          <tr>
            <th>LibellÃ©</th>
            <th>Note</th>
            <th>Salaire prÃ©vu</th>
            <th>Montant</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${escapeHtml(payment.reason || "Paiement")}</td>
            <td>${escapeHtml(payment.note || "-")}</td>
            <td>${formatMoney(beneficiary.baseSalary || 0)}</td>
            <td><strong>${formatMoney(payment.amount)}</strong></td>
          </tr>
          <tr>
            <td colspan="3"><strong>Net payÃ©</strong></td>
            <td><strong>${formatMoney(payment.amount)}</strong></td>
          </tr>
        </tbody>
      </table>

      <div class="print-signature-row">
        <p>Responsable caisse<br><span>${escapeHtml(recorder)}</span></p>
        <p>BÃ©nÃ©ficiaire</p>
      </div>
      <p class="muted" style="margin-top: 18px;">Document gÃ©nÃ©rÃ© le ${escapeHtml(formatDateTime(new Date()))}</p>
    </section>
  `;
  showPrintPreview();
}

function printEnrollment(enrollmentId) {
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Fiche d'inscription")}
      <table>
        <tbody>
          <tr><td>Matricule</td><td>${escapeHtml(student?.matricule || "-")}</td></tr>
          <tr><td>Sexe</td><td>${escapeHtml(student?.gender || "-")}</td></tr>
          <tr><td>Date / lieu de naissance</td><td>${escapeHtml([student?.birthDate ? formatDate(student.birthDate) : "", student?.birthPlace || ""].filter(Boolean).join(" - ") || "-")}</td></tr>
          <tr><td>Nationalite</td><td>${escapeHtml(student?.nationality || "-")}</td></tr>
          <tr><td>Adresse complete</td><td>${escapeHtml([student?.address, student?.district, student?.city, student?.country].filter(Boolean).join(", ") || "-")}</td></tr>
          <tr><td>Niveau / situation</td><td>${escapeHtml([student?.studyLevel, student?.profession].filter(Boolean).join(" - ") || "-")}</td></tr>
          <tr><td>Parents</td><td>${escapeHtml([student?.fatherName ? `Pere: ${student.fatherName} ${student.fatherPhone || ""}` : "", student?.motherName ? `Mere: ${student.motherName} ${student.motherPhone || ""}` : ""].filter(Boolean).join(" / ") || "-")}</td></tr>
          <tr><td>Personne a contacter</td><td>${escapeHtml([student?.emergencyName, student?.emergencyPhone].filter(Boolean).join(" - ") || "-")}</td></tr>
          <tr><td>Responsable paiement</td><td>${escapeHtml([student?.paymentResponsible, student?.paymentResponsiblePhone].filter(Boolean).join(" - ") || "-")}</td></tr>
          <tr><td>Source / observation</td><td>${escapeHtml([student?.source, student?.observation].filter(Boolean).join(" - ") || "-")}</td></tr>
          <tr><td>Ã‰tudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>TÃ©lÃ©phone</td><td>${escapeHtml(student?.phone || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Date</td><td>${formatDate(enrollment.date)}</td></tr>
          <tr><td>ScolaritÃ© exigible</td><td>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</td></tr>
          <tr><td>ScolaritÃ© payÃ©e</td><td>${formatMoney(paidAmount(enrollment.id))}</td></tr>
          <tr><td>Frais annexes payÃ©s</td><td>${formatMoney(annexPaidAmount(enrollment.id))}</td></tr>
          <tr><td>Total payÃ©</td><td>${formatMoney(totalPaidAmountForEnrollment(enrollment.id))}</td></tr>
          <tr><td>Reste scolaritÃ©</td><td>${formatMoney(balanceForEnrollment(enrollment))}</td></tr>
        </tbody>
      </table>
      <p style="margin-top: 42px;">Signature et cachet</p>
    </section>
  `;
  showPrintPreview();
}

function printAttestation(enrollmentId) {
  const template = templateByKey("attestation-inscription");
  if (template && template.status !== "archive") {
    printTemplateDocument("attestation-inscription", { enrollmentId });
    return;
  }
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  const center = state.center || {};
  const stampSrc = normalizeLogoData(center.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Attestation d'inscription")}
      <p style="margin-top: 28px; line-height: 1.8; font-size: 15px;">
        Nous soussignÃ©s <strong>${escapeHtml(center.name || "CFP EREXIT")}</strong>,
        attestons que <strong>${escapeHtml(fullName(student))}</strong>,
        matricule <strong>${escapeHtml(student?.matricule || "-")}</strong>, est rÃ©guliÃ¨rement inscrit(e)
        Ã  la formation <strong>${escapeHtml(course?.name || "-")}</strong>,
        promotion <strong>${escapeHtml(group?.name || "-")}</strong>
        (${escapeHtml(groupSessionLabel(group))}), pour l'annÃ©e ${escapeHtml(group?.year || yearFromDate(enrollment.date))}.
      </p>
      <table style="margin-top: 22px;">
        <tbody>
          <tr><td>Date d'inscription</td><td>${formatDate(enrollment.date)}</td></tr>
          <tr><td>ScolaritÃ© exigible</td><td>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</td></tr>
          <tr><td>ScolaritÃ© payÃ©e</td><td>${formatMoney(paidAmount(enrollment.id))}</td></tr>
          <tr><td>Reste scolaritÃ©</td><td>${formatMoney(balanceForEnrollment(enrollment))}</td></tr>
        </tbody>
      </table>
      <p style="margin-top: 28px;">Fait pour servir et valoir ce que de droit.</p>
      <div class="document-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <strong>Signature et cachet</strong>
      </div>
    </section>
  `;
  showPrintPreview();
}

function printTrainingContract(enrollmentId) {
  const template = templateByKey("contrat-formation");
  if (template && template.status !== "archive") {
    printTemplateDocument("contrat-formation", { enrollmentId });
    return;
  }
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  const center = state.center || {};
  const stampSrc = normalizeLogoData(center.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Contrat de formation")}
      <table>
        <tbody>
          <tr><td>Centre</td><td>${escapeHtml(center.name || "CFP EREXIT")}</td></tr>
          <tr><td>Ã‰tudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Matricule</td><td>${escapeHtml(student?.matricule || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>DurÃ©e</td><td>${escapeHtml(course?.duration || "-")}</td></tr>
          <tr><td>ScolaritÃ© exigible</td><td>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</td></tr>
          <tr><td>MensualitÃ© indicative</td><td>${formatMoney(course?.monthlyFee || 0)}</td></tr>
        </tbody>
      </table>
      <h2>Engagements</h2>
      <p>L'Ã©tudiant s'engage Ã  respecter le rÃ¨glement intÃ©rieur, les horaires, le programme pÃ©dagogique et les modalitÃ©s de paiement convenues.</p>
      <p>Le centre s'engage Ã  assurer la formation conformÃ©ment au programme prÃ©vu et Ã  suivre la progression de l'Ã©tudiant.</p>
      <div class="contract-signatures">
        <div>
          <strong>L'Ã©tudiant</strong>
          <span>Signature</span>
        </div>
        <div>
          ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
          <strong>Le centre</strong>
          <span>Signature et cachet</span>
        </div>
      </div>
    </section>
  `;
  showPrintPreview();
}

function printBalancesReport() {
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(`Rapport des restes scolaritÃ© - ${formatDate(today())}`)}
      <table>
        <thead>
          <tr>
            <th>Ã‰tudiant</th>
            <th>Formation</th>
            <th>Type</th>
            <th>ScolaritÃ© exigible</th>
            <th>ScolaritÃ© payÃ©e</th>
            <th>Reste scolaritÃ©</th>
          </tr>
        </thead>
        <tbody>
          ${balances().map(item => `
            <tr>
              <td>${escapeHtml(item.student)}</td>
              <td>${escapeHtml(item.course)}</td>
              <td>${escapeHtml(item.sessionType)}</td>
              <td>${formatMoney(item.tuitionExpected)}</td>
              <td>${formatMoney(item.paid)}</td>
              <td>${formatMoney(item.balance)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </section>
  `;
  showPrintPreview();
}

function printIndividualStudentReport() {
  const report = individualStudentReportData();
  const { student, enrollments, payments, paymentsByMotif, tuitionExpected, tuitionPaid, annexPaid, totalPaid, balance } = report;
  if (!student) {
    showToast("Aucun Ã©tudiant sÃ©lectionnÃ©");
    return;
  }

  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(`Rapport individuel Ã©tudiant - ${formatDate(today())}`)}
      <table>
        <tbody>
          <tr><td>Matricule</td><td>${escapeHtml(student.matricule || "-")}</td></tr>
          <tr><td>Ã‰tudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>TÃ©lÃ©phone</td><td>${escapeHtml(student.phone || "-")}</td></tr>
          <tr><td>Email</td><td>${escapeHtml(student.email || "-")}</td></tr>
          <tr><td>Adresse</td><td>${escapeHtml(student.address || "-")}</td></tr>
          <tr><td>Statut</td><td>${escapeHtml(student.status || "-")}</td></tr>
        </tbody>
      </table>

      <h2>Inscriptions</h2>
      <table>
        <thead>
          <tr>
            <th>Formation</th>
            <th>Promotion</th>
            <th>Type</th>
            <th>Date</th>
            <th>ScolaritÃ© exigible</th>
            <th>Reste</th>
          </tr>
        </thead>
        <tbody>
          ${enrollments.map(enrollment => {
            const course = getCourse(enrollment.courseId);
            const group = getGroup(enrollment.groupId);
            return `
              <tr>
                <td>${escapeHtml(course?.name || "-")}</td>
                <td>${escapeHtml(group?.name || "-")}</td>
                <td>${escapeHtml(groupSessionLabel(group))}</td>
                <td>${formatDate(enrollment.date)}</td>
                <td>${formatMoney(tuitionExpectedForEnrollment(enrollment))}</td>
                <td>${formatMoney(balanceForEnrollment(enrollment))}</td>
              </tr>
            `;
          }).join("") || `<tr><td colspan="6">Aucune inscription</td></tr>`}
        </tbody>
      </table>

      <h2>SynthÃ¨se financiÃ¨re</h2>
      <table>
        <tbody>
          <tr><td>ScolaritÃ© due</td><td>${formatMoney(tuitionExpected)}</td></tr>
          <tr><td>ScolaritÃ© payÃ©e</td><td>${formatMoney(tuitionPaid)}</td></tr>
          <tr><td>Reste scolaritÃ©</td><td>${formatMoney(balance)}</td></tr>
          <tr><td>Frais annexes payÃ©s</td><td>${formatMoney(annexPaid)}</td></tr>
          <tr><td>Total payÃ©</td><td><strong>${formatMoney(totalPaid)}</strong></td></tr>
        </tbody>
      </table>

      <h2>DÃ©tail par motif</h2>
      <table>
        <thead>
          <tr>
            <th>Motif</th>
            <th>CatÃ©gorie</th>
            <th>Montant payÃ©</th>
            <th>Dernier paiement</th>
          </tr>
        </thead>
        <tbody>
          ${paymentsByMotif.map(item => `
            <tr>
              <td>${escapeHtml(item.reason)}</td>
              <td>${escapeHtml(item.category)}</td>
              <td>${formatMoney(item.amount)}</td>
              <td>${formatDate(item.lastDate)}</td>
            </tr>
          `).join("") || `<tr><td colspan="4">Aucun paiement</td></tr>`}
        </tbody>
      </table>

      <h2>Historique des paiements</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>ReÃ§u</th>
            <th>Motif</th>
            <th>CatÃ©gorie</th>
            <th>Montant</th>
            <th>Mode</th>
          </tr>
        </thead>
        <tbody>
          ${payments.map(payment => `
            <tr>
              <td>${formatDate(payment.date)}</td>
              <td>${escapeHtml(payment.receiptNumber || "-")}</td>
              <td>${escapeHtml(payment.reason || "-")}</td>
              <td>${isTuitionPayment(payment) ? "ScolaritÃ©" : "Frais annexe"}</td>
              <td>${formatMoney(payment.amount)}</td>
              <td>${escapeHtml(payment.method || "-")}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucun paiement</td></tr>`}
        </tbody>
      </table>

      <h2>Notes et Ã©valuations</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Ã‰valuation</th>
            <th>Type</th>
            <th>Note</th>
            <th>Statut</th>
            <th>ApprÃ©ciation</th>
          </tr>
        </thead>
        <tbody>
          ${studentGradeRows(student.id).map(row => `
            <tr>
              <td>${formatDate(row.date)}</td>
              <td>${escapeHtml(row.title)}</td>
              <td>${escapeHtml(row.type)}</td>
              <td>${escapeHtml(row.score)}</td>
              <td>${escapeHtml(row.status)}</td>
              <td>${escapeHtml(row.needsMakeup ? "Non validÃ©" : (row.appreciation || ""))}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucune note</td></tr>`}
        </tbody>
      </table>

      <p style="margin-top: 42px;">Signature et cachet</p>
    </section>
  `;
  showPrintPreview();
}

function printStudentTranscript(studentId = Number(ids.individualReportStudent?.value || 0)) {
  const student = getStudent(studentId);
  if (!student) {
    showToast("Choisissez un Ã©tudiant");
    return;
  }

  const rows = studentGradeRows(student.id);
  const scoredRows = rows.filter(row => row.score20 !== null);
  const average20 = scoredRows.length
    ? scoredRows.reduce((sum, row) => sum + Number(row.score20 || 0), 0) / scoredRows.length
    : null;
  const enrollment = state.enrollments.find(item => Number(item.studentId) === Number(student.id));
  const course = enrollment ? getCourse(enrollment.courseId) : null;
  const group = enrollment ? getGroup(enrollment.groupId) : null;

  ids.printArea.innerHTML = `
    <section class="print-document transcript-document">
      ${printHeaderHtml("RelevÃ© de notes")}
      <table>
        <tbody>
          <tr><td>Ã‰tudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Matricule</td><td>${escapeHtml(student.matricule || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Condition de validation</td><td>${PASSING_SCORE_20}/20 minimum par matiÃ¨re</td></tr>
        </tbody>
      </table>

      <div class="transcript-summary">
        <div><span>Moyenne gÃ©nÃ©rale</span><strong>${average20 === null ? "-" : `${average20.toFixed(2)} / 20`}</strong></div>
        <div><span>MatiÃ¨res Ã©valuÃ©es</span><strong>${rows.length}</strong></div>
        <div><span>MatiÃ¨res validÃ©es</span><strong>${rows.filter(row => !row.needsMakeup && row.score20 !== null).length}</strong></div>
        <div><span>MatiÃ¨res non validÃ©es</span><strong>${rows.filter(row => row.needsMakeup).length}</strong></div>
      </div>

      <table style="margin-top: 18px;">
        <thead>
          <tr>
            <th>Date</th>
            <th>MatiÃ¨re / Ã‰valuation</th>
            <th>Promotion</th>
            <th>Note</th>
            <th>Statut</th>
            <th>ApprÃ©ciation</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map(row => `
            <tr>
              <td>${formatDate(row.date)}</td>
              <td>${escapeHtml(row.title)}</td>
              <td>${escapeHtml(row.groupName)}</td>
              <td>${escapeHtml(row.score)}</td>
              <td>${escapeHtml(row.status)}</td>
              <td>${escapeHtml(row.needsMakeup ? "Non validÃ©" : (row.appreciation || ""))}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucune note enregistrÃ©e</td></tr>`}
        </tbody>
      </table>

      <div class="print-signature-row">
        <p>Direction des Ã©tudes</p>
        <p>Signature et cachet</p>
      </div>
    </section>
  `;
  showPrintPreview();
}

function studentGradeRows(studentId) {
  return state.evaluations.flatMap(evaluation => {
    const grade = (evaluation.grades || []).find(item => Number(item.studentId) === Number(studentId));
    if (!grade) return [];
    const maxScore = Number(evaluation.maxScore || 20);
    const needsMakeup = gradeNeedsMakeup(grade.score, maxScore);
    const group = getGroup(evaluation.groupId);
    const scoreNumber = Number(grade.score);
    return [{
      date: evaluation.date,
      title: evaluation.title,
      type: evaluation.type || "-",
      groupName: group?.name || "-",
      sessionType: groupSessionLabel(group),
      rawScore: Number.isNaN(scoreNumber) ? null : scoreNumber,
      maxScore,
      score20: Number.isNaN(scoreNumber) ? null : scoreNumber * 20 / maxScore,
      score: grade.score === "" ? "-" : `${grade.score} / ${maxScore}`,
      status: gradeStatusLabel(grade.score, maxScore),
      needsMakeup,
      makeupFee: needsMakeup ? MAKEUP_FEE : 0,
      appreciation: grade.appreciation || ""
    }];
  }).sort((a, b) => String(a.date).localeCompare(String(b.date)));
}

function printGradesReport(evaluationId) {
  const evaluation = getEvaluation(evaluationId);
  if (!evaluation) return;
  const group = getGroup(evaluation.groupId);
  const trainer = getTrainer(evaluation.trainerId);
  const maxScore = Number(evaluation.maxScore || 20);
  const grades = Array.isArray(evaluation.grades) ? evaluation.grades : [];
  const makeup = evaluationMakeupStats(evaluation);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Releve de notes")}
      <table>
        <tbody>
          <tr><td>Evaluation</td><td><strong>${escapeHtml(evaluation.title)}</strong></td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Formateur</td><td>${escapeHtml(trainerName(trainer))}</td></tr>
          <tr><td>Date</td><td>${formatDate(evaluation.date)}</td></tr>
          <tr><td>Moyenne</td><td>${formatAverage(evaluation)}</td></tr>
          <tr><td>Condition de validation</td><td>${PASSING_SCORE_20}/20 minimum par matiÃ¨re</td></tr>
          <tr><td>MatiÃ¨res non validÃ©es</td><td>${makeup.count} Ã©tudiant(s)</td></tr>
        </tbody>
      </table>
      <table style="margin-top: 18px;">
        <thead>
          <tr>
            <th>Matricule</th>
            <th>Ã‰tudiant</th>
            <th>Note</th>
            <th>Statut</th>
            <th>Appreciation</th>
          </tr>
        </thead>
        <tbody>
          ${grades.map(grade => {
            const student = getStudent(grade.studentId);
            return `
              <tr>
                <td>${escapeHtml(student?.matricule || "-")}</td>
                <td>${escapeHtml(fullName(student))}</td>
                <td>${grade.score === "" ? "-" : `${escapeHtml(grade.score)} / ${maxScore}`}</td>
                <td>${escapeHtml(gradeStatusLabel(grade.score, maxScore))}</td>
                <td>${escapeHtml(gradeNeedsMakeup(grade.score, maxScore) ? "Non validÃ©" : (grade.appreciation || ""))}</td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
      <p style="margin-top: 42px;">Signature du formateur</p>
    </section>
  `;
  showPrintPreview();
}

function exportPaymentsCsv(filename = "paiements-cfp-erexit.csv") {
  const rows = state.payments.map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return [
      payment.receiptNumber,
      fullName(student),
      payment.amount,
      payment.method,
      payment.reason,
      isTuitionPayment(payment) ? "ScolaritÃ©" : "Frais annexe",
      payment.date
    ];
  });
  downloadCsv(filename, ["ReÃ§u", "Ã‰tudiant", "Montant", "Mode", "Motif", "CatÃ©gorie", "Date"], rows);
}

function exportCashCsv(filename = "caisse-cfp-erexit.csv") {
  const rows = cashLedgerEntries().map(entry => [
    entry.date,
    entry.type === "income" ? "EntrÃ©e" : "DÃ©pense",
    entry.category,
    entry.amount,
    entry.method,
    entry.description,
    entry.recordedBy,
    entry.locked ? "Automatique" : "Manuel"
  ]);
  downloadCsv(filename, ["Date", "Type", "CatÃ©gorie", "Montant", "Mode", "Description", "Saisi par", "Origine"], rows);
}

function exportStudentsCsv(filename = "etudiants-cfp-erexit.csv") {
  const rows = state.students.map(student => [
    student.matricule,
    student.lastName,
    student.firstName,
    student.phone,
    student.email,
    student.status
  ]);
  downloadCsv(filename, ["Matricule", "Nom", "PrÃ©nom", "TÃ©lÃ©phone", "Email", "Statut"], rows);
}

function exportAllCsv() {
  const stamp = exportStamp();
  exportPaymentsCsv(`paiements-cfp-erexit-${stamp}.csv`);
  exportCashCsv(`caisse-cfp-erexit-${stamp}.csv`);
  exportStudentsCsv(`etudiants-cfp-erexit-${stamp}.csv`);
  exportEnrollmentsCsv(`inscriptions-cfp-erexit-${stamp}.csv`);
  exportStaffPaymentsCsv(`paiements-personnel-cfp-erexit-${stamp}.csv`);
  showToast("Exports CSV gÃ©nÃ©rÃ©s");
}

function exportEnrollmentsCsv(filename = "inscriptions-cfp-erexit.csv") {
  const rows = state.enrollments.map(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    return [
      fullName(student),
      course?.name || "",
      group?.name || "",
      groupSessionLabel(group),
      enrollment.date,
      tuitionExpectedForEnrollment(enrollment),
      paidAmount(enrollment.id),
      annexPaidAmount(enrollment.id),
      balanceForEnrollment(enrollment),
      enrollment.status
    ];
  });
  downloadCsv(filename, ["Ã‰tudiant", "Formation", "Promotion", "Type de cours", "Date", "ScolaritÃ© exigible", "ScolaritÃ© payÃ©e", "Annexes payÃ©es", "Reste scolaritÃ©", "Statut"], rows);
}

function exportStaffPaymentsCsv(filename = "paiements-personnel-cfp-erexit.csv") {
  const rows = state.staffPayments.map(payment => {
    const member = getStaffMember(payment.staffId);
    return [
      payment.date,
      staffName(member),
      payment.period,
      payment.reason,
      payment.amount,
      payment.method,
      payment.note,
      payment.recordedBy
    ];
  });
  downloadCsv(filename, ["Date", "Personnel", "PÃ©riode", "Motif", "Montant", "Mode", "Note", "Saisi par"], rows);
}

function downloadCsv(filename, headers, rows) {
  const csv = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(";"))
    .join("\n");
  downloadFile(filename, `\uFEFF${csv}`, "text/csv;charset=utf-8");
}

function exportStamp() {
  return new Date().toISOString().slice(0, 19).replaceAll(":", "").replace("T", "-");
}

function exportJson() {
  const payload = {
    exportedAt: new Date().toISOString(),
    app: "CFP EREXIT Manager",
    version: "2.0.0",
    data: state
  };
  downloadFile(`cfp-erexit-sauvegarde-${exportStamp()}.json`, JSON.stringify(payload, null, 2), "application/json");
}

function importJson(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      const importedState = imported?.data && typeof imported.data === "object" ? imported.data : imported;
      state = { ...seedState(), ...importedState };
      saveState();
      render();
      showToast("DonnÃ©es importÃ©es");
    } catch {
      showToast("Fichier JSON invalide");
    }
    event.target.value = "";
  };
  reader.readAsText(file);
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function resetData() {
  if (!confirm("RÃ©initialiser toutes les donnÃ©es locales ?")) return;
  state = seedState();
  saveState();
  render();
  showToast("DonnÃ©es rÃ©initialisÃ©es");
}

window.addEventListener("error", (event) => {
  console.error("Erreur JS :", event.error);
});

bootstrap();

