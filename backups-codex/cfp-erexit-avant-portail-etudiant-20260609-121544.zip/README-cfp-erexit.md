# CFP EREXIT Manager

## Version locale simple

Ouvrir le fichier :

`index.html`

Cette option fonctionne directement dans le navigateur et sauvegarde les donnees dans le stockage local du navigateur.

## Version serveur recommandee

Lancer l'application avec :

```powershell
npm start
```

Puis ouvrir :

`http://localhost:3000`

Depuis un autre poste du meme reseau, ouvrir :

`http://ADRESSE-IP-DU-PC:3000`

Pour un hebergement en ligne/cloud, lancer le meme serveur sur un service Node.js avec HTTPS.

Par defaut, sans configuration MySQL, les donnees sont sauvegardees dans :

`data/db.json`

Des copies automatiques sont conservees dans :

`data/backups`

## Base MySQL / MariaDB pour plusieurs utilisateurs

Sur o2switch/cPanel, creer une base MySQL, un utilisateur MySQL, puis associer l'utilisateur a la base avec tous les droits.

Dans `Setup Node.js App`, ajouter ces variables d'environnement :

```text
MYSQL_HOST=localhost
MYSQL_DATABASE=nom_de_la_base
MYSQL_USER=nom_utilisateur_mysql
MYSQL_PASSWORD=mot_de_passe_mysql
MYSQL_PORT=3306
```

Ou une seule variable :

```text
DATABASE_URL=mysql://utilisateur:motdepasse@localhost:3306/nom_de_la_base
```

Ensuite :

```bash
npm install
npm start
```

Au premier demarrage, l'application cree les tables `cfp_state` et `cfp_state_revisions`, puis migre automatiquement les donnees existantes depuis `data/db.json` si la base est vide.

Pour verifier le stockage actif :

```text
https://votre-domaine/api/health
```

Le champ `storage` doit indiquer `mysql`.

## Comptes de test

- Administrateur : `admin` / `admin123` (`admin@cftperexit.com`)
- Secretariat : `secretariat` / `secret123` (`secretariat@cftperexit.com`)
- Comptabilite : `comptable` / `compta123` (`comptable@cftperexit.com`)
- Formateur : `formateur` / `formateur123` (`formateur@cftperexit.com`)

Important : ces mots de passe initiaux sont faibles et doivent etre remplaces immediatement dans Parametres > Acces utilisateurs par des mots de passe forts.

Regle minimale : 8 caracteres, une majuscule, une minuscule, un chiffre et un caractere special.

## Modules disponibles

- Tableau de bord
- Apprenants
- Formations
- Promotions / classes
- Inscriptions
- Paiements
- Montants configurables par motif : inscription, document, tenue, T-shirt, macaron
- Motif et montant libres pour les paiements de type autre
- Recu de paiement imprimable
- Fiche d'inscription imprimable
- Presences
- Formateurs
- Notes et evaluations
- Releve de notes imprimable
- Rapports
- Export CSV
- Export / import JSON
- Connexion utilisateur
- Sauvegarde serveur avec API
- Matricule automatique au format `ERX-annee-00000`

## Fichiers principaux

- `index.html` : structure de l'application
- `styles.css` : design et responsive
- `app.js` : logique, donnees et interactions
- `server.js` : serveur web, API et authentification
- `data/db.json` : base de donnees JSON de depart
- `package.json` : commande de lancement
- `.env.example` : exemple de configuration sans secret
- `schema-cfp-erexit.sql` : ancien schema de reference
- `schema-cfp-erexit-mysql.sql` : tables MySQL utilisees par la version multi-utilisateur
- `cahier-des-charges-cfp-erexit.md` : specification du projet

## Limite de cette version

Avec MySQL/MariaDB, les sauvegardes sont transactionnelles et journalisees dans `cfp_state_revisions`.

Pour une utilisation officielle en production, il faut encore prevoir :

- sauvegardes automatiques de la base MySQL cote hebergeur ;
- HTTPS actif ;
- changement obligatoire des mots de passe par defaut ;
- comptes personnels pour chaque utilisateur reel.

## Prochaine evolution conseillee

Transformer cette version en application Laravel + MySQL ou Django + PostgreSQL, en reutilisant les modules et le schema deja prepares.
