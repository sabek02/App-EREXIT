const http = require("node:http");
const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "0.0.0.0";
const ROOT_DIR = __dirname;
const DATA_DIR = path.join(ROOT_DIR, "data");
const BACKUP_DIR = path.join(DATA_DIR, "backups");
const UPLOAD_DIR = path.join(ROOT_DIR, "uploads");
const DB_PATH = path.join(DATA_DIR, "db.json");
const LOGO_PATH = path.join(DATA_DIR, "logo.png");
const SESSION_COOKIE = "cfp_erexit_session";
const sessions = new Map();
const MAX_AUTO_BACKUPS = 30;

const ACCESS_VIEWS = [
  "dashboard",
  "students",
  "courses",
  "groups",
  "enrollments",
  "payments",
  "cash",
  "attendance",
  "trainers",
  "staff",
  "grades",
  "reports",
  "settings"
];
const MANAGED_ACCESS_VIEWS = ACCESS_VIEWS.filter(view => view !== "settings");
const TUITION_MOTIF_KEYS = ["scolarite", "formation", "mensualite"];
const PASSING_SCORE_20 = 12;
const MAKEUP_FEE = 5000;

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
};

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

function defaultPermissionsForRole(role) {
  if (role === "Administrateur") return [...ACCESS_VIEWS];
  if (role === "Directeur") {
    return ["dashboard", "students", "courses", "groups", "enrollments", "attendance", "trainers", "staff", "grades", "reports"];
  }
  if (role === "Secrétaire") {
    return ["dashboard", "students", "courses", "groups", "enrollments", "attendance", "trainers"];
  }
  if (role === "Comptable") {
    return ["dashboard", "payments", "cash", "staff", "reports"];
  }
  if (role === "Formateur") {
    return ["dashboard", "attendance", "grades"];
  }
  return ["dashboard"];
}

function isAdminUser(user) {
  return user?.role === "Administrateur";
}

function permissionsForUser(user) {
  if (isAdminUser(user)) return [...ACCESS_VIEWS];
  const permissions = Array.isArray(user?.permissions) && user.permissions.length
    ? user.permissions
    : defaultPermissionsForRole(user?.role);
  return permissions.filter(view => MANAGED_ACCESS_VIEWS.includes(view));
}

function defaultDb() {
  return {
    center: {
      name: "CFP EREXIT",
      subtitle: "Centre de Formation Professionnelle",
      phone: "",
      email: "",
      logoData: "",
      stampData: "",
      address: ""
    },
    paymentMotifs: [
      { key: "scolarite", label: "Scolarité", amount: 0 },
      { key: "inscription", label: "Inscription", amount: 15000 },
      { key: "document", label: "Document", amount: 5000 },
      { key: "tenue", label: "Tenue", amount: 25000 },
      { key: "tshirt", label: "T-shirt", amount: 5000 },
      { key: "macaron", label: "Macaron", amount: 2000 }
    ],
    documentTemplates: [],
    users: [
      {
        id: 1,
        name: "Administrateur CFP EREXIT",
        username: "admin",
        email: "admin@cftperexit.com",
        passwordHash: hashPassword("admin123"),
        role: "Administrateur",
        status: "active",
        permissions: [...ACCESS_VIEWS]
      },
      {
        id: 2,
        name: "Secrétariat",
        username: "secretariat",
        email: "secretariat@cftperexit.com",
        passwordHash: hashPassword("secret123"),
        role: "Secrétaire",
        status: "active",
        permissions: defaultPermissionsForRole("Secrétaire")
      },
      {
        id: 3,
        name: "Comptabilité",
        username: "comptable",
        email: "comptable@cftperexit.com",
        passwordHash: hashPassword("compta123"),
        role: "Comptable",
        status: "active",
        permissions: defaultPermissionsForRole("Comptable")
      },
      {
        id: 4,
        name: "Formateur",
        username: "formateur",
        email: "formateur@cftperexit.com",
        passwordHash: hashPassword("formateur123"),
        role: "Formateur",
        status: "active",
        permissions: defaultPermissionsForRole("Formateur")
      }
    ],
    passwordResetRequests: [],
    loginHistory: [],
    auditLog: [],
    requiredDocuments: {
      student: ["Photo", "Pièce d'identité", "Contrat signé"],
      trainer: ["Photo", "Pièce d'identité", "Contrat signé", "Diplôme ou CV"],
      staff: ["Photo", "Pièce d'identité", "Contrat signé"]
    },
    students: [
      {
        id: 1,
        matricule: "ERX-2026-001",
        firstName: "Amina",
        lastName: "Traore",
        gender: "F",
        birthDate: "2003-04-18",
        phone: "+221 77 000 10 01",
        email: "amina@example.com",
        address: "Quartier Centre",
        emergencyName: "Mariam Traore",
        emergencyPhone: "+221 77 100 10 01",
        status: "actif"
      },
      {
        id: 2,
        matricule: "ERX-2026-002",
        firstName: "Moussa",
        lastName: "Diallo",
        gender: "M",
        birthDate: "2001-09-08",
        phone: "+221 77 000 10 02",
        email: "moussa@example.com",
        address: "Route Principale",
        emergencyName: "Oumar Diallo",
        emergencyPhone: "+221 77 100 10 02",
        status: "actif"
      },
      {
        id: 3,
        matricule: "ERX-2026-003",
        firstName: "Fatou",
        lastName: "Ndiaye",
        gender: "F",
        birthDate: "2002-02-22",
        phone: "+221 77 000 10 03",
        email: "fatou@example.com",
        address: "Cite Nouvelle",
        emergencyName: "Adama Ndiaye",
        emergencyPhone: "+221 77 100 10 03",
        status: "preinscrit"
      },
      {
        id: 4,
        matricule: "ERX-2026-004",
        firstName: "Jean",
        lastName: "Kouame",
        gender: "M",
        birthDate: "2000-12-14",
        phone: "+225 07 00 10 04",
        email: "jean@example.com",
        address: "Avenue de la Paix",
        emergencyName: "Claire Kouame",
        emergencyPhone: "+225 07 10 10 04",
        status: "actif"
      }
    ],
    courses: [
      {
        id: 1,
        code: "BUR",
        name: "Informatique bureautique",
        duration: "6 mois",
        description: "Word, Excel, PowerPoint, Internet et outils administratifs.",
        registrationFee: 15000,
        trainingFee: 120000,
        monthlyFee: 20000,
        status: "active"
      },
      {
        id: 2,
        code: "COMPTA",
        name: "Comptabilité pratique",
        duration: "8 mois",
        description: "Bases comptables, caisse, facturation et états financiers.",
        registrationFee: 20000,
        trainingFee: 160000,
        monthlyFee: 25000,
        status: "active"
      },
      {
        id: 3,
        code: "INFO",
        name: "Maintenance informatique",
        duration: "9 mois",
        description: "Matériel, systèmes, réseaux et dépannage.",
        registrationFee: 20000,
        trainingFee: 180000,
        monthlyFee: 30000,
        status: "active"
      }
    ],
    groups: [
      {
        id: 1,
        name: "Bureautique 2026 - Groupe A",
        courseId: 1,
      year: "2026",
      sessionType: "jour",
      trainer: "Mme Coulibaly",
        capacity: 25,
        startDate: "2026-01-12",
        endDate: "2026-07-12",
        status: "active"
      },
      {
        id: 2,
        name: "Comptabilité 2026 - Groupe A",
        courseId: 2,
      year: "2026",
      sessionType: "soir",
      trainer: "M. Diop",
        capacity: 20,
        startDate: "2026-02-03",
        endDate: "2026-10-03",
        status: "active"
      },
      {
        id: 3,
        name: "Maintenance 2026 - Groupe A",
        courseId: 3,
      year: "2026",
      sessionType: "jour",
      trainer: "M. Kone",
        capacity: 18,
        startDate: "2026-03-01",
        endDate: "2026-12-01",
        status: "active"
      }
    ],
    trainers: [
      {
        id: 1,
        firstName: "Awa",
        lastName: "Coulibaly",
        phone: "+228 90 00 00 01",
        email: "awa.coulibaly@cftperexit.com",
        specialty: "Bureautique",
        modules: "Word, Excel, PowerPoint",
        status: "actif"
      },
      {
        id: 2,
        firstName: "Mamadou",
        lastName: "Diop",
        phone: "+228 90 00 00 02",
        email: "mamadou.diop@cftperexit.com",
        specialty: "Comptabilite pratique",
        modules: "Caisse, facturation, etats financiers",
        status: "actif"
      },
      {
        id: 3,
        firstName: "Koffi",
        lastName: "Kone",
        phone: "+228 90 00 00 03",
        email: "koffi.kone@cftperexit.com",
        specialty: "Maintenance informatique",
        modules: "Materiel, systemes, reseaux",
        status: "actif"
      }
    ],
    staffMembers: [
      {
        id: 1,
        firstName: "Abla",
        lastName: "Kossibokon",
        role: "Comptable",
        phone: "",
        email: "",
        salary: 0,
        status: "actif"
      }
    ],
    enrollments: [
      {
        id: 1,
        studentId: 1,
        courseId: 1,
        groupId: 1,
        date: "2026-01-13",
        totalAmount: 135000,
        discountAmount: 0,
        finalAmount: 135000,
        status: "validee"
      },
      {
        id: 2,
        studentId: 2,
        courseId: 2,
        groupId: 2,
        date: "2026-02-05",
        totalAmount: 180000,
        discountAmount: 10000,
        finalAmount: 170000,
        status: "validee"
      },
      {
        id: 3,
        studentId: 3,
        courseId: 1,
        groupId: 1,
        date: "2026-03-02",
        totalAmount: 135000,
        discountAmount: 0,
        finalAmount: 135000,
        status: "en attente"
      },
      {
        id: 4,
        studentId: 4,
        courseId: 3,
        groupId: 3,
        date: "2026-03-10",
        totalAmount: 200000,
        discountAmount: 0,
        finalAmount: 200000,
        status: "validee"
      }
    ],
    payments: [
      {
        id: 1,
        enrollmentId: 1,
        receiptNumber: "REC-2026-001",
        amount: 35000,
        method: "Espèce",
        reason: "Frais d'inscription",
        date: "2026-01-13",
        receivedBy: "Comptable"
      },
      {
        id: 2,
        enrollmentId: 1,
        receiptNumber: "REC-2026-002",
        amount: 20000,
        method: "Mobile Money",
        reason: "Mensualité",
        date: "2026-02-12",
        receivedBy: "Comptable"
      },
      {
        id: 3,
        enrollmentId: 2,
        receiptNumber: "REC-2026-003",
        amount: 50000,
        method: "Espèce",
        reason: "Frais d'inscription",
        date: "2026-02-05",
        receivedBy: "Comptable"
      },
      {
        id: 4,
        enrollmentId: 4,
        receiptNumber: "REC-2026-004",
        amount: 60000,
        method: "Virement",
        reason: "Formation",
        date: "2026-03-11",
        receivedBy: "Comptable"
      }
    ],
    paymentAuditLog: [],
    cashEntries: [],
    staffPayments: [],
    attendanceSessions: [
      {
        id: 1,
        groupId: 1,
        date: "2026-04-02",
        topic: "Traitement de texte",
        records: [
          { studentId: 1, status: "present" },
          { studentId: 3, status: "absent" }
        ]
      }
    ],
    trainerAttendanceSessions: [],
    evaluations: [
      {
        id: 1,
        groupId: 1,
        trainerId: 1,
        title: "Evaluation Word",
        type: "pratique",
        date: "2026-04-15",
        maxScore: 20,
        grades: [
          { studentId: 1, score: 16, appreciation: "Bon travail" },
          { studentId: 3, score: 12, appreciation: "A renforcer" }
        ]
      }
    ]
  };
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    username: user.username || "",
    email: user.email,
    role: user.role,
    status: user.status,
    permissions: permissionsForUser(user)
  };
}

function publicManagedUser(user) {
  return {
    id: user.id,
    name: user.name,
    username: user.username || "",
    email: user.email,
    role: user.role,
    status: user.status,
    visiblePassword: user.visiblePassword || knownDefaultPassword(user) || "",
    permissions: permissionsForUser(user)
  };
}

function normalizeUsername(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function knownDefaultPassword(user = {}) {
  const defaults = [
    ["admin@cftperexit.com", "admin123"],
    ["secretariat@cftperexit.com", "secret123"],
    ["comptable@cftperexit.com", "compta123"],
    ["formateur@cftperexit.com", "formateur123"],
    ["admin@erexit.local", "admin123"],
    ["secretariat@erexit.local", "secret123"],
    ["comptable@erexit.local", "compta123"],
    ["formateur@erexit.local", "formateur123"]
  ];
  const email = String(user.email || "").toLowerCase();
  const match = defaults.find(([defaultEmail, password]) =>
    email === defaultEmail && user.passwordHash === hashPassword(password)
  );
  return match?.[1] || "";
}

function publicState(db, user = null) {
  const { users, ...state } = db;
  if (state.center?.logoData) {
    state.center = {
      ...state.center,
      logoData: `/api/logo?v=${encodeURIComponent(String(db.updatedAt || Date.now()))}`
    };
  }
  if (isAdminUser(user)) {
    state.users = users.map(publicManagedUser);
  }
  return state;
}

function normalizeSearchText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function normalizeDigits(value) {
  return String(value || "").replace(/\D/g, "");
}

function phoneMatches(input, stored) {
  const submitted = normalizeDigits(input);
  const expected = normalizeDigits(stored);
  if (!submitted || !expected) return false;
  return submitted === expected
    || (submitted.length >= 6 && expected.endsWith(submitted))
    || (expected.length >= 6 && submitted.endsWith(expected));
}

function fullName(student) {
  if (!student) return "Etudiant";
  return `${student.firstName || ""} ${student.lastName || ""}`.trim();
}

function groupSessionLabel(group) {
  const type = String(group?.sessionType || "jour");
  if (type === "soir") return "Cours du soir";
  if (type === "ligne") return "Cours en ligne";
  return "Cours du jour";
}

function isTuitionPayment(payment) {
  const key = String(payment.reasonKey || "").toLowerCase();
  if (TUITION_MOTIF_KEYS.includes(key)) return true;
  const reason = normalizeSearchText(payment.reason);
  return ["scolarite", "frais de scolarite", "formation", "frais formation", "frais de formation", "mensualite"]
    .includes(reason);
}

function passingScoreFor(maxScore = 20) {
  return Number(maxScore || 20) * PASSING_SCORE_20 / 20;
}

function gradeNeedsMakeup(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return false;
  return Number(score) < passingScoreFor(maxScore);
}

function gradeStatusLabel(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return "Non noté";
  return gradeNeedsMakeup(score, maxScore) ? "Non validé" : "Validé";
}

function studentPortalPayload(db, student) {
  const studentEnrollments = db.enrollments
    .filter(enrollment => Number(enrollment.studentId) === Number(student.id))
    .map(enrollment => {
      const course = db.courses.find(item => Number(item.id) === Number(enrollment.courseId));
      const group = db.groups.find(item => Number(item.id) === Number(enrollment.groupId));
      const enrollmentPayments = db.payments.filter(payment => Number(payment.enrollmentId) === Number(enrollment.id));
      const tuitionPaid = enrollmentPayments
        .filter(isTuitionPayment)
        .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
      const annexPaid = enrollmentPayments
        .filter(payment => !isTuitionPayment(payment))
        .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
      const finalAmount = Number(enrollment.finalAmount || 0);

      return {
        id: enrollment.id,
        date: enrollment.date || "",
        status: enrollment.status || "",
        courseName: course?.name || "",
        courseCode: course?.code || "",
        groupName: group?.name || "",
        sessionType: groupSessionLabel(group),
        finalAmount,
        tuitionPaid,
        annexPaid,
        balance: Math.max(0, finalAmount - tuitionPaid)
      };
    });

  const enrollmentIds = new Set(studentEnrollments.map(enrollment => Number(enrollment.id)));
  const payments = db.payments
    .filter(payment => enrollmentIds.has(Number(payment.enrollmentId)))
    .map(payment => ({
      id: payment.id,
      receiptNumber: payment.receiptNumber || "",
      amount: Number(payment.amount || 0),
      method: payment.method || "",
      reason: payment.reason || "",
      reasonKey: payment.reasonKey || "",
      category: isTuitionPayment(payment) ? "Scolarite" : "Frais annexe",
      date: payment.date || ""
    }))
    .sort((a, b) => String(b.date).localeCompare(String(a.date)) || Number(b.id) - Number(a.id));

  const grades = db.evaluations.flatMap(evaluation => {
    const grade = (evaluation.grades || []).find(item => Number(item.studentId) === Number(student.id));
    if (!grade) return [];
    const group = db.groups.find(item => Number(item.id) === Number(evaluation.groupId));
    return [{
      id: evaluation.id,
      date: evaluation.date || "",
      title: evaluation.title || "",
      type: evaluation.type || "",
      groupName: group?.name || "",
      sessionType: groupSessionLabel(group),
      maxScore: Number(evaluation.maxScore || 20),
      score: grade.score === "" || grade.score === undefined ? "" : grade.score,
      status: gradeStatusLabel(grade.score, evaluation.maxScore || 20),
      needsMakeup: gradeNeedsMakeup(grade.score, evaluation.maxScore || 20),
      makeupFee: gradeNeedsMakeup(grade.score, evaluation.maxScore || 20) ? MAKEUP_FEE : 0,
      appreciation: grade.appreciation || ""
    }];
  }).sort((a, b) => String(b.date).localeCompare(String(a.date)));

  const attendance = db.attendanceSessions.flatMap(session => {
    const record = (session.records || []).find(item => Number(item.studentId) === Number(student.id));
    if (!record) return [];
    const group = db.groups.find(item => Number(item.id) === Number(session.groupId));
    return [{
      id: session.id,
      date: session.date || "",
      topic: session.topic || "",
      groupName: group?.name || "",
      sessionType: groupSessionLabel(group),
      status: record.status || ""
    }];
  }).sort((a, b) => String(b.date).localeCompare(String(a.date)));

  return {
    center: {
      name: db.center?.name || "CFP EREXIT",
      subtitle: db.center?.subtitle || "",
      phone: db.center?.phone || "",
      email: db.center?.email || "",
      address: db.center?.address || ""
    },
    student: {
      id: student.id,
      matricule: student.matricule || "",
      firstName: student.firstName || "",
      lastName: student.lastName || "",
      fullName: fullName(student),
      gender: student.gender || "",
      birthDate: student.birthDate || "",
      phone: student.phone || "",
      email: student.email || "",
      address: student.address || "",
      status: student.status || ""
    },
    enrollments: studentEnrollments,
    payments,
    grades,
    attendance
  };
}

function normalizeBase64DataUrl(value) {
  const logo = String(value || "").trim();
  const match = logo.match(/^(data:image\/[a-zA-Z0-9.+-]+;base64,)(.+)$/);
  if (!match) return "";
  let payload = match[2].replace(/\s+/g, "").replace(/=+$/g, "");
  while (payload.length % 4 === 1) {
    payload = payload.slice(0, -1);
  }
  const padding = ["", "", "==", "="][payload.length % 4];
  return `${match[1]}${payload}${padding}`;
}

async function syncLogoFile(db) {
  if (db.center && db.center.logoData === "") {
    await fs.unlink(LOGO_PATH).catch(() => {});
    return;
  }
  const logo = normalizeBase64DataUrl(db.center?.logoData);
  if (!logo) return;
  const payload = logo.replace(/^data:[^,]+,/, "");
  await fs.writeFile(LOGO_PATH, Buffer.from(payload, "base64"));
}

async function ensureDb() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  try {
    await fs.access(DB_PATH);
  } catch {
    await writeDb(defaultDb());
  }
}

async function readDb() {
  await ensureDb();
  const raw = await fs.readFile(DB_PATH, "utf8");
  const db = JSON.parse(cleanJsonText(raw));
  const defaults = defaultDb();
  const next = repairEncodingIssues({
    ...defaults,
    ...db,
    users: Array.isArray(db.users) && db.users.length ? db.users : defaults.users
  });
  next.users = normalizeLoadedUsers(next.users);
  next.trainers = Array.isArray(next.trainers)
    ? next.trainers.map(trainer => ({ ...trainer, email: migrateEmailDomain(trainer.email) }))
    : [];
  next.passwordResetRequests = Array.isArray(next.passwordResetRequests) ? next.passwordResetRequests : [];
  next.loginHistory = Array.isArray(next.loginHistory) ? next.loginHistory : [];
  next.auditLog = Array.isArray(next.auditLog) ? next.auditLog : [];
  next.requiredDocuments = normalizeRequiredDocuments(next.requiredDocuments);
  next.documentTemplates = Array.isArray(next.documentTemplates) ? next.documentTemplates : [];
  next.groups = Array.isArray(next.groups) ? next.groups.map(group => ({
    ...group,
    sessionType: group.sessionType || "jour"
  })) : [];
  return next;
}

function normalizeRequiredDocuments(value = {}) {
  const defaults = defaultDb().requiredDocuments;
  return {
    student: Array.isArray(value.student) && value.student.length ? value.student : defaults.student,
    trainer: Array.isArray(value.trainer) && value.trainer.length ? value.trainer : defaults.trainer,
    staff: Array.isArray(value.staff) && value.staff.length ? value.staff : defaults.staff
  };
}

function cleanJsonText(raw) {
  return String(raw || "").replace(/^\uFEFF/, "").replace(/^ï»¿/, "");
}

function normalizeLoadedUsers(users) {
  return users.map((user, index) => {
    const role = user.role || (index === 0 ? "Administrateur" : "Secrétaire");
    return {
      ...user,
      id: Number(user.id || index + 1),
      username: normalizeUsername(user.username || String(user.email || "").split("@")[0] || user.name || `user-${index + 1}`),
      email: migrateEmailDomain(user.email),
      role,
      status: index === 0 || role === "Administrateur" ? "active" : (user.status || "active"),
      permissions: permissionsForUser({ ...user, role })
    };
  });
}

function migrateEmailDomain(email) {
  return String(email || "").replace(/@erexit\.local$/i, "@cftperexit.com");
}

function repairEncodingIssues(value) {
  if (Array.isArray(value)) {
    return value.map(repairEncodingIssues);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, entry]) => [key, repairEncodingIssues(entry)])
    );
  }
  if (typeof value !== "string") return value;

  const replacements = [
    ["Ã€", "À"], ["Ã‚", "Â"], ["Ã‡", "Ç"], ["Ãˆ", "È"], ["Ã‰", "É"], ["ÃŠ", "Ê"], ["Ã‹", "Ë"],
    ["Ã ", "à"], ["Ã¡", "á"], ["Ã¢", "â"], ["Ã£", "ã"], ["Ã¤", "ä"], ["Ã¥", "å"], ["Ã§", "ç"],
    ["Ã¨", "è"], ["Ã©", "é"], ["Ãª", "ê"], ["Ã«", "ë"], ["Ã¬", "ì"], ["Ã­", "í"], ["Ã®", "î"],
    ["Ã¯", "ï"], ["Ã±", "ñ"], ["Ã²", "ò"], ["Ã³", "ó"], ["Ã´", "ô"], ["Ã¶", "ö"], ["Ã¹", "ù"],
    ["Ãº", "ú"], ["Ã»", "û"], ["Ã¼", "ü"], ["Â°", "°"], ["â€™", "'"], ["â€˜", "'"],
    ["â€œ", "\""], ["â€", "\""], ["â€“", "-"], ["â€”", "-"],
    ["Esp?ce", "Espèce"], ["Mensualit?", "Mensualité"], ["Mat?riel", "Matériel"], ["syst?mes", "systèmes"],
    ["r?seaux", "réseaux"], ["d?pannage", "dépannage"], ["Comptabilit?", "Comptabilité"], ["sangu?ra", "sanguéra"],
    ["Scolarit?", "Scolarité"], ["Adidogom? douane", "Adidogomé douane"],
    ["Secr�taire", "Secrétaire"]
  ];

  return replacements.reduce((text, [from, to]) => text.split(from).join(to), value);
}

async function writeDb(db) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const cleanDb = repairEncodingIssues(db);
  await sanitizeUploadedFiles(cleanDb);
  await fs.writeFile(DB_PATH, JSON.stringify(cleanDb, null, 2), "utf8");
  await syncLogoFile(cleanDb).catch(() => {});
}

function safeUploadName(name = "fichier") {
  const extension = path.extname(String(name || "")).toLowerCase().replace(/[^a-z0-9.]/g, "") || ".bin";
  const base = path.basename(String(name || "fichier"), extension)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "fichier";
  return `${base}${extension}`;
}

function parseDataUrl(value = "") {
  const match = String(value).match(/^data:([^;,]+)?(?:;[^,]*)?;base64,(.+)$/);
  if (!match) return null;
  return {
    mime: match[1] || "application/octet-stream",
    buffer: Buffer.from(match[2].replace(/\s+/g, ""), "base64")
  };
}

async function saveUploadFromDataUrl({ dataUrl, name, folder = "documents" }) {
  const parsed = parseDataUrl(dataUrl);
  if (!parsed) return "";
  const now = new Date();
  const dateFolder = now.toISOString().slice(0, 10);
  const targetDir = path.join(UPLOAD_DIR, folder, dateFolder);
  await fs.mkdir(targetDir, { recursive: true });
  const filename = `${Date.now()}-${crypto.randomBytes(5).toString("hex")}-${safeUploadName(name)}`;
  await fs.writeFile(path.join(targetDir, filename), parsed.buffer);
  return `/uploads/${folder}/${dateFolder}/${filename}`;
}

async function sanitizePersonUploads(person, folder) {
  if (!person || typeof person !== "object") return;
  if (String(person.photoData || "").startsWith("data:")) {
    person.photoData = await saveUploadFromDataUrl({
      dataUrl: person.photoData,
      name: `${person.firstName || person.name || "photo"}-${person.lastName || ""}.png`,
      folder: `${folder}/photos`
    });
  }
  person.documents = Array.isArray(person.documents) ? person.documents : [];
  for (const documentItem of person.documents) {
    if (String(documentItem.data || "").startsWith("data:")) {
      documentItem.url = await saveUploadFromDataUrl({
        dataUrl: documentItem.data,
        name: documentItem.name || "document",
        folder: `${folder}/documents`
      });
      delete documentItem.data;
    }
  }
}

async function sanitizeUploadedFiles(db) {
  await Promise.all([
    ...(Array.isArray(db.students) ? db.students.map(item => sanitizePersonUploads(item, "students")) : []),
    ...(Array.isArray(db.trainers) ? db.trainers.map(item => sanitizePersonUploads(item, "trainers")) : []),
    ...(Array.isArray(db.staffMembers) ? db.staffMembers.map(item => sanitizePersonUploads(item, "staff")) : [])
  ]);
}

function backupStamp() {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

async function writeAutoBackup(db) {
  await fs.mkdir(BACKUP_DIR, { recursive: true });
  const filename = `cfp-erexit-backup-${backupStamp()}.json`;
  await fs.writeFile(path.join(BACKUP_DIR, filename), JSON.stringify(db, null, 2), "utf8");
  const files = (await fs.readdir(BACKUP_DIR))
    .filter(file => file.endsWith(".json"))
    .sort();
  const oldFiles = files.slice(0, Math.max(0, files.length - MAX_AUTO_BACKUPS));
  await Promise.all(oldFiles.map(file => fs.unlink(path.join(BACKUP_DIR, file)).catch(() => {})));
}

async function readBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString("utf8");
  return raw ? JSON.parse(raw) : {};
}

function sendJson(response, status, payload, headers = {}) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    ...headers
  });
  response.end(JSON.stringify(payload));
}

function sendError(response, status, message) {
  sendJson(response, status, { error: message });
}

function parseCookies(request) {
  const cookies = {};
  const header = request.headers.cookie || "";
  for (const part of header.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key) {
      cookies[key] = decodeURIComponent(value.join("="));
    }
  }
  return cookies;
}

async function currentUser(request) {
  const token = parseCookies(request)[SESSION_COOKIE];
  const session = token ? sessions.get(token) : null;
  if (!session) return null;
  const db = await readDb();
  const user = db.users.find(item => item.id === session.userId && item.status === "active");
  return user || null;
}

async function requireUser(request, response) {
  const user = await currentUser(request);
  if (!user) {
    sendError(response, 401, "Connexion requise");
    return null;
  }
  return user;
}

function clearCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

function sessionCookie(token) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax`;
}

function normalizeManagedUsers(submittedUsers, previousUsers) {
  const previousById = new Map(previousUsers.map(user => [Number(user.id), user]));
  const nextUsers = [];
  let nextId = Math.max(0, ...previousUsers.map(user => Number(user.id) || 0));

  submittedUsers.forEach((submitted, index) => {
    const existing = previousById.get(Number(submitted.id));
    const isExistingAdmin = existing?.role === "Administrateur" || index === 0;
    const role = isExistingAdmin ? "Administrateur" : (
      submitted.role === "Administrateur" ? "Secrétaire" : submitted.role || existing?.role || "Secrétaire"
    );
    const id = existing ? Number(existing.id) : ++nextId;
    const password = String(submitted.password || "").trim();
    const email = String(submitted.email || existing?.email || "").trim().toLowerCase();
    const username = normalizeUsername(submitted.username || existing?.username || email.split("@")[0] || submitted.name || `user-${id}`);
    nextUsers.push({
      id,
      name: String(submitted.name || existing?.name || "Utilisateur").trim(),
      username,
      email,
      passwordHash: password ? hashPassword(password) : existing?.passwordHash || hashPassword("changeme123"),
      visiblePassword: password ? password : existing?.visiblePassword || knownDefaultPassword(existing) || "",
      role,
      status: role === "Administrateur" ? "active" : (submitted.status === "inactive" ? "inactive" : "active"),
      permissions: role === "Administrateur"
        ? [...ACCESS_VIEWS]
        : (Array.isArray(submitted.permissions) ? submitted.permissions : defaultPermissionsForRole(role))
          .filter(view => MANAGED_ACCESS_VIEWS.includes(view))
    });
  });

  if (!nextUsers.some(user => user.role === "Administrateur")) {
    const admin = previousUsers.find(user => user.role === "Administrateur") || defaultDb().users[0];
    nextUsers.unshift({
      ...admin,
      status: "active",
      permissions: [...ACCESS_VIEWS]
    });
  }

  return nextUsers.filter(user => user.email && user.username);
}

function normalizeResetEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function requestIp(request) {
  const forwarded = String(request.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return forwarded || request.socket.remoteAddress || "";
}

async function appendLoginHistory(db, entry) {
  const history = Array.isArray(db.loginHistory) ? db.loginHistory : [];
  const nextId = Math.max(0, ...history.map(item => Number(item.id) || 0)) + 1;
  db.loginHistory = [
    ...history,
    {
      id: nextId,
      at: new Date().toISOString(),
      ...entry
    }
  ].slice(-500);
}

function appendAuditLog(db, entry) {
  const history = Array.isArray(db.auditLog) ? db.auditLog : [];
  const nextId = Math.max(0, ...history.map(item => Number(item.id) || 0)) + 1;
  db.auditLog = [
    ...history,
    {
      id: nextId,
      at: new Date().toISOString(),
      ...entry
    }
  ].slice(-1000);
}

function collectionSignature(items = []) {
  return JSON.stringify(items.map(item => ({
    id: item.id,
    updated: item.updatedAt || item.correctedAt || item.deletedAt || "",
    count: Object.keys(item || {}).length,
    raw: item
  })));
}

function appendStateAudit(previous, next, user) {
  const tracked = [
    ["students", "Étudiants"],
    ["courses", "Formations"],
    ["groups", "Promotions"],
    ["enrollments", "Inscriptions"],
    ["payments", "Paiements"],
    ["cashEntries", "Caisse"],
    ["trainers", "Formateurs"],
    ["staffMembers", "Personnel"],
    ["staffPayments", "Paiements personnel"],
    ["attendanceSessions", "Présences étudiants"],
    ["trainerAttendanceSessions", "Présences professeurs"],
    ["evaluations", "Notes"],
    ["documentTemplates", "Modèles de documents"],
    ["requiredDocuments", "Documents obligatoires"],
    ["users", "Accès utilisateurs"]
  ];
  tracked.forEach(([key, label]) => {
    const before = previous[key];
    const after = next[key];
    if (JSON.stringify(before || null) === JSON.stringify(after || null)) return;
    const beforeCount = Array.isArray(before) ? before.length : Object.keys(before || {}).length;
    const afterCount = Array.isArray(after) ? after.length : Object.keys(after || {}).length;
    appendAuditLog(next, {
      action: "Modification",
      section: label,
      detail: `${beforeCount} -> ${afterCount}`,
      operator: user.name || user.email || "",
      operatorEmail: user.email || ""
    });
  });
}

async function handleApi(request, response, pathname) {
  if (request.method === "GET" && pathname === "/api/health") {
    sendJson(response, 200, { ok: true, app: "CFP EREXIT Manager" });
    return;
  }

  if (request.method === "GET" && pathname === "/api/logo") {
    try {
      const file = await fs.readFile(LOGO_PATH);
      response.writeHead(200, {
        "Content-Type": "image/png",
        "Cache-Control": "no-store, max-age=0"
      });
      response.end(file);
    } catch {
      sendError(response, 404, "Logo introuvable");
    }
    return;
  }

  if (request.method === "GET" && pathname === "/api/public-center") {
    const db = await readDb();
    sendJson(response, 200, {
      center: {
        name: db.center?.name || "CFP EREXIT",
        subtitle: db.center?.subtitle || "Centre de Formation Professionnelle",
        logoData: db.center?.logoData ? `/api/logo?v=${encodeURIComponent(String(db.updatedAt || Date.now()))}` : ""
      }
    });
    return;
  }

  if (request.method === "POST" && pathname === "/api/student-portal") {
    const body = await readBody(request);
    const matricule = String(body.matricule || "").trim().toLowerCase();
    const phone = String(body.phone || "").trim();
    if (!matricule || !phone) {
      sendError(response, 400, "Matricule et téléphone requis");
      return;
    }
    const db = await readDb();
    const student = db.students.find(item => {
      const sameMatricule = String(item.matricule || "").trim().toLowerCase() === matricule;
      return sameMatricule && (phoneMatches(phone, item.phone) || phoneMatches(phone, item.emergencyPhone));
    });

    if (!student) {
      sendError(response, 401, "Informations étudiant incorrectes");
      return;
    }

    sendJson(response, 200, studentPortalPayload(db, student));
    return;
  }

  if (request.method === "POST" && pathname === "/api/password-reset-request") {
    const body = await readBody(request);
    const email = normalizeResetEmail(body.email);
    if (!email) {
      sendError(response, 400, "Email requis");
      return;
    }

    const db = await readDb();
    const user = db.users.find(item => normalizeResetEmail(item.email) === email);
    const genericMessage = "Si ce compte existe, la demande sera transmise à l'administrateur.";
    if (!user) {
      sendJson(response, 200, { ok: true, message: genericMessage });
      return;
    }

    const pending = (db.passwordResetRequests || []).find(request => request.email === email && request.status !== "done");
    if (!pending) {
      const requests = Array.isArray(db.passwordResetRequests) ? db.passwordResetRequests : [];
      const nextId = Math.max(0, ...requests.map(request => Number(request.id) || 0)) + 1;
      db.passwordResetRequests = [
        ...requests,
        {
          id: nextId,
          email,
          userId: user.id,
          requestedAt: new Date().toISOString(),
          status: "pending"
        }
      ];
      await writeDb(db);
    }

    sendJson(response, 200, { ok: true, message: genericMessage });
    return;
  }

  if (request.method === "POST" && pathname === "/api/login") {
    const body = await readBody(request);
    const identifier = String(body.identifier || body.email || "").trim().toLowerCase();
    const username = normalizeUsername(identifier);
    const password = String(body.password || "");
    const db = await readDb();
    const user = db.users.find(item =>
      item.status === "active" &&
      (String(item.email || "").toLowerCase() === identifier || normalizeUsername(item.username) === username)
    );

    if (!user || user.passwordHash !== hashPassword(password)) {
      await appendLoginHistory(db, {
        email: identifier,
        identifier,
        userId: user?.id || null,
        userName: user?.name || "",
        role: user?.role || "",
        success: false,
        ip: requestIp(request),
        reason: user ? "Mot de passe incorrect" : "Utilisateur introuvable ou inactif"
      });
      await writeDb(db);
      sendError(response, 401, "Identifiants incorrects");
      return;
    }

    await appendLoginHistory(db, {
      email: user.email || identifier,
      identifier: user.username || identifier,
      userId: user.id,
      userName: user.name || "",
      role: user.role || "",
      success: true,
      ip: requestIp(request),
      reason: ""
    });
    await writeDb(db);

    const token = crypto.randomBytes(32).toString("hex");
    sessions.set(token, { userId: user.id, createdAt: Date.now() });
    sendJson(response, 200, { user: publicUser(user) }, { "Set-Cookie": sessionCookie(token) });
    return;
  }

  if (request.method === "POST" && pathname === "/api/logout") {
    const token = parseCookies(request)[SESSION_COOKIE];
    if (token) sessions.delete(token);
    sendJson(response, 200, { ok: true }, { "Set-Cookie": clearCookie() });
    return;
  }

  if (request.method === "GET" && pathname === "/api/me") {
    const user = await currentUser(request);
    if (!user) {
      sendJson(response, 200, { user: null });
      return;
    }
    sendJson(response, 200, { user: publicUser(user) });
    return;
  }

  if (request.method === "POST" && pathname === "/api/upload") {
    const user = await requireUser(request, response);
    if (!user) return;
    const body = await readBody(request);
    const dataUrl = String(body.data || "");
    const name = String(body.name || "fichier");
    const folder = String(body.folder || "documents").replace(/[^a-zA-Z0-9/_-]/g, "");
    const parsed = parseDataUrl(dataUrl);
    if (!parsed) {
      sendError(response, 400, "Fichier invalide");
      return;
    }
    if (parsed.buffer.length > 8 * 1024 * 1024) {
      sendError(response, 400, "Fichier trop lourd");
      return;
    }
    const url = await saveUploadFromDataUrl({ dataUrl, name, folder });
    const db = await readDb();
    appendAuditLog(db, {
      action: "Ajout fichier",
      section: "Dossiers numériques",
      detail: name,
      operator: user.name || user.email || "",
      operatorEmail: user.email || ""
    });
    await writeDb(db);
    sendJson(response, 200, { ok: true, url });
    return;
  }

  if (request.method === "GET" && pathname === "/api/state") {
    const user = await requireUser(request, response);
    if (!user) return;
    const db = await readDb();
    sendJson(response, 200, publicState(db, user));
    return;
  }

  if (request.method === "PUT" && pathname === "/api/state") {
    const user = await requireUser(request, response);
    if (!user) return;

    const body = await readBody(request);
    const previous = await readDb();
    const clientRevision = String(body.clientRevision || body.updatedAt || "");
    const currentRevision = String(previous.updatedAt || "");
    if (clientRevision !== currentRevision) {
      sendJson(response, 409, {
        error: "Les données ont été modifiées sur un autre poste. Rechargez la dernière version avant d'enregistrer.",
        updatedAt: currentRevision,
        state: publicState(previous, user)
      });
      return;
    }
    const managedUsers = isAdminUser(user) && Array.isArray(body.users)
      ? normalizeManagedUsers(body.users, previous.users)
      : previous.users;
    const userEmails = managedUsers.map(item => item.email).filter(Boolean);
    if (new Set(userEmails).size !== userEmails.length) {
      sendError(response, 400, "Deux utilisateurs ont le même email");
      return;
    }
    const usernames = managedUsers.map(item => normalizeUsername(item.username)).filter(Boolean);
    if (new Set(usernames).size !== usernames.length) {
      sendError(response, 400, "Deux utilisateurs ont le même identifiant");
      return;
    }
    const submittedLogoData = String(body.center?.logoData || "");
    const center = body.center
      ? {
          ...body.center,
          logoData: submittedLogoData.startsWith("/api/logo")
            ? previous.center?.logoData || ""
            : submittedLogoData
        }
      : previous.center;
    const next = {
      ...previous,
      center,
      students: Array.isArray(body.students) ? body.students : previous.students,
      courses: Array.isArray(body.courses) ? body.courses : previous.courses,
      paymentMotifs: Array.isArray(body.paymentMotifs) ? body.paymentMotifs : previous.paymentMotifs,
      documentTemplates: Array.isArray(body.documentTemplates) ? body.documentTemplates : previous.documentTemplates,
      requiredDocuments: normalizeRequiredDocuments(body.requiredDocuments || previous.requiredDocuments),
      groups: Array.isArray(body.groups) ? body.groups : previous.groups,
      trainers: Array.isArray(body.trainers) ? body.trainers : previous.trainers,
      staffMembers: Array.isArray(body.staffMembers) ? body.staffMembers : previous.staffMembers,
      users: managedUsers,
      enrollments: Array.isArray(body.enrollments) ? body.enrollments : previous.enrollments,
      payments: Array.isArray(body.payments) ? body.payments : previous.payments,
      paymentAuditLog: Array.isArray(body.paymentAuditLog) ? body.paymentAuditLog : previous.paymentAuditLog,
      passwordResetRequests: Array.isArray(body.passwordResetRequests)
        ? body.passwordResetRequests
        : previous.passwordResetRequests,
      loginHistory: previous.loginHistory,
      cashEntries: Array.isArray(body.cashEntries) ? body.cashEntries : previous.cashEntries,
      staffPayments: Array.isArray(body.staffPayments) ? body.staffPayments : previous.staffPayments,
      attendanceSessions: Array.isArray(body.attendanceSessions)
        ? body.attendanceSessions
        : previous.attendanceSessions,
      trainerAttendanceSessions: Array.isArray(body.trainerAttendanceSessions)
        ? body.trainerAttendanceSessions
        : previous.trainerAttendanceSessions,
      evaluations: Array.isArray(body.evaluations) ? body.evaluations : previous.evaluations,
      updatedAt: new Date().toISOString(),
      updatedBy: user.email
    };

    appendStateAudit(previous, next, user);
    await writeDb(next);
    await writeAutoBackup(next).catch(() => {});
    sendJson(response, 200, { ok: true, updatedAt: next.updatedAt, state: publicState(next, user) });
    return;
  }

  sendError(response, 404, "API introuvable");
}

async function serveStatic(request, response, pathname) {
  const urlPath = pathname === "/" ? "/index.html" : pathname;
  const decodedPath = decodeURIComponent(urlPath);
  const filePath = path.normalize(path.join(ROOT_DIR, decodedPath));

  if (!filePath.startsWith(ROOT_DIR)) {
    response.writeHead(403);
    response.end("Acces refuse");
    return;
  }
  if (decodedPath.startsWith("/uploads/") && !filePath.startsWith(UPLOAD_DIR)) {
    response.writeHead(403);
    response.end("Acces refuse");
    return;
  }

  try {
    const file = await fs.readFile(filePath);
    response.writeHead(200, {
      "Content-Type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream",
      "Cache-Control": "no-store, max-age=0"
    });
    response.end(file);
  } catch {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Fichier introuvable");
  }
}

const server = http.createServer(async (request, response) => {
  try {
    const requestUrl = new URL(request.url, `http://${request.headers.host}`);
    if (requestUrl.pathname.startsWith("/api/")) {
      await handleApi(request, response, requestUrl.pathname);
      return;
    }
    await serveStatic(request, response, requestUrl.pathname);
  } catch (error) {
    console.error(error);
    sendError(response, 500, "Erreur serveur");
  }
});

server.listen(PORT, HOST, async () => {
  await ensureDb();
  await syncLogoFile(await readDb()).catch(() => {});
  console.log(`CFP EREXIT Manager disponible sur http://localhost:${PORT}`);
  console.log(`Acces reseau local : http://ADRESSE-IP-DU-PC:${PORT}`);
  console.log("Compte administrateur : admin / admin123");
});
