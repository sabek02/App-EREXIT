const STORAGE_KEY = "cfp-erexit-manager-v1";
const SERVER_MODE = ["http:", "https:"].includes(window.location.protocol);
let currentUser = null;
let studentPortalData = null;
let saveTimer = null;
let syncTimer = null;
let lastSavedAt = "";
let serverRevision = "";
let hasPendingChanges = false;
const personFileDrafts = {
  student: { photoData: "", documents: [] },
  trainer: { photoData: "", documents: [] },
  staff: { photoData: "", documents: [] }
};

const today = () => new Date().toISOString().slice(0, 10);
const DAY_MS = 24 * 60 * 60 * 1000;

const VIEW_LABELS = {
  dashboard: "Tableau de bord",
  students: "Étudiants",
  courses: "Formations",
  groups: "Promotions",
  enrollments: "Inscriptions",
  payments: "Paiements",
  cash: "Caisse",
  attendance: "Présences",
  trainers: "Formateurs",
  staff: "Personnel",
  grades: "Notes",
  reports: "Rapports",
  settings: "Paramètres"
};

const ACCESS_VIEWS = Object.keys(VIEW_LABELS);
const MANAGED_ACCESS_VIEWS = ACCESS_VIEWS.filter(view => view !== "settings");
const ROLE_OPTIONS = ["Administrateur", "Directeur", "Secrétaire", "Comptable", "Formateur"];
const TUITION_MOTIF_KEYS = ["scolarite", "formation", "mensualite"];
const PASSING_SCORE_20 = 12;
const MAKEUP_FEE = 5000;
const TABLE_PAGE_SIZE = 25;
const tablePages = {};

function defaultPaymentMotifs() {
  return [
    { key: "scolarite", label: "Scolarité", amount: 0 },
    { key: "inscription", label: "Inscription", amount: 15000 },
    { key: "document", label: "Document", amount: 5000 },
    { key: "tenue", label: "Tenue", amount: 25000 },
    { key: "tshirt", label: "T-shirt", amount: 5000 },
    { key: "macaron", label: "Macaron", amount: 2000 }
  ];
}

function defaultDocumentTemplates() {
  return [
    {
      key: "attestation-inscription",
      title: "Attestation d'inscription",
      category: "Attestation",
      audience: "student",
      status: "active",
      locked: true,
      content: `Nous soussignés {{centre_nom}}, attestons que {{etudiant_nom}}, matricule {{matricule}}, est régulièrement inscrit(e) à la formation {{formation}}, promotion {{promotion}}, en {{type_cours}}.

La présente attestation est délivrée pour servir et valoir ce que de droit.

Fait à Lomé, le {{date}}.`
    },
    {
      key: "attestation-fin-formation",
      title: "Attestation de fin de formation",
      category: "Attestation",
      audience: "student",
      status: "active",
      locked: true,
      content: `Nous soussignés {{centre_nom}}, attestons que {{etudiant_nom}}, matricule {{matricule}}, a suivi la formation {{formation}} au sein de notre centre.

Cette attestation est établie sous réserve de la validation administrative et pédagogique du dossier.

Fait à Lomé, le {{date}}.`
    },
    {
      key: "reglement-interieur",
      title: "Règlement intérieur",
      category: "Règlement",
      audience: "general",
      status: "active",
      locked: true,
      content: `Le présent règlement intérieur fixe les conditions de conduite, de ponctualité, de discipline et de respect des biens du centre.

Chaque étudiant s'engage à respecter les horaires, le programme de formation, les consignes données par l'administration et les formateurs, ainsi que les modalités de paiement convenues.

Tout manquement grave peut entraîner des mesures disciplinaires après examen par l'administration.`
    },
    {
      key: "contrat-formation",
      title: "Contrat de formation",
      category: "Contrat",
      audience: "student",
      status: "active",
      locked: true,
      content: `Entre {{centre_nom}} et {{etudiant_nom}}, matricule {{matricule}}, il est convenu ce qui suit :

L'étudiant est inscrit à la formation {{formation}}, promotion {{promotion}}, en {{type_cours}}.

La scolarité convenue est de {{scolarite}}. Le reste scolarité à la date du document est de {{reste_scolarite}}.

L'étudiant s'engage à respecter le règlement intérieur, les horaires et les modalités de paiement. Le centre s'engage à assurer la formation selon le programme prévu.`
    },
    {
      key: "contrat-travail",
      title: "Contrat de travail",
      category: "Contrat",
      audience: "staff",
      status: "active",
      locked: true,
      content: `Entre {{centre_nom}} et {{beneficiaire_nom}}, occupant la fonction de {{fonction}}, il est établi le présent contrat de travail.

Le bénéficiaire s'engage à exercer ses missions avec ponctualité, confidentialité et professionnalisme.

Les conditions particulières de rémunération, d'horaires et de responsabilités sont définies par l'administration du centre.

Fait à Lomé, le {{date}}.`
    }
  ];
}

const seedState = () => ({
  center: {
    name: "CFP EREXIT",
    subtitle: "Centre de Formation Professionnelle",
    phone: "",
    email: "",
    address: "",
    logoData: "",
    stampData: ""
  },
  users: [],
  passwordResetRequests: [],
  loginHistory: [],
  paymentMotifs: defaultPaymentMotifs(),
  documentTemplates: defaultDocumentTemplates(),
  auditLog: [],
  requiredDocuments: {
    student: ["Photo", "Pièce d'identité", "Contrat signé"],
    trainer: ["Photo", "Pièce d'identité", "Contrat signé", "Diplôme ou CV"],
    staff: ["Photo", "Pièce d'identité", "Contrat signé"]
  },
  students: [
    {
      id: 1,
      matricule: "ERX-2026-001",
      firstName: "Amina",
      lastName: "Traore",
      gender: "F",
      birthDate: "2003-04-18",
      phone: "+221 77 000 10 01",
      email: "amina@example.com",
      address: "Quartier Centre",
      emergencyName: "Mariam Traore",
      emergencyPhone: "+221 77 100 10 01",
      status: "actif"
    },
    {
      id: 2,
      matricule: "ERX-2026-002",
      firstName: "Moussa",
      lastName: "Diallo",
      gender: "M",
      birthDate: "2001-09-08",
      phone: "+221 77 000 10 02",
      email: "moussa@example.com",
      address: "Route Principale",
      emergencyName: "Oumar Diallo",
      emergencyPhone: "+221 77 100 10 02",
      status: "actif"
    },
    {
      id: 3,
      matricule: "ERX-2026-003",
      firstName: "Fatou",
      lastName: "Ndiaye",
      gender: "F",
      birthDate: "2002-02-22",
      phone: "+221 77 000 10 03",
      email: "fatou@example.com",
      address: "Cite Nouvelle",
      emergencyName: "Adama Ndiaye",
      emergencyPhone: "+221 77 100 10 03",
      status: "preinscrit"
    },
    {
      id: 4,
      matricule: "ERX-2026-004",
      firstName: "Jean",
      lastName: "Kouame",
      gender: "M",
      birthDate: "2000-12-14",
      phone: "+225 07 00 10 04",
      email: "jean@example.com",
      address: "Avenue de la Paix",
      emergencyName: "Claire Kouame",
      emergencyPhone: "+225 07 10 10 04",
      status: "actif"
    }
  ],
  courses: [
    {
      id: 1,
      code: "BUR",
      name: "Informatique bureautique",
      duration: "6 mois",
      description: "Word, Excel, PowerPoint, Internet et outils administratifs.",
      registrationFee: 15000,
      trainingFee: 120000,
      monthlyFee: 20000,
      status: "active"
    },
    {
      id: 2,
      code: "COMPTA",
      name: "Comptabilité pratique",
      duration: "8 mois",
      description: "Bases comptables, caisse, facturation et états financiers.",
      registrationFee: 20000,
      trainingFee: 160000,
      monthlyFee: 25000,
      status: "active"
    },
    {
      id: 3,
      code: "INFO",
      name: "Maintenance informatique",
      duration: "9 mois",
      description: "Matériel, systèmes, réseaux et dépannage.",
      registrationFee: 20000,
      trainingFee: 180000,
      monthlyFee: 30000,
      status: "active"
    }
  ],
  groups: [
    {
      id: 1,
      name: "Bureautique 2026 - Groupe A",
      courseId: 1,
      year: "2026",
      sessionType: "jour",
      trainer: "Mme Coulibaly",
      capacity: 25,
      startDate: "2026-01-12",
      endDate: "2026-07-12",
      status: "active"
    },
    {
      id: 2,
      name: "Comptabilité 2026 - Groupe A",
      courseId: 2,
      year: "2026",
      sessionType: "soir",
      trainer: "M. Diop",
      capacity: 20,
      startDate: "2026-02-03",
      endDate: "2026-10-03",
      status: "active"
    },
    {
      id: 3,
      name: "Maintenance 2026 - Groupe A",
      courseId: 3,
      year: "2026",
      sessionType: "jour",
      trainer: "M. Kone",
      capacity: 18,
      startDate: "2026-03-01",
      endDate: "2026-12-01",
      status: "active"
    }
  ],
  trainers: [
    {
      id: 1,
      firstName: "Awa",
      lastName: "Coulibaly",
      phone: "+228 90 00 00 01",
      email: "awa.coulibaly@cftperexit.com",
      specialty: "Bureautique",
      modules: "Word, Excel, PowerPoint",
      status: "actif"
    },
    {
      id: 2,
      firstName: "Mamadou",
      lastName: "Diop",
      phone: "+228 90 00 00 02",
      email: "mamadou.diop@cftperexit.com",
      specialty: "Comptabilite pratique",
      modules: "Caisse, facturation, etats financiers",
      status: "actif"
    },
    {
      id: 3,
      firstName: "Koffi",
      lastName: "Kone",
      phone: "+228 90 00 00 03",
      email: "koffi.kone@cftperexit.com",
      specialty: "Maintenance informatique",
      modules: "Materiel, systemes, reseaux",
      status: "actif"
    }
  ],
  staffMembers: [
    {
      id: 1,
      firstName: "Abla",
      lastName: "Kossibokon",
      role: "Comptable",
      phone: "",
      email: "",
      salary: 0,
      status: "actif"
    }
  ],
  enrollments: [
    {
      id: 1,
      studentId: 1,
      courseId: 1,
      groupId: 1,
      date: "2026-01-13",
      totalAmount: 135000,
      discountAmount: 0,
      finalAmount: 135000,
      status: "validee"
    },
    {
      id: 2,
      studentId: 2,
      courseId: 2,
      groupId: 2,
      date: "2026-02-05",
      totalAmount: 180000,
      discountAmount: 10000,
      finalAmount: 170000,
      status: "validee"
    },
    {
      id: 3,
      studentId: 3,
      courseId: 1,
      groupId: 1,
      date: "2026-03-02",
      totalAmount: 135000,
      discountAmount: 0,
      finalAmount: 135000,
      status: "en attente"
    },
    {
      id: 4,
      studentId: 4,
      courseId: 3,
      groupId: 3,
      date: "2026-03-10",
      totalAmount: 200000,
      discountAmount: 0,
      finalAmount: 200000,
      status: "validee"
    }
  ],
  payments: [
    {
      id: 1,
      enrollmentId: 1,
      receiptNumber: "REC-2026-001",
      amount: 35000,
      method: "Espèce",
      reason: "Frais d'inscription",
      date: "2026-01-13",
      receivedBy: "Comptable"
    },
    {
      id: 2,
      enrollmentId: 1,
      receiptNumber: "REC-2026-002",
      amount: 20000,
      method: "Mobile Money",
      reason: "Mensualité",
      date: "2026-02-12",
      receivedBy: "Comptable"
    },
    {
      id: 3,
      enrollmentId: 2,
      receiptNumber: "REC-2026-003",
      amount: 50000,
      method: "Espèce",
      reason: "Frais d'inscription",
      date: "2026-02-05",
      receivedBy: "Comptable"
    },
    {
      id: 4,
      enrollmentId: 4,
      receiptNumber: "REC-2026-004",
      amount: 60000,
      method: "Virement",
      reason: "Formation",
      date: "2026-03-11",
      receivedBy: "Comptable"
    }
  ],
  paymentAuditLog: [],
  cashEntries: [],
  staffPayments: [],
  attendanceSessions: [
    {
      id: 1,
      groupId: 1,
      date: "2026-04-02",
      topic: "Traitement de texte",
      records: [
        { studentId: 1, status: "present" },
        { studentId: 3, status: "absent" }
      ]
    }
  ],
  trainerAttendanceSessions: [],
  evaluations: [
    {
      id: 1,
      groupId: 1,
      trainerId: 1,
      title: "Evaluation Word",
      type: "pratique",
      date: "2026-04-15",
      maxScore: 20,
      grades: [
        { studentId: 1, score: 16, appreciation: "Bon travail" },
        { studentId: 3, score: 12, appreciation: "A renforcer" }
      ]
    }
  ]
});

let state = loadState();
let currentView = "dashboard";

const ids = {
  pageTitle: document.getElementById("pageTitle"),
  toast: document.getElementById("toast"),
  saveStatus: document.getElementById("saveStatus"),
  loginScreen: document.getElementById("loginScreen"),
  appShell: document.getElementById("appShell"),
  loginChoiceView: document.getElementById("loginChoiceView"),
  studentPortal: document.getElementById("studentPortal"),
  studentPortalLoginError: document.getElementById("studentPortalLoginError"),
  studentPortalName: document.getElementById("studentPortalName"),
  studentPortalMeta: document.getElementById("studentPortalMeta"),
  studentPortalSummary: document.getElementById("studentPortalSummary"),
  studentPortalInfo: document.getElementById("studentPortalInfo"),
  studentPortalEnrollments: document.getElementById("studentPortalEnrollments"),
  studentPortalPayments: document.getElementById("studentPortalPayments"),
  studentPortalGrades: document.getElementById("studentPortalGrades"),
  studentPortalAttendance: document.getElementById("studentPortalAttendance"),
  statsGrid: document.getElementById("statsGrid"),
  recentPaymentsTable: document.getElementById("recentPaymentsTable"),
  balancesTable: document.getElementById("balancesTable"),
  paymentAlertsTable: document.getElementById("paymentAlertsTable"),
  paymentAlertCount: document.getElementById("paymentAlertCount"),
  studentsTable: document.getElementById("studentsTable"),
  studentCount: document.getElementById("studentCount"),
  studentPhotoPreview: document.getElementById("studentPhotoPreview"),
  studentDocumentList: document.getElementById("studentDocumentList"),
  coursesTable: document.getElementById("coursesTable"),
  courseCount: document.getElementById("courseCount"),
  groupsTable: document.getElementById("groupsTable"),
  groupCount: document.getElementById("groupCount"),
  enrollmentsTable: document.getElementById("enrollmentsTable"),
  enrollmentCount: document.getElementById("enrollmentCount"),
  paymentsTable: document.getElementById("paymentsTable"),
  paymentCount: document.getElementById("paymentCount"),
  paymentBalance: document.getElementById("paymentBalance"),
  paymentAuditTable: document.getElementById("paymentAuditTable"),
  paymentAuditCount: document.getElementById("paymentAuditCount"),
  cashTable: document.getElementById("cashTable"),
  cashCount: document.getElementById("cashCount"),
  cashBalance: document.getElementById("cashBalance"),
  dashboardFinanceBars: document.getElementById("dashboardFinanceBars"),
  dashboardTuitionRing: document.getElementById("dashboardTuitionRing"),
  dashboardTuitionDetails: document.getElementById("dashboardTuitionDetails"),
  dashboardCourseBars: document.getElementById("dashboardCourseBars"),
  attendanceList: document.getElementById("attendanceList"),
  attendanceTable: document.getElementById("attendanceTable"),
  attendanceTotal: document.getElementById("attendanceTotal"),
  attendanceCount: document.getElementById("attendanceCount"),
  trainerAttendanceList: document.getElementById("trainerAttendanceList"),
  trainerAttendanceTable: document.getElementById("trainerAttendanceTable"),
  trainerAttendanceTotal: document.getElementById("trainerAttendanceTotal"),
  trainerAttendanceCount: document.getElementById("trainerAttendanceCount"),
  trainersTable: document.getElementById("trainersTable"),
  trainerCount: document.getElementById("trainerCount"),
  trainerPhotoPreview: document.getElementById("trainerPhotoPreview"),
  trainerDocumentList: document.getElementById("trainerDocumentList"),
  staffTable: document.getElementById("staffTable"),
  staffCount: document.getElementById("staffCount"),
  staffPhotoPreview: document.getElementById("staffPhotoPreview"),
  staffDocumentList: document.getElementById("staffDocumentList"),
  staffPaymentStaff: document.getElementById("staffPaymentStaff"),
  staffPaymentsTable: document.getElementById("staffPaymentsTable"),
  staffPaymentCount: document.getElementById("staffPaymentCount"),
  staffPaymentTotal: document.getElementById("staffPaymentTotal"),
  gradeEntryList: document.getElementById("gradeEntryList"),
  evaluationsTable: document.getElementById("evaluationsTable"),
  evaluationCount: document.getElementById("evaluationCount"),
  financialReport: document.getElementById("financialReport"),
  reportBalancesTable: document.getElementById("reportBalancesTable"),
  courseDistribution: document.getElementById("courseDistribution"),
  monthlyScheduleTable: document.getElementById("monthlyScheduleTable"),
  monthlyScheduleCount: document.getElementById("monthlyScheduleCount"),
  documentGeneratorTemplate: document.getElementById("documentGeneratorTemplate"),
  documentGeneratorStudent: document.getElementById("documentGeneratorStudent"),
  documentGeneratorBeneficiary: document.getElementById("documentGeneratorBeneficiary"),
  individualReportStudent: document.getElementById("individualReportStudent"),
  individualReportSummary: document.getElementById("individualReportSummary"),
  individualMotifTable: document.getElementById("individualMotifTable"),
  printIndividualReport: document.getElementById("printIndividualReport"),
  printStudentTranscript: document.getElementById("printStudentTranscript"),
  printArea: document.getElementById("printArea"),
  currentUserName: document.getElementById("currentUserName"),
  loginError: document.getElementById("loginError"),
  passwordResetBox: document.getElementById("passwordResetBox"),
  passwordResetEmail: document.getElementById("passwordResetEmail"),
  passwordResetMessage: document.getElementById("passwordResetMessage"),
  centerLogoPreview: document.getElementById("centerLogoPreview"),
  centerStampPreview: document.getElementById("centerStampPreview"),
  paymentMotifsSettings: document.getElementById("paymentMotifsSettings"),
  courseFeesSettings: document.getElementById("courseFeesSettings"),
  documentTemplateList: document.getElementById("documentTemplateList"),
  documentTemplateEditKey: document.getElementById("documentTemplateEditKey"),
  documentTemplateTitle: document.getElementById("documentTemplateTitle"),
  documentTemplateCategory: document.getElementById("documentTemplateCategory"),
  documentTemplateAudience: document.getElementById("documentTemplateAudience"),
  documentTemplateStatus: document.getElementById("documentTemplateStatus"),
  documentTemplateContent: document.getElementById("documentTemplateContent"),
  userAccessSettings: document.getElementById("userAccessSettings"),
  passwordResetRequests: document.getElementById("passwordResetRequests"),
  loginHistoryTable: document.getElementById("loginHistoryTable"),
  loginHistoryCount: document.getElementById("loginHistoryCount"),
  auditLogTable: document.getElementById("auditLogTable"),
  auditLogCount: document.getElementById("auditLogCount"),
  requiredDocumentsSettings: document.getElementById("requiredDocumentsSettings")
};

function loadState() {
  if (SERVER_MODE) {
    return seedState();
  }
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return seedState();
  }
  try {
    return { ...seedState(), ...JSON.parse(raw) };
  } catch {
    return seedState();
  }
}

function saveTimestamp() {
  return new Intl.DateTimeFormat("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).format(new Date());
}

function setSaveStatus(text, status = "") {
  if (!ids.saveStatus) return;
  ids.saveStatus.textContent = text;
  ids.saveStatus.className = `save-status ${status}`.trim();
}

function markSaved() {
  lastSavedAt = saveTimestamp();
  hasPendingChanges = false;
  setSaveStatus(`Sauvegardé ${lastSavedAt}`, "saved");
}

function applyServerState(nextState) {
  state = { ...seedState(), ...(nextState || {}) };
  serverRevision = String(state.updatedAt || "");
}

function stopServerSync() {
  if (syncTimer) {
    window.clearInterval(syncTimer);
    syncTimer = null;
  }
}

function startServerSync() {
  if (!SERVER_MODE) return;
  stopServerSync();
  syncTimer = window.setInterval(() => {
    refreshServerState({ silent: true });
  }, 15000);
}

function isEditingField() {
  const active = document.activeElement;
  return !!active && ["INPUT", "SELECT", "TEXTAREA"].includes(active.tagName);
}

async function refreshServerState({ silent = false } = {}) {
  if (!SERVER_MODE || !currentUser || hasPendingChanges || isEditingField()) return;
  try {
    const latest = await apiRequest("/api/state");
    const latestRevision = String(latest.updatedAt || "");
    if (latestRevision && latestRevision !== serverRevision) {
      applyServerState(latest);
      render();
      markSaved();
      if (!silent) showToast("Dernière version chargée");
    }
  } catch {
    if (!silent) showToast("Actualisation impossible");
  }
}

function handleSaveConflict(error) {
  if (error.status !== 409) return false;
  if (error.payload?.state) {
    applyServerState(error.payload.state);
    render();
  }
  hasPendingChanges = false;
  setSaveStatus("Données actualisées", "error");
  showToast("Une autre personne a modifié les données. Dernière version rechargée, recommence l'action.");
  return true;
}

async function persistStateNow({ notify = false } = {}) {
  if (!SERVER_MODE) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    markSaved();
    if (notify) showToast("Données sauvegardées");
    return;
  }

  if (!currentUser) return;
  setSaveStatus("Sauvegarde en cours...", "saving");
  try {
    const result = await apiRequest("/api/state", {
      method: "PUT",
      body: JSON.stringify({
        ...state,
        clientRevision: serverRevision
      })
    });
    if (result.state) {
      applyServerState(result.state);
      render();
    } else {
      serverRevision = String(result.updatedAt || state.updatedAt || serverRevision);
      state.updatedAt = serverRevision || state.updatedAt;
    }
    markSaved();
    if (notify) showToast("Données sauvegardées");
  } catch (error) {
    if (handleSaveConflict(error)) return;
    setSaveStatus("Sauvegarde impossible", "error");
    showToast("Sauvegarde serveur impossible");
  }
}

function saveState(options = {}) {
  const { immediate = false, notify = false } = options;
  window.clearTimeout(saveTimer);
  hasPendingChanges = true;
  if (immediate) {
    return persistStateNow({ notify });
  }
  setSaveStatus("Modifications en attente...", "saving");
  saveTimer = window.setTimeout(() => {
    persistStateNow({ notify });
  }, 250);
}

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || "Erreur serveur");
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

async function loadServerState() {
  applyServerState(await apiRequest("/api/state"));
  markSaved();
}

async function loadPublicCenterIdentity() {
  if (!SERVER_MODE) return;
  try {
    const result = await apiRequest("/api/public-center");
    if (result.center) {
      state.center = { ...state.center, ...result.center };
      renderCenterIdentity();
    }
  } catch {
    renderCenterIdentity();
  }
}

function ensurePaymentMotifs() {
  const defaults = defaultPaymentMotifs();
  if (!Array.isArray(state.paymentMotifs)) {
    state.paymentMotifs = defaults;
    return;
  }

  defaults.forEach(defaultMotif => {
    const existing = state.paymentMotifs.find(motif => motif.key === defaultMotif.key);
    if (!existing) {
      if (defaultMotif.key === "scolarite") {
        state.paymentMotifs.unshift(defaultMotif);
      } else {
        state.paymentMotifs.push(defaultMotif);
      }
      return;
    }
    existing.label ||= defaultMotif.label;
    existing.amount = Number(existing.amount || 0);
  });
}

function ensureDocumentTemplates() {
  const defaults = defaultDocumentTemplates();
  if (!Array.isArray(state.documentTemplates)) {
    state.documentTemplates = defaults;
    return;
  }

  defaults.forEach(defaultTemplate => {
    const existing = state.documentTemplates.find(template => template.key === defaultTemplate.key);
    if (!existing) {
      state.documentTemplates.push(defaultTemplate);
      return;
    }
    existing.title ||= defaultTemplate.title;
    existing.category ||= defaultTemplate.category;
    existing.audience ||= defaultTemplate.audience;
    existing.status ||= "active";
    existing.locked = existing.locked !== false;
    existing.content ||= defaultTemplate.content;
  });
}

function ensureCollections() {
  state.trainers = Array.isArray(state.trainers) ? state.trainers : [];
  state.evaluations = Array.isArray(state.evaluations) ? state.evaluations : [];
  state.cashEntries = Array.isArray(state.cashEntries) ? state.cashEntries : [];
  state.paymentAuditLog = Array.isArray(state.paymentAuditLog) ? state.paymentAuditLog : [];
  state.attendanceSessions = Array.isArray(state.attendanceSessions) ? state.attendanceSessions : [];
  state.trainerAttendanceSessions = Array.isArray(state.trainerAttendanceSessions) ? state.trainerAttendanceSessions : [];
  state.users = Array.isArray(state.users) ? state.users : [];
  state.passwordResetRequests = Array.isArray(state.passwordResetRequests) ? state.passwordResetRequests : [];
  state.loginHistory = Array.isArray(state.loginHistory) ? state.loginHistory : [];
  state.auditLog = Array.isArray(state.auditLog) ? state.auditLog : [];
  state.requiredDocuments = normalizeRequiredDocuments(state.requiredDocuments);
  state.staffMembers = Array.isArray(state.staffMembers) ? state.staffMembers : [];
  state.staffPayments = Array.isArray(state.staffPayments) ? state.staffPayments : [];
  state.groups = Array.isArray(state.groups) ? state.groups : [];
  ensureDocumentTemplates();
  state.users.forEach(user => {
    user.email = migrateEmailDomain(user.email);
  });
  state.trainers.forEach(trainer => {
    trainer.email = migrateEmailDomain(trainer.email);
  });
  [...state.students, ...state.trainers, ...state.staffMembers].forEach(person => {
    if (!person) return;
    person.photoData ||= "";
    person.documents = Array.isArray(person.documents) ? person.documents : [];
  });
  state.groups.forEach(group => {
    group.sessionType ||= "jour";
  });
}

function normalizeRequiredDocuments(value = {}) {
  const defaults = seedState().requiredDocuments;
  return {
    student: Array.isArray(value.student) && value.student.length ? value.student : defaults.student,
    trainer: Array.isArray(value.trainer) && value.trainer.length ? value.trainer : defaults.trainer,
    staff: Array.isArray(value.staff) && value.staff.length ? value.staff : defaults.staff
  };
}

function migrateEmailDomain(email) {
  return String(email || "").replace(/@erexit\.local$/i, "@cftperexit.com");
}

function isAdmin() {
  if (SERVER_MODE) return currentUser?.role === "Administrateur";
  return document.getElementById("roleSelect")?.value === "Administrateur";
}

function defaultPermissionsForRole(role) {
  if (role === "Administrateur") return [...ACCESS_VIEWS];
  if (role === "Directeur") {
    return ["dashboard", "students", "courses", "groups", "enrollments", "attendance", "trainers", "staff", "grades", "reports"];
  }
  if (role === "Secrétaire") {
    return ["dashboard", "students", "courses", "groups", "enrollments", "attendance", "trainers"];
  }
  if (role === "Comptable") {
    return ["dashboard", "payments", "cash", "staff", "reports"];
  }
  if (role === "Formateur") {
    return ["dashboard", "attendance", "grades"];
  }
  return ["dashboard"];
}

function permissionsForUser(user = currentUser) {
  if (!SERVER_MODE) return [...ACCESS_VIEWS];
  if (!user) return [];
  if (user.role === "Administrateur") return [...ACCESS_VIEWS];
  const permissions = Array.isArray(user.permissions) && user.permissions.length
    ? user.permissions
    : defaultPermissionsForRole(user.role);
  return permissions.filter(view => MANAGED_ACCESS_VIEWS.includes(view));
}

function canAccessView(view) {
  if (!SERVER_MODE) return true;
  if (view === "settings") return isAdmin();
  return isAdmin() || permissionsForUser().includes(view);
}

function canControlPayments() {
  return isAdmin();
}

function currentOperatorName() {
  return currentUser?.name || document.getElementById("roleSelect")?.value || "Administrateur";
}

function firstAllowedView() {
  return ACCESS_VIEWS.find(view => canAccessView(view)) || "dashboard";
}

function getPaymentMotif(key) {
  ensurePaymentMotifs();
  return state.paymentMotifs.find(motif => motif.key === key);
}

function yearFromDate(value = today()) {
  return String(value || today()).slice(0, 4);
}

function randomFiveDigits() {
  return String(Math.floor(Math.random() * 100000)).padStart(5, "0");
}

function generateMatricule(year = yearFromDate()) {
  let matricule = "";
  do {
    matricule = `ERX-${year}-${randomFiveDigits()}`;
  } while (state.students.some(student => student.matricule === matricule));
  return matricule;
}

function nextId(collection) {
  return collection.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1;
}

function formatMoney(value) {
  return `${new Intl.NumberFormat("fr-FR").format(Number(value) || 0)} FCFA`;
}

function formatNumber(value) {
  return new Intl.NumberFormat("fr-FR").format(Number(value) || 0);
}

function statValueHtml(item) {
  if (item.type === "money") {
    return `
      <strong class="stat-value money">
        <span class="money-number">${formatNumber(item.value)}</span>
        <span class="money-currency">FCFA</span>
      </strong>
    `;
  }
  return `<strong class="stat-value count">${formatNumber(item.value)}</strong>`;
}

function formatCompactMoney(value) {
  return new Intl.NumberFormat("fr-FR", {
    notation: "compact",
    maximumFractionDigits: 1
  }).format(Number(value) || 0);
}

function formatPrintAmount(value) {
  return new Intl.NumberFormat("fr-FR").format(Number(value) || 0);
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Lecture du fichier impossible"));
    reader.readAsDataURL(file);
  });
}

function formatFileSize(bytes = 0) {
  const size = Number(bytes) || 0;
  if (size >= 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} Mo`;
  if (size >= 1024) return `${Math.round(size / 1024)} Ko`;
  return `${size} o`;
}

function cloneDocuments(documents = []) {
  return JSON.parse(JSON.stringify(Array.isArray(documents) ? documents : []));
}

function resetPersonFileDraft(kind, person = {}) {
  personFileDrafts[kind] = {
    photoData: person.photoData || "",
    documents: cloneDocuments(person.documents)
  };
  renderPersonFileDraft(kind);
}

function personFilesPayload(kind) {
  return {
    photoData: personFileDrafts[kind]?.photoData || "",
    documents: cloneDocuments(personFileDrafts[kind]?.documents || [])
  };
}

function personPhotoHtml(person, label = "Photo") {
  const src = normalizeLogoData(person?.photoData || "");
  return src
    ? `<img class="person-avatar" src="${escapeHtml(src)}" alt="${escapeHtml(label)}">`
    : `<span class="person-avatar placeholder">${escapeHtml(label.slice(0, 2).toUpperCase())}</span>`;
}

function personDocumentSummary(person) {
  const count = Array.isArray(person?.documents) ? person.documents.length : 0;
  return count ? `${count} fichier(s)` : "Aucun fichier";
}

function requiredDocumentsFor(kind) {
  return normalizeRequiredDocuments(state.requiredDocuments)[kind] || [];
}

function personDocumentCompletion(person, kind) {
  const required = requiredDocumentsFor(kind);
  if (!required.length) return { missing: [], completed: true };
  const docs = Array.isArray(person?.documents) ? person.documents : [];
  const hasPhotoRequirement = required.some(label => normalizeSearchText(label).includes("photo"));
  const missing = required.filter(label => {
    const normalized = normalizeSearchText(label);
    if (normalized.includes("photo") && person?.photoData) return false;
    return !docs.some(documentItem => normalizeSearchText(documentItem.type || documentItem.name).includes(normalized));
  });
  if (hasPhotoRequirement && !person?.photoData && !missing.some(label => normalizeSearchText(label).includes("photo"))) {
    missing.push("Photo");
  }
  return { missing, completed: missing.length === 0 };
}

function documentCompletionBadge(person, kind) {
  const completion = personDocumentCompletion(person, kind);
  return completion.completed
    ? `<span class="status active">Dossier complet</span>`
    : `<span class="status inactive">Dossier incomplet (${completion.missing.length})</span>`;
}

function renderPersonFileDraft(kind) {
  const draft = personFileDrafts[kind];
  const preview = ids[`${kind}PhotoPreview`];
  const list = ids[`${kind}DocumentList`];
  if (preview) {
    const src = normalizeLogoData(draft.photoData);
    preview.innerHTML = src ? `<img src="${escapeHtml(src)}" alt="">` : "Photo";
  }
  if (list) {
    list.innerHTML = draft.documents.map((documentItem, index) => `
      <article class="attached-document-item">
        <div>
          <strong>${escapeHtml(documentItem.type || "Document")}</strong>
          <span>${escapeHtml(documentItem.name || "Fichier")} · ${formatFileSize(documentItem.size)}</span>
        </div>
        <div class="row-actions">
          <a class="chip-button" href="${escapeHtml(documentItem.url || documentItem.data || "#")}" download="${escapeHtml(documentItem.name || "document")}" target="_blank" rel="noopener">Ouvrir</a>
          <button class="chip-button danger" type="button" data-action="delete-person-document" data-kind="${escapeHtml(kind)}" data-index="${index}">Retirer</button>
        </div>
      </article>
    `).join("") || `<p class="muted">Aucun document ajouté.</p>`;
  }
}

async function importPersonPhoto(kind) {
  const input = document.getElementById(`${kind}PhotoInput`);
  const file = input?.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Choisissez une image pour la photo");
    input.value = "";
    return;
  }
  try {
    const dataUrl = await imageToPngDataUrl(file, 420);
    personFileDrafts[kind].photoData = await uploadDataUrlToServer({
      dataUrl,
      name: file.name || `${kind}-photo.png`,
      folder: `${kind}/photos`
    });
    renderPersonFileDraft(kind);
  } catch {
    showToast("Photo illisible");
  } finally {
    input.value = "";
  }
}

function removePersonPhoto(kind) {
  personFileDrafts[kind].photoData = "";
  renderPersonFileDraft(kind);
}

async function uploadDataUrlToServer({ dataUrl, name, folder }) {
  if (!SERVER_MODE) return dataUrl;
  const result = await apiRequest("/api/upload", {
    method: "POST",
    body: JSON.stringify({ data: dataUrl, name, folder })
  });
  return result.url || dataUrl;
}

async function addPersonDocument(kind) {
  const fileInput = document.getElementById(`${kind}DocumentFile`);
  const typeInput = document.getElementById(`${kind}DocumentType`);
  const file = fileInput?.files?.[0];
  if (!file) {
    showToast("Choisissez un fichier");
    return;
  }
  const maxSize = 4 * 1024 * 1024;
  if (file.size > maxSize) {
    showToast("Fichier trop lourd : maximum 4 Mo");
    return;
  }
  try {
    const dataUrl = await readFileAsDataUrl(file);
    const storedUrl = await uploadDataUrlToServer({
      dataUrl,
      name: file.name,
      folder: `${kind}/documents`
    });
    personFileDrafts[kind].documents.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type: typeInput?.value.trim() || "Document",
      name: file.name,
      size: file.size,
      mime: file.type || "application/octet-stream",
      ...(SERVER_MODE ? { url: storedUrl } : { data: storedUrl }),
      addedAt: new Date().toISOString(),
      addedBy: currentOperatorName()
    });
    if (typeInput) typeInput.value = "";
    if (fileInput) fileInput.value = "";
    renderPersonFileDraft(kind);
    showToast("Document ajouté au dossier");
  } catch {
    showToast("Ajout du fichier impossible");
  }
}

function deletePersonDocument(kind, index) {
  const draft = personFileDrafts[kind];
  if (!draft) return;
  draft.documents.splice(Number(index), 1);
  renderPersonFileDraft(kind);
}

function formatDate(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("fr-FR").format(new Date(`${value}T00:00:00`));
}

function daysSince(value) {
  if (!value) return Infinity;
  const date = new Date(`${String(value).slice(0, 10)}T00:00:00`);
  if (Number.isNaN(date.getTime())) return Infinity;
  return Math.floor((new Date(`${today()}T00:00:00`) - date) / DAY_MS);
}

function formatDateTime(value = new Date()) {
  return new Intl.DateTimeFormat("fr-FR", {
    dateStyle: "short",
    timeStyle: "medium"
  }).format(value);
}

function statusClass(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, "-");
}

function fullName(student) {
  if (!student) return "Étudiant supprimé";
  return `${student.firstName || ""} ${student.lastName || ""}`.trim();
}

function findById(collection, id) {
  return collection.find(item => Number(item.id) === Number(id));
}

function getStudent(id) {
  return findById(state.students, id);
}

function getCourse(id) {
  return findById(state.courses, id);
}

function getGroup(id) {
  return findById(state.groups, id);
}

function getEnrollment(id) {
  return findById(state.enrollments, id);
}

function getTrainer(id) {
  return findById(state.trainers, id);
}

function getStaffMember(id) {
  return findById(state.staffMembers, id);
}

function getEvaluation(id) {
  return findById(state.evaluations, id);
}

function groupSessionLabel(group) {
  const type = String(group?.sessionType || "jour");
  if (type === "soir") return "Cours du soir";
  if (type === "ligne") return "Cours en ligne";
  return "Cours du jour";
}

function normalizeSearchText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function trainerName(trainer) {
  if (!trainer) return "Formateur non precise";
  return `${trainer.firstName || ""} ${trainer.lastName || ""}`.trim();
}

function staffName(member) {
  if (!member) return "Personnel supprimé";
  return `${member.firstName || ""} ${member.lastName || ""}`.trim();
}

function payrollBeneficiaryValue(type, id) {
  return `${type}:${id}`;
}

function parsePayrollBeneficiary(value) {
  const [type, id] = String(value || "").split(":");
  return {
    type: type === "trainer" ? "trainer" : "staff",
    id: Number(id || 0)
  };
}

function payrollBeneficiary(payment) {
  const type = payment.payeeType === "trainer" ? "trainer" : "staff";
  const id = Number(payment.payeeId || payment.staffId || 0);
  const person = type === "trainer" ? getTrainer(id) : getStaffMember(id);
  return {
    type,
    id,
    person,
    name: type === "trainer" ? trainerName(person) : staffName(person),
    role: type === "trainer" ? "Formateur" : (person?.role || "Personnel"),
    phone: person?.phone || "",
    email: person?.email || "",
    baseSalary: type === "trainer" ? Number(person?.salary || 0) : Number(person?.salary || 0)
  };
}

function courseCost(course) {
  if (!course) return 0;
  return Number(course.trainingFee || 0);
}

function paymentsForEnrollment(enrollmentId) {
  return state.payments.filter(payment => Number(payment.enrollmentId) === Number(enrollmentId));
}

function isTuitionMotifKey(key) {
  return TUITION_MOTIF_KEYS.includes(String(key || "").toLowerCase());
}

function isTuitionPayment(payment) {
  const key = String(payment.reasonKey || "").toLowerCase();
  if (isTuitionMotifKey(key)) return true;
  const reason = normalizeSearchText(payment.reason);
  return ["scolarite", "frais de scolarite", "formation", "frais formation", "frais de formation", "mensualite"]
    .some(label => reason === label);
}

function tuitionPaymentsForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).filter(isTuitionPayment);
}

function annexPaymentsForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).filter(payment => !isTuitionPayment(payment));
}

function lastPaymentDateForEnrollment(enrollmentId, predicate = () => true) {
  return paymentsForEnrollment(enrollmentId)
    .filter(predicate)
    .map(payment => payment.date)
    .filter(Boolean)
    .sort()
    .at(-1) || "";
}

function paidAmount(enrollmentId) {
  return tuitionPaymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function paidAmountExcluding(enrollmentId, excludedPaymentId) {
  return tuitionPaymentsForEnrollment(enrollmentId)
    .filter(payment => Number(payment.id) !== Number(excludedPaymentId))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function annexPaidAmount(enrollmentId) {
  return annexPaymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function totalPaidAmountForEnrollment(enrollmentId) {
  return paymentsForEnrollment(enrollmentId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function balanceForEnrollment(enrollment) {
  if (!enrollment) return 0;
  return Math.max(0, Number(enrollment.finalAmount || 0) - paidAmount(enrollment.id));
}

function balanceForEnrollmentExcluding(enrollment, excludedPaymentId) {
  if (!enrollment) return 0;
  return Math.max(0, Number(enrollment.finalAmount || 0) - paidAmountExcluding(enrollment.id, excludedPaymentId));
}

function paymentsTotal() {
  return state.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function tuitionPaymentsTotal() {
  return state.payments.filter(isTuitionPayment).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function annexPaymentsTotal() {
  return state.payments.filter(payment => !isTuitionPayment(payment)).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function cashIncomeTotal() {
  return state.cashEntries
    .filter(entry => entry.type === "income")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function cashExpenseTotal() {
  const cashExpenses = state.cashEntries
    .filter(entry => entry.type === "expense")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  return cashExpenses + staffPaymentsTotal();
}

function staffPaymentsTotal() {
  return state.staffPayments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function netCashTotal() {
  return paymentsTotal() + cashIncomeTotal() - cashExpenseTotal();
}

function studentsForGroup(groupId) {
  const seen = new Set();
  return state.enrollments
    .filter(enrollment => Number(enrollment.groupId) === Number(groupId) && enrollment.status !== "annulee")
    .map(enrollment => getStudent(enrollment.studentId))
    .filter(student => {
      if (!student || seen.has(Number(student.id))) return false;
      seen.add(Number(student.id));
      return true;
    });
}

function formatAverage(evaluation) {
  const grades = Array.isArray(evaluation.grades) ? evaluation.grades : [];
  const scored = grades.filter(grade => grade.score !== "" && grade.score !== null && !Number.isNaN(Number(grade.score)));
  if (!scored.length) return "-";
  const total = scored.reduce((sum, grade) => sum + Number(grade.score || 0), 0);
  const average = total / scored.length;
  return `${average.toFixed(2)} / ${Number(evaluation.maxScore || 20)}`;
}

function passingScoreFor(maxScore = 20) {
  return Number(maxScore || 20) * PASSING_SCORE_20 / 20;
}

function gradeNeedsMakeup(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return false;
  return Number(score) < passingScoreFor(maxScore);
}

function gradeStatusLabel(score, maxScore = 20) {
  if (score === "" || score === null || score === undefined || Number.isNaN(Number(score))) return "Non noté";
  return gradeNeedsMakeup(score, maxScore) ? "Non validé" : "Validé";
}

function evaluationMakeupStats(evaluation) {
  const maxScore = Number(evaluation?.maxScore || 20);
  const count = (evaluation?.grades || []).filter(grade => gradeNeedsMakeup(grade.score, maxScore)).length;
  return {
    count,
    amount: count * MAKEUP_FEE
  };
}

function centerContactLine() {
  const center = state.center || {};
  return [center.address, center.phone, center.email].filter(Boolean).join(" - ");
}

function printHeaderHtml(title) {
  const center = state.center || {};
  const logoSrc = normalizeLogoData(center.logoData);
  const stampSrc = normalizeLogoData(center.stampData);
  return `
    <div class="print-header">
      ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="Logo ${escapeHtml(center.name || "CFP EREXIT")}">` : ""}
      <div>
        <h1>${escapeHtml(center.name || "CFP EREXIT")}</h1>
        <p>${escapeHtml(center.subtitle || "Centre de Formation Professionnelle")}</p>
        <p>${escapeHtml(centerContactLine())}</p>
      </div>
    </div>
    <hr>
    <h2>${escapeHtml(title)}</h2>
  `;
}

function normalizeLogoData(value) {
  const logo = String(value || "").trim();
  if (logo.startsWith("/") || logo.startsWith("http://") || logo.startsWith("https://") || logo.startsWith("blob:")) {
    return logo;
  }
  const match = logo.match(/^(data:image\/[a-zA-Z0-9.+-]+;base64,)(.+)$/);
  if (!match) return logo.startsWith("data:image/svg+xml") ? logo : "";

  let payload = match[2].replace(/\s+/g, "").replace(/=+$/g, "");
  while (payload.length % 4 === 1) {
    payload = payload.slice(0, -1);
  }
  const padding = ["", "", "==", "="][payload.length % 4];
  payload += padding;
  return `${match[1]}${payload}`;
}

function imageToPngDataUrl(file, maxSize = 512) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      const context = canvas.getContext("2d");
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/png"));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Image illisible"));
    };
    image.src = url;
  });
}

function svgToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || "");
      if (!text.includes("<svg")) {
        reject(new Error("SVG invalide"));
        return;
      }
      resolve(`data:image/svg+xml;charset=utf-8,${encodeURIComponent(text)}`);
    };
    reader.onerror = () => reject(new Error("Lecture impossible"));
    reader.readAsText(file);
  });
}

function showToast(message) {
  ids.toast.textContent = message;
  ids.toast.classList.add("show");
  window.setTimeout(() => ids.toast.classList.remove("show"), 2200);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setView(view) {
  if (!canAccessView(view)) {
    showToast("Accès non autorisé");
    view = firstAllowedView();
  }
  currentView = view;
  applyViewState();
  render();
}

function applyViewState() {
  document.querySelectorAll(".view").forEach(section => {
    section.classList.toggle("active", section.dataset.view === currentView);
  });
  document.querySelectorAll("[data-view-target]").forEach(button => {
    const target = button.dataset.viewTarget;
    const allowed = canAccessView(target);
    button.hidden = !allowed;
    button.disabled = !allowed;
    button.classList.toggle("active", target === currentView);
  });
  ids.pageTitle.textContent = VIEW_LABELS[currentView] || "Tableau de bord";
}

function render() {
  ensureCollections();
  ensurePaymentMotifs();
  if (!canAccessView(currentView)) {
    currentView = firstAllowedView();
  }
  applyViewState();
  [
    ["identité", renderCenterIdentity],
    ["session", renderSession],
    ["sélecteurs", syncSelects],
    ["tableau de bord", renderDashboard],
    ["étudiants", renderStudents],
    ["formations", renderCourses],
    ["promotions", renderGroups],
    ["inscriptions", renderEnrollments],
    ["paiements", renderPayments],
    ["caisse", renderCash],
    ["présences", renderAttendance],
    ["présences professeurs", renderTrainerAttendance],
    ["formateurs", renderTrainers],
    ["personnel", renderStaff],
    ["rapports", renderReports],
    ["notes", renderEvaluations],
    ["paramètres", renderSettings]
  ].forEach(([label, step]) => {
    try {
      step();
    } catch (error) {
      console.error(`Erreur rendu ${label} :`, error);
    }
  });
  applyTablePagination();
}

function renderSession() {
  const roleSelect = document.getElementById("roleSelect");
  const logoutButton = document.getElementById("logoutButton");

  if (!SERVER_MODE) {
    ids.currentUserName.textContent = "Mode local";
    logoutButton.hidden = true;
    roleSelect.disabled = false;
    return;
  }

  ids.currentUserName.textContent = currentUser
    ? `${currentUser.name} - ${currentUser.role}`
    : "Non connecté";
  logoutButton.hidden = !currentUser;
  roleSelect.disabled = true;
  if (currentUser?.role) {
    roleSelect.value = currentUser.role;
  }
}

function applyTablePagination() {
  document.querySelectorAll(".table-pagination").forEach(control => control.remove());
  document.querySelectorAll(".view tbody[id] tr").forEach(row => {
    row.hidden = false;
  });
}

function renderAndPaginate(step, tableIds = []) {
  tableIds.forEach(tableId => {
    tablePages[tableId] = 1;
  });
  step();
  applyTablePagination();
}

function paginateTableBody(tbody) {
  const rows = [...tbody.children].filter(row => row.tagName === "TR");
  const tableId = tbody.id;
  const tableWrap = tbody.closest(".table-wrap");
  if (!tableId || !tableWrap) return;

  let controls = tableWrap.nextElementSibling;
  if (!controls || controls.dataset.paginationFor !== tableId) {
    controls = document.createElement("div");
    controls.className = "table-pagination";
    controls.dataset.paginationFor = tableId;
    tableWrap.insertAdjacentElement("afterend", controls);
  }

  if (rows.length <= TABLE_PAGE_SIZE || rows.some(row => row.querySelector("td[colspan]"))) {
    rows.forEach(row => { row.hidden = false; });
    controls.hidden = true;
    controls.innerHTML = "";
    tablePages[tableId] = 1;
    return;
  }

  const totalPages = Math.max(1, Math.ceil(rows.length / TABLE_PAGE_SIZE));
  const page = Math.min(Math.max(1, tablePages[tableId] || 1), totalPages);
  tablePages[tableId] = page;
  const start = (page - 1) * TABLE_PAGE_SIZE;
  const end = start + TABLE_PAGE_SIZE;

  rows.forEach((row, index) => {
    row.hidden = index < start || index >= end;
  });

  controls.hidden = false;
  controls.innerHTML = `
    <span>${start + 1}-${Math.min(end, rows.length)} sur ${rows.length}</span>
    <div>
      <button class="chip-button" type="button" data-table-page="${tableId}" data-page-direction="prev" ${page <= 1 ? "disabled" : ""}>Précédent</button>
      <strong>Page ${page} / ${totalPages}</strong>
      <button class="chip-button" type="button" data-table-page="${tableId}" data-page-direction="next" ${page >= totalPages ? "disabled" : ""}>Suivant</button>
    </div>
  `;
}

function handleTablePaginationClick(event) {
  const button = event.target.closest("[data-table-page]");
  if (!button) return;
  const tableId = button.dataset.tablePage;
  const direction = button.dataset.pageDirection;
  tablePages[tableId] = Math.max(1, (tablePages[tableId] || 1) + (direction === "next" ? 1 : -1));
  const tbody = document.getElementById(tableId);
  if (tbody) paginateTableBody(tbody);
}

function renderCenterIdentity() {
  const center = state.center || {};
  const name = center.name || "CFP EREXIT";
  const subtitle = center.subtitle || "Centre de Formation Professionnelle";
  const logoSrc = normalizeLogoData(center.logoData);
  if (logoSrc && logoSrc !== center.logoData) {
    state.center = { ...center, logoData: logoSrc };
    saveState();
  }
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0])
    .join("")
    .toUpperCase() || "CE";

  document.querySelectorAll(".brand-mark, .choice-mark").forEach(mark => {
    const fallback = mark.classList.contains("choice-mark") ? mark.textContent.trim() || initials : initials;
    mark.innerHTML = logoSrc
      ? `<img src="${escapeHtml(logoSrc)}" alt="" aria-hidden="true">`
      : escapeHtml(fallback);
  });

  document.querySelectorAll(".brand h1").forEach(title => {
    title.textContent = name;
  });

  const sidebarSubtitle = document.querySelector(".sidebar .brand p");
  if (sidebarSubtitle) {
    sidebarSubtitle.textContent = subtitle;
  }

  if (ids.centerLogoPreview) {
    ids.centerLogoPreview.innerHTML = logoSrc
      ? `<img src="${escapeHtml(logoSrc)}" alt="" aria-hidden="true">`
      : escapeHtml(initials);
  }
  if (ids.centerStampPreview) {
    const stampSrc = normalizeLogoData(center.stampData);
    ids.centerStampPreview.innerHTML = stampSrc
      ? `<img src="${escapeHtml(stampSrc)}" alt="" aria-hidden="true">`
      : "Cachet";
  }
}

function renderDashboard() {
  const activeStudents = state.students.filter(student => student.status === "actif").length;
  const activeCourses = state.courses.filter(course => course.status === "active").length;
  const totalPaid = paymentsTotal();
  const tuitionPaid = tuitionPaymentsTotal();
  const annexPaid = annexPaymentsTotal();
  const totalExpenses = cashExpenseTotal();
  const totalDue = state.enrollments.reduce((sum, enrollment) => sum + balanceForEnrollment(enrollment), 0);
  const todayPayments = state.payments
    .filter(payment => payment.date === today())
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);

  ids.statsGrid.innerHTML = [
    { label: "Étudiants actifs", value: activeStudents, tone: "blue" },
    { label: "Formations actives", value: activeCourses, tone: "green" },
    { label: "Inscriptions", value: state.enrollments.length, tone: "gold" },
    { label: "Scolarité reçue", value: tuitionPaid, type: "money", tone: "green" },
    { label: "Frais annexes", value: annexPaid, type: "money", tone: "sky" },
    { label: "Paiements reçus", value: totalPaid, type: "money", tone: "indigo" },
    { label: "Dépenses", value: totalExpenses, type: "money", tone: "orange" },
    { label: "Solde caisse", value: netCashTotal(), type: "money", tone: "green" },
    { label: "Reste scolarité", value: totalDue, type: "money", tone: "red" }
  ].map(item => `
    <article class="stat-card tone-${item.tone}">
      <span>${escapeHtml(item.label)}</span>
      ${statValueHtml(item)}
    </article>
  `).join("");

  const recentPayments = [...state.payments]
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .slice(0, 5);

  ids.recentPaymentsTable.innerHTML = recentPayments.map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    const controlInfo = payment.correctedAt
      ? `<div class="muted">Corrige le ${escapeHtml(formatDate(payment.correctedAt))}</div>`
      : "";
    return `
      <tr>
        <td>${escapeHtml(payment.receiptNumber)}${controlInfo}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td class="amount-positive">${formatMoney(payment.amount)}</td>
        <td>${formatDate(payment.date)}</td>
      </tr>
    `;
  }).join("") || emptyRow(4, "Aucun paiement");

  ids.balancesTable.innerHTML = balances()
    .slice(0, 6)
    .map(item => `
      <tr>
        <td>${escapeHtml(item.student)}</td>
        <td>
          <strong>${escapeHtml(item.course)}</strong>
          <div class="muted">${escapeHtml(item.sessionType)}</div>
        </td>
        <td class="amount-danger">${formatMoney(item.balance)}</td>
      </tr>
    `).join("") || emptyRow(3, "Aucun impayé");

  const alerts = paymentAlerts();
  const urgentAlerts = alerts.filter(alert => alert.severity === "danger").length;
  ids.paymentAlertCount.textContent = `${alerts.length} alerte(s)${urgentAlerts ? `, ${urgentAlerts} urgente(s)` : ""}`;
  ids.paymentAlertsTable.innerHTML = alerts.slice(0, 8).map(alert => `
    <tr>
      <td>
        <strong>${escapeHtml(alert.student)}</strong>
        <div class="muted">${escapeHtml(alert.detail)} - ${escapeHtml(alert.sessionType)}</div>
      </td>
      <td><span class="alert-pill ${alert.severity}">${escapeHtml(alert.message)}</span></td>
      <td class="${alert.severity === "danger" ? "amount-danger" : ""}">${formatMoney(alert.amount)}</td>
      <td>${alert.lastPaymentDate ? formatDate(alert.lastPaymentDate) : "Aucun"}</td>
      <td>
        <button class="chip-button success" type="button" data-action="pay-alert" data-id="${alert.enrollmentId}" data-reason="${escapeHtml(alert.reasonKey)}">Encaisser</button>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucune alerte");

  renderDashboardAnalytics({
    tuitionPaid,
    annexPaid,
    totalExpenses,
    totalDue
  });

  if (todayPayments > 0) {
    document.title = `CFP EREXIT - ${formatMoney(todayPayments)} aujourd'hui`;
  } else {
    document.title = "CFP EREXIT Manager";
  }
}

function renderDashboardAnalytics({ tuitionPaid, annexPaid, totalExpenses, totalDue }) {
  const totalExpected = state.enrollments.reduce((sum, enrollment) => sum + Number(enrollment.finalAmount || 0), 0);
  const recoveryRate = totalExpected > 0 ? Math.round((tuitionPaid / totalExpected) * 100) : 0;
  const clampedRate = Math.max(0, Math.min(100, recoveryRate));
  const financeItems = [
    { label: "Scolarité", value: tuitionPaid, className: "tuition" },
    { label: "Annexes", value: annexPaid, className: "annex" },
    { label: "Dépenses", value: totalExpenses, className: "expense" },
    { label: "Reste", value: totalDue, className: "balance" }
  ];
  const maxFinance = Math.max(1, ...financeItems.map(item => item.value));

  ids.dashboardFinanceBars.innerHTML = `
    <h4>Flux financiers</h4>
    ${financeItems.map(item => `
      <div class="analytics-bar-row">
        <div>
          <strong>${escapeHtml(item.label)}</strong>
          <span>${formatMoney(item.value)}</span>
        </div>
        <div class="analytics-track">
          <div class="analytics-fill ${item.className}" style="width: ${(item.value / maxFinance) * 100}%"></div>
        </div>
        <em>${formatCompactMoney(item.value)}</em>
      </div>
    `).join("")}
  `;

  ids.dashboardTuitionRing.style.setProperty("--progress", `${clampedRate}%`);
  ids.dashboardTuitionRing.innerHTML = `
    <strong>${clampedRate}%</strong>
    <span>recouvré</span>
  `;
  ids.dashboardTuitionDetails.innerHTML = `
    <strong>Recouvrement scolarité</strong>
    <span>${formatMoney(tuitionPaid)} encaissés</span>
    <span>${formatMoney(totalExpected)} attendus</span>
  `;

  const courseItems = state.courses.map(course => {
    const enrollments = state.enrollments.filter(enrollment => Number(enrollment.courseId) === Number(course.id));
    return {
      label: course.code || course.name,
      value: enrollments.length
    };
  }).filter(item => item.value > 0);
  const maxCourse = Math.max(1, ...courseItems.map(item => item.value));
  ids.dashboardCourseBars.innerHTML = `
    <h4>Inscriptions par formation</h4>
    ${courseItems.map(item => `
      <div class="course-analytics-row">
        <span>${escapeHtml(item.label)}</span>
        <div class="analytics-track">
          <div class="analytics-fill course" style="width: ${(item.value / maxCourse) * 100}%"></div>
        </div>
        <strong>${item.value}</strong>
      </div>
    `).join("") || `<p class="muted">Aucune inscription</p>`}
  `;
}

function renderStudents() {
  const query = document.getElementById("studentSearch").value.trim().toLowerCase();
  const status = document.getElementById("studentStatusFilter").value;
  const filtered = state.students.filter(student => {
    const haystack = [student.matricule, student.firstName, student.lastName, student.phone, student.email]
      .join(" ")
      .toLowerCase();
    return (!query || haystack.includes(query)) && (!status || student.status === status);
  });

  ids.studentCount.textContent = `${filtered.length} sur ${state.students.length}`;
  ids.studentsTable.innerHTML = filtered.map(student => `
    <tr>
      <td>${escapeHtml(student.matricule)}</td>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(student, "ET")}
          <div>
            <strong>${escapeHtml(fullName(student))}</strong>
            <div class="muted">${escapeHtml(student.email || student.address || "")}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(student))}</div>
            <div>${documentCompletionBadge(student, "student")}</div>
          </div>
        </div>
      </td>
      <td>${escapeHtml(student.phone || "-")}</td>
      <td><span class="status ${statusClass(student.status)}">${escapeHtml(student.status)}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-student" data-id="${student.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-student" data-id="${student.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun étudiant");
}

function renderCourses() {
  const query = document.getElementById("courseSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("courseStatusFilter")?.value || "";
  const courses = state.courses.filter(course => {
    const haystack = [course.code, course.name, course.duration, course.description].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || course.status === status);
  });
  ids.courseCount.textContent = `${courses.length} sur ${state.courses.length}`;
  ids.coursesTable.innerHTML = courses.map(course => `
    <tr>
      <td>${escapeHtml(course.code)}</td>
      <td>
        <strong>${escapeHtml(course.name)}</strong>
        <div class="muted">${escapeHtml(course.description || "")}</div>
      </td>
      <td>${escapeHtml(course.duration || "-")}</td>
      <td>${formatMoney(courseCost(course))}</td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-course" data-id="${course.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-course" data-id="${course.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucune formation");
}

function renderGroups() {
  const courseFilter = document.getElementById("groupCourseFilter")?.value || "";
  const sessionFilter = document.getElementById("groupSessionFilter")?.value || "";
  const statusFilter = document.getElementById("groupStatusFilter")?.value || "";
  const groups = state.groups.filter(group =>
    (!courseFilter || String(group.courseId) === courseFilter) &&
    (!sessionFilter || String(group.sessionType || "jour") === sessionFilter) &&
    (!statusFilter || String(group.status || "") === statusFilter)
  );
  ids.groupCount.textContent = `${groups.length} sur ${state.groups.length}`;
  ids.groupsTable.innerHTML = groups.map(group => {
    const course = getCourse(group.courseId);
    const count = state.enrollments.filter(enrollment => Number(enrollment.groupId) === Number(group.id)).length;
    return `
      <tr>
        <td>
          <strong>${escapeHtml(group.name)}</strong>
          <div class="muted">${escapeHtml(group.trainer || "Formateur non précisé")}</div>
        </td>
        <td>${escapeHtml(course?.name || "-")}</td>
        <td><span class="status ${String(group.sessionType || "jour") === "soir" ? "termine" : String(group.sessionType || "jour") === "ligne" ? "excuse" : "active"}">${escapeHtml(groupSessionLabel(group))}</span></td>
        <td>${count}${group.capacity ? ` / ${group.capacity}` : ""}</td>
        <td>${formatDate(group.startDate)} - ${formatDate(group.endDate)}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="edit-group" data-id="${group.id}">Modifier</button>
            <button class="chip-button danger" type="button" data-action="delete-group" data-id="${group.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(6, "Aucune promotion");
}

function renderEnrollments() {
  const query = document.getElementById("enrollmentSearch")?.value.trim().toLowerCase() || "";
  const courseFilter = document.getElementById("enrollmentCourseFilter")?.value || "";
  const statusFilter = document.getElementById("enrollmentStatusFilter")?.value || "";
  const balanceFilter = document.getElementById("enrollmentBalanceFilter")?.value || "";
  const enrollments = state.enrollments.filter(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    const balance = balanceForEnrollment(enrollment);
    const haystack = [fullName(student), student?.matricule, course?.name, course?.code, group?.name].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) &&
      (!courseFilter || String(enrollment.courseId) === courseFilter) &&
      (!statusFilter || enrollment.status === statusFilter) &&
      (!balanceFilter || (balanceFilter === "due" ? balance > 0 : balance <= 0));
  });
  ids.enrollmentCount.textContent = `${enrollments.length} sur ${state.enrollments.length}`;
  ids.enrollmentsTable.innerHTML = enrollments.map(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    const paid = paidAmount(enrollment.id);
    const annexPaid = annexPaidAmount(enrollment.id);
    const balance = balanceForEnrollment(enrollment);
    return `
      <tr>
        <td>${escapeHtml(fullName(student))}</td>
        <td>${escapeHtml(course?.name || "-")}</td>
        <td>
          <strong>${escapeHtml(group?.name || "-")}</strong>
          <div class="muted">${escapeHtml(groupSessionLabel(group))}</div>
        </td>
        <td class="amount-positive">${formatMoney(paid)}</td>
        <td>${formatMoney(annexPaid)}</td>
        <td class="${balance > 0 ? "amount-danger" : "amount-positive"}">${formatMoney(balance)}</td>
        <td>
          <div class="actions">
            <button class="chip-button success" type="button" data-action="pay-enrollment" data-id="${enrollment.id}">Payer</button>
            <button class="chip-button" type="button" data-action="print-enrollment" data-id="${enrollment.id}">Fiche</button>
            <button class="chip-button" type="button" data-action="print-attestation" data-id="${enrollment.id}">Attestation</button>
            <button class="chip-button" type="button" data-action="print-contract" data-id="${enrollment.id}">Contrat</button>
            <button class="chip-button" type="button" data-action="edit-enrollment" data-id="${enrollment.id}">Modifier</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(7, "Aucune inscription");
}

function renderPayments() {
  const allowControl = canControlPayments();
  const query = document.getElementById("paymentSearch")?.value.trim().toLowerCase() || "";
  const category = document.getElementById("paymentCategoryFilter")?.value || "";
  const method = document.getElementById("paymentMethodFilter")?.value || "";
  const month = document.getElementById("paymentMonthFilter")?.value || "";
  const payments = state.payments.filter(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    const tuition = isTuitionPayment(payment);
    const haystack = [payment.receiptNumber, fullName(student), payment.reason, payment.method, payment.date].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) &&
      (!category || (category === "tuition" ? tuition : !tuition)) &&
      (!method || payment.method === method) &&
      (!month || String(payment.date).startsWith(month));
  });
  ids.paymentCount.textContent = `${payments.length} sur ${state.payments.length}`;
  ids.paymentsTable.innerHTML = [...payments].reverse().map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return `
      <tr>
        <td>${escapeHtml(payment.receiptNumber)}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td>${escapeHtml(payment.reason || "-")}</td>
        <td><span class="status ${isTuitionPayment(payment) ? "active" : "termine"}">${isTuitionPayment(payment) ? "Scolarité" : "Annexe"}</span></td>
        <td class="amount-positive">${formatMoney(payment.amount)}</td>
        <td>${escapeHtml(payment.method)}</td>
        <td>${formatDate(payment.date)}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-receipt" data-id="${payment.id}">Reçu</button>
            ${allowControl ? `<button class="chip-button" type="button" data-action="edit-payment" data-id="${payment.id}">Modifier</button>` : ""}
            ${allowControl ? `<button class="chip-button danger" type="button" data-action="delete-payment" data-id="${payment.id}">Supprimer</button>` : ""}
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(8, "Aucun paiement");
  const auditItems = [...state.paymentAuditLog].reverse();
  ids.paymentAuditCount.textContent = `${auditItems.length} action(s)`;
  ids.paymentAuditTable.innerHTML = auditItems.map(item => {
    const source = item.before || item.after || {};
    const enrollment = getEnrollment(source.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return `
      <tr>
        <td>${formatDate(String(item.date || "").slice(0, 10))}</td>
        <td><span class="status ${item.action === "Suppression" ? "annulee" : "en-attente"}">${escapeHtml(item.action || "-")}</span></td>
        <td>${escapeHtml(item.receiptNumber || source.receiptNumber || "-")}</td>
        <td>${escapeHtml(fullName(student))}</td>
        <td>
          <strong>${escapeHtml(source.reason || "-")}</strong>
          <div class="muted">${escapeHtml(source.method || "")} ${source.date ? `- ${formatDate(source.date)}` : ""}</div>
        </td>
        <td class="amount-danger">${formatMoney(source.amount || 0)}</td>
        <td>${escapeHtml(item.operator || "-")}</td>
        <td>${escapeHtml(item.controlReason || "-")}</td>
      </tr>
    `;
  }).join("") || emptyRow(8, "Aucune correction");
  updatePaymentBalance();
}

function renderCash() {
  const entries = [...state.cashEntries].sort((a, b) => String(b.date).localeCompare(String(a.date)) || Number(b.id) - Number(a.id));
  ids.cashBalance.textContent = `Solde : ${formatMoney(netCashTotal())}`;
  ids.cashCount.textContent = `${entries.length} opération(s)`;
  ids.cashTable.innerHTML = entries.map(entry => {
    const isIncome = entry.type === "income";
    return `
      <tr>
        <td>${formatDate(entry.date)}</td>
        <td><span class="status ${isIncome ? "active" : "annulee"}">${isIncome ? "Entrée" : "Dépense"}</span></td>
        <td>
          <strong>${escapeHtml(entry.category || "-")}</strong>
          <div class="muted">${escapeHtml(entry.description || "")}</div>
        </td>
        <td class="${isIncome ? "amount-positive" : "amount-danger"}">${formatMoney(entry.amount)}</td>
        <td>${escapeHtml(entry.method || "-")}</td>
        <td>
          <div class="actions">
            <button class="chip-button danger" type="button" data-action="delete-cash-entry" data-id="${entry.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(6, "Aucune opération de caisse");
}

function renderAttendance() {
  const groupId = Number(document.getElementById("attendanceGroup").value);
  const enrolled = state.enrollments
    .filter(enrollment => Number(enrollment.groupId) === groupId && enrollment.status !== "annulee")
    .map(enrollment => getStudent(enrollment.studentId))
    .filter(Boolean);

  ids.attendanceTotal.textContent = `${enrolled.length} étudiant(s)`;
  ids.attendanceList.innerHTML = enrolled.map(student => `
    <div class="attendance-row">
      <div class="student-line">
        <strong>${escapeHtml(fullName(student))}</strong>
        <span>${escapeHtml(student.matricule)}</span>
      </div>
      <select data-attendance-student="${student.id}">
        <option value="present">Présent</option>
        <option value="absent">Absent</option>
        <option value="retard">Retard</option>
        <option value="excuse">Excusé</option>
      </select>
    </div>
  `).join("") || `<p class="muted">Aucun étudiant inscrit dans cette promotion.</p>`;

  ids.attendanceCount.textContent = `${state.attendanceSessions.length} séance(s)`;
  ids.attendanceTable.innerHTML = [...state.attendanceSessions].reverse().map(session => {
    const group = getGroup(session.groupId);
    const present = session.records.filter(record => record.status === "present").length;
    const absent = session.records.filter(record => record.status === "absent").length;
    const late = session.records.filter(record => record.status === "retard").length;
    return `
      <tr>
        <td>${formatDate(session.date)}</td>
        <td>
          <strong>${escapeHtml(group?.name || "-")}</strong>
          <div class="muted">${escapeHtml(session.topic || "")}</div>
        </td>
        <td>${present}</td>
        <td>${absent}</td>
        <td>${late}</td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucun appel enregistré");
}

function renderTrainerAttendance() {
  const trainers = state.trainers.filter(trainer => (trainer.status || "actif") !== "archive");

  ids.trainerAttendanceTotal.textContent = `${trainers.length} professeur(s)`;
  ids.trainerAttendanceList.innerHTML = trainers.map(trainer => `
    <div class="attendance-row">
      <div class="student-line">
        <strong>${escapeHtml(trainerName(trainer))}</strong>
        <span>${escapeHtml(trainer.modules || trainer.specialty || "")}</span>
      </div>
      <select data-attendance-trainer="${trainer.id}">
        <option value="present">Présent</option>
        <option value="absent">Absent</option>
        <option value="retard">Retard</option>
        <option value="excuse">Excusé</option>
      </select>
    </div>
  `).join("") || `<p class="muted">Aucun professeur enregistré.</p>`;

  ids.trainerAttendanceCount.textContent = `${state.trainerAttendanceSessions.length} appel(s)`;
  ids.trainerAttendanceTable.innerHTML = [...state.trainerAttendanceSessions].reverse().map(session => {
    const present = session.records.filter(record => record.status === "present").length;
    const absent = session.records.filter(record => record.status === "absent").length;
    const late = session.records.filter(record => record.status === "retard").length;
    return `
      <tr>
        <td>${formatDate(session.date)}</td>
        <td>
          <strong>${session.records.length} professeur(s)</strong>
          <div class="muted">${escapeHtml(session.topic || "")}</div>
        </td>
        <td>${present}</td>
        <td>${absent}</td>
        <td>${late}</td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucun appel professeur enregistré");
}

function renderTrainers() {
  const query = document.getElementById("trainerSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("trainerStatusFilter")?.value || "";
  const trainers = state.trainers.filter(trainer => {
    const haystack = [trainer.firstName, trainer.lastName, trainer.phone, trainer.email, trainer.specialty, trainer.modules].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || trainer.status === status);
  });
  ids.trainerCount.textContent = `${trainers.length} sur ${state.trainers.length}`;
  ids.trainersTable.innerHTML = trainers.map(trainer => `
    <tr>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(trainer, "FO")}
          <div>
            <strong>${escapeHtml(trainerName(trainer))}</strong>
            <div class="muted">${escapeHtml(trainer.modules || "")}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(trainer))}</div>
            <div>${documentCompletionBadge(trainer, "trainer")}</div>
          </div>
        </div>
      </td>
      <td>
        ${escapeHtml(trainer.phone || "-")}
        <div class="muted">${escapeHtml(trainer.email || "")}</div>
      </td>
      <td>${escapeHtml(trainer.specialty || "-")}</td>
      <td><span class="status ${statusClass(trainer.status)}">${escapeHtml(trainer.status || "actif")}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-trainer" data-id="${trainer.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-trainer" data-id="${trainer.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun formateur");
}

function renderStaff() {
  const query = document.getElementById("staffSearch")?.value.trim().toLowerCase() || "";
  const status = document.getElementById("staffStatusFilter")?.value || "";
  const members = state.staffMembers.filter(member => {
    const haystack = [member.firstName, member.lastName, member.role, member.phone, member.email].join(" ").toLowerCase();
    return (!query || haystack.includes(query)) && (!status || member.status === status);
  });
  const totalPaid = staffPaymentsTotal();
  ids.staffCount.textContent = `${members.length} membre(s)`;
  ids.staffPaymentTotal.textContent = formatMoney(totalPaid);
  ids.staffTable.innerHTML = members.map(member => `
    <tr>
      <td>
        <div class="person-cell">
          ${personPhotoHtml(member, "PE")}
          <div>
            <strong>${escapeHtml(staffName(member))}</strong>
            <div class="muted">${escapeHtml(member.phone || member.email || "")}</div>
            <div class="muted">${escapeHtml(personDocumentSummary(member))}</div>
            <div>${documentCompletionBadge(member, "staff")}</div>
          </div>
        </div>
      </td>
      <td>${escapeHtml(member.role || "-")}</td>
      <td>${formatMoney(member.salary)}</td>
      <td><span class="status ${statusClass(member.status)}">${escapeHtml(member.status || "actif")}</span></td>
      <td>
        <div class="actions">
          <button class="chip-button" type="button" data-action="edit-staff" data-id="${member.id}">Modifier</button>
          <button class="chip-button danger" type="button" data-action="delete-staff" data-id="${member.id}">Supprimer</button>
        </div>
      </td>
    </tr>
  `).join("") || emptyRow(5, "Aucun personnel");

  ids.staffPaymentCount.textContent = `${state.staffPayments.length} paiement(s)`;
  ids.staffPaymentsTable.innerHTML = [...state.staffPayments].reverse().map(payment => {
    const beneficiary = payrollBeneficiary(payment);
    return `
      <tr>
        <td>${formatDate(payment.date)}</td>
        <td>
          <strong>${escapeHtml(beneficiary.name)}</strong>
          <div class="muted">${escapeHtml(beneficiary.role)}</div>
          <div class="muted">${escapeHtml(payment.note || "")}</div>
        </td>
        <td>${escapeHtml(payment.period || "-")}</td>
        <td>${escapeHtml(payment.reason || "-")}</td>
        <td class="amount-danger">${formatMoney(payment.amount)}</td>
        <td>${escapeHtml(payment.method || "-")}</td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-payroll-slip" data-id="${payment.id}">Fiche</button>
            <button class="chip-button danger" type="button" data-action="delete-staff-payment" data-id="${payment.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(7, "Aucun paiement personnel");
}

function renderEvaluations() {
  updateEvaluationStudents();
  ids.evaluationCount.textContent = `${state.evaluations.length} evaluation(s)`;
  ids.evaluationsTable.innerHTML = [...state.evaluations].reverse().map(evaluation => {
    const group = getGroup(evaluation.groupId);
    const trainer = getTrainer(evaluation.trainerId);
    const makeup = evaluationMakeupStats(evaluation);
    return `
      <tr>
        <td>
          <strong>${escapeHtml(evaluation.title)}</strong>
          <div class="muted">${escapeHtml(evaluation.type || "-")} - ${escapeHtml(trainerName(trainer))}</div>
        </td>
        <td>${escapeHtml(group?.name || "-")}</td>
        <td>${formatDate(evaluation.date)}</td>
        <td>
          ${formatAverage(evaluation)}
          <div class="muted">${makeup.count} rattrapage(s) - ${formatMoney(makeup.amount)}</div>
        </td>
        <td>
          <div class="actions">
            <button class="chip-button" type="button" data-action="print-grades" data-id="${evaluation.id}">PV notes</button>
            <button class="chip-button" type="button" data-action="edit-evaluation" data-id="${evaluation.id}">Modifier</button>
            <button class="chip-button danger" type="button" data-action="delete-evaluation" data-id="${evaluation.id}">Supprimer</button>
          </div>
        </td>
      </tr>
    `;
  }).join("") || emptyRow(5, "Aucune evaluation");
}

function renderReports() {
  const totalPaid = paymentsTotal();
  const tuitionPaid = tuitionPaymentsTotal();
  const annexPaid = annexPaymentsTotal();
  const otherIncome = cashIncomeTotal();
  const totalExpenses = cashExpenseTotal();
  const month = today().slice(0, 7);
  const monthPaid = state.payments
    .filter(payment => String(payment.date).startsWith(month))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const monthOtherIncome = state.cashEntries
    .filter(entry => entry.type === "income" && String(entry.date).startsWith(month))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const monthExpenses = state.cashEntries
    .filter(entry => entry.type === "expense" && String(entry.date).startsWith(month))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalExpected = state.enrollments.reduce((sum, enrollment) => sum + Number(enrollment.finalAmount || 0), 0);
  const totalBalance = state.enrollments.reduce((sum, enrollment) => sum + balanceForEnrollment(enrollment), 0);

  ids.financialReport.innerHTML = [
    ["Scolarité attendue", formatMoney(totalExpected)],
    ["Scolarité encaissée", formatMoney(tuitionPaid)],
    ["Frais annexes encaissés", formatMoney(annexPaid)],
    ["Total paiements étudiants", formatMoney(totalPaid)],
    ["Autres entrées", formatMoney(otherIncome)],
    ["Dépenses", formatMoney(totalExpenses)],
    ["Solde net caisse", formatMoney(netCashTotal())],
    ["Encaissement du mois", formatMoney(monthPaid + monthOtherIncome)],
    ["Dépenses du mois", formatMoney(monthExpenses)],
    ["Reste scolarité", formatMoney(totalBalance)]
  ].map(([label, value]) => `
    <article class="mini-card">
      <span>${label}</span>
      <strong>${value}</strong>
    </article>
  `).join("");

  ids.reportBalancesTable.innerHTML = balances().map(item => `
    <tr>
      <td>${escapeHtml(item.student)}</td>
      <td>
        <strong>${escapeHtml(item.course)}</strong>
        <div class="muted">${escapeHtml(item.sessionType)} - Total ${formatMoney(item.finalAmount)}</div>
      </td>
      <td class="amount-positive">${formatMoney(item.paid)}</td>
      <td class="amount-danger">${formatMoney(item.balance)}</td>
    </tr>
  `).join("") || emptyRow(4, "Aucun impayé");

  const counts = state.courses.map(course => ({
    name: course.name,
    count: state.enrollments.filter(enrollment => Number(enrollment.courseId) === Number(course.id)).length
  }));
  const max = Math.max(1, ...counts.map(item => item.count));
  ids.courseDistribution.innerHTML = counts.map(item => `
    <div class="bar-row">
      <strong>${escapeHtml(item.name)}</strong>
      <div class="bar-track"><div class="bar-fill" style="width: ${(item.count / max) * 100}%"></div></div>
      <span>${item.count}</span>
    </div>
  `).join("");

  const scheduleRows = monthlyScheduleRows();
  ids.monthlyScheduleCount.textContent = `${scheduleRows.length} échéance(s)`;
  ids.monthlyScheduleTable.innerHTML = scheduleRows.map(row => `
    <tr>
      <td>${escapeHtml(row.month)}</td>
      <td>${escapeHtml(row.student)}</td>
      <td>${escapeHtml(row.course)}</td>
      <td>${formatMoney(row.expected)}</td>
      <td class="amount-positive">${formatMoney(row.paid)}</td>
      <td class="${row.balance > 0 ? "amount-danger" : "amount-positive"}">${formatMoney(row.balance)}</td>
    </tr>
  `).join("") || emptyRow(6, "Aucune échéance");

  renderDocumentGenerator();
  renderIndividualReport();
}

function addMonths(dateValue, count) {
  const date = new Date(`${dateValue || today()}T00:00:00`);
  date.setMonth(date.getMonth() + count);
  return date.toISOString().slice(0, 7);
}

function monthlyScheduleRows() {
  const rows = [];
  state.enrollments
    .filter(enrollment => !["annulee", "terminee"].includes(enrollment.status))
    .forEach(enrollment => {
      const course = getCourse(enrollment.courseId);
      const monthly = Number(course?.monthlyFee || 0);
      const finalAmount = Number(enrollment.finalAmount || 0);
      if (!monthly || !finalAmount) return;
      const student = getStudent(enrollment.studentId);
      const totalMonths = Math.max(1, Math.ceil(finalAmount / monthly));
      const tuitionPaid = paidAmount(enrollment.id);
      for (let index = 0; index < totalMonths; index += 1) {
        const expected = Math.min(monthly, finalAmount - (monthly * index));
        const cumulativeExpected = Math.min(finalAmount, monthly * (index + 1));
        const cumulativeBalance = Math.max(0, cumulativeExpected - tuitionPaid);
        rows.push({
          month: addMonths(enrollment.date, index),
          student: fullName(student),
          course: course?.name || "-",
          expected,
          paid: Math.min(tuitionPaid, cumulativeExpected),
          balance: cumulativeBalance
        });
      }
    });
  return rows.sort((a, b) => String(a.month).localeCompare(String(b.month)) || a.student.localeCompare(b.student));
}

function renderIndividualReport() {
  if (!ids.individualReportStudent || !ids.individualReportSummary || !ids.individualMotifTable) return;
  const { tuitionExpected, tuitionPaid, annexPaid, totalPaid, balance, paymentsByMotif } = individualStudentReportData();

  ids.individualReportSummary.innerHTML = [
    ["Scolarité due", formatMoney(tuitionExpected)],
    ["Scolarité payée", formatMoney(tuitionPaid)],
    ["Reste scolarité", formatMoney(balance)],
    ["Frais annexes payés", formatMoney(annexPaid)],
    ["Total payé", formatMoney(totalPaid)]
  ].map(([label, value]) => `
    <article class="mini-card">
      <span>${label}</span>
      <strong>${value}</strong>
    </article>
  `).join("");

  ids.individualMotifTable.innerHTML = paymentsByMotif.map(item => `
    <tr>
      <td>${escapeHtml(item.reason)}</td>
      <td><span class="status ${item.category === "Scolarité" ? "active" : "termine"}">${escapeHtml(item.category)}</span></td>
      <td class="amount-positive">${formatMoney(item.amount)}</td>
      <td>${formatDate(item.lastDate)}</td>
    </tr>
  `).join("") || emptyRow(4, "Aucun paiement pour cet étudiant");
}

function individualStudentReportData(studentId = Number(ids.individualReportStudent?.value || state.students[0]?.id || 0)) {
  const student = getStudent(studentId);
  const enrollments = state.enrollments.filter(enrollment => Number(enrollment.studentId) === studentId);
  const payments = enrollments
    .flatMap(enrollment => paymentsForEnrollment(enrollment.id).map(payment => ({ ...payment, enrollment })))
    .sort((a, b) => String(a.date).localeCompare(String(b.date)) || Number(a.id) - Number(b.id));
  const tuitionExpected = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.finalAmount || 0), 0);
  const tuitionPaid = enrollments.reduce((sum, enrollment) => sum + paidAmount(enrollment.id), 0);
  const annexPaid = enrollments.reduce((sum, enrollment) => sum + annexPaidAmount(enrollment.id), 0);
  const totalPaid = tuitionPaid + annexPaid;
  const balance = Math.max(0, tuitionExpected - tuitionPaid);
  const byMotif = new Map();

  payments.forEach(payment => {
    const key = payment.reasonKey || payment.reason || "motif";
    const current = byMotif.get(key) || {
      reason: payment.reason || key,
      category: isTuitionPayment(payment) ? "Scolarité" : "Frais annexe",
      amount: 0,
      lastDate: ""
    };
    current.amount += Number(payment.amount || 0);
    if (!current.lastDate || String(payment.date).localeCompare(String(current.lastDate)) > 0) {
      current.lastDate = payment.date;
    }
    byMotif.set(key, current);
  });

  return {
    student,
    enrollments,
    payments,
    paymentsByMotif: [...byMotif.values()],
    tuitionExpected,
    tuitionPaid,
    annexPaid,
    totalPaid,
    balance
  };
}

function activeDocumentTemplates() {
  ensureDocumentTemplates();
  return state.documentTemplates
    .filter(template => template.status !== "archive")
    .map(template => ({ ...template, id: template.key }))
    .sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title)));
}

function templateByKey(key) {
  ensureDocumentTemplates();
  return state.documentTemplates.find(template => template.key === key);
}

function latestEnrollmentForStudent(studentId) {
  return state.enrollments
    .filter(enrollment => Number(enrollment.studentId) === Number(studentId))
    .sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")) || Number(b.id) - Number(a.id))[0];
}

function documentTemplateContext({ enrollmentId = 0, studentId = 0, beneficiaryValue = "" } = {}) {
  const center = state.center || {};
  const enrollment = getEnrollment(enrollmentId) || latestEnrollmentForStudent(studentId) || state.enrollments[0];
  const student = getStudent(studentId) || getStudent(enrollment?.studentId);
  const course = getCourse(enrollment?.courseId);
  const group = getGroup(enrollment?.groupId);
  const parsedBeneficiary = parsePayrollBeneficiary(beneficiaryValue);
  const person = parsedBeneficiary.type === "trainer"
    ? getTrainer(parsedBeneficiary.id)
    : getStaffMember(parsedBeneficiary.id);
  const beneficiaryName = parsedBeneficiary.type === "trainer" ? trainerName(person) : staffName(person);
  const beneficiaryRole = parsedBeneficiary.type === "trainer" ? "Formateur" : (person?.role || "Personnel");

  return {
    centre_nom: center.name || "CFP EREXIT",
    centre_sous_titre: center.subtitle || "Centre de Formation Professionnelle",
    centre_telephone: center.phone || "",
    centre_email: center.email || "",
    centre_adresse: center.address || "",
    etudiant_nom: fullName(student),
    matricule: student?.matricule || "",
    telephone: student?.phone || person?.phone || "",
    email: student?.email || person?.email || "",
    formation: course?.name || "",
    promotion: group?.name || "",
    type_cours: groupSessionLabel(group),
    date_inscription: enrollment?.date ? formatDate(enrollment.date) : "",
    scolarite: enrollment ? formatMoney(enrollment.finalAmount) : "",
    scolarite_payee: enrollment ? formatMoney(paidAmount(enrollment.id)) : "",
    reste_scolarite: enrollment ? formatMoney(balanceForEnrollment(enrollment)) : "",
    beneficiaire_nom: beneficiaryName,
    fonction: beneficiaryRole,
    date: formatDate(today())
  };
}

function renderTemplateContent(content, context) {
  const resolved = String(content || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) => context[key] ?? "");
  return resolved
    .split(/\n{2,}/)
    .map(paragraph => `<p>${escapeHtml(paragraph).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

function renderDocumentGenerator() {
  if (!ids.documentGeneratorTemplate) return;
  const template = templateByKey(ids.documentGeneratorTemplate.value) || activeDocumentTemplates()[0];
  if (!template) return;
  const studentLabel = ids.documentGeneratorStudent?.closest("label");
  const beneficiaryLabel = ids.documentGeneratorBeneficiary?.closest("label");
  if (studentLabel) studentLabel.hidden = template.audience === "staff" || template.audience === "general";
  if (beneficiaryLabel) beneficiaryLabel.hidden = template.audience === "student" || template.audience === "general";
}

function printTemplateDocument(templateKey, options = {}) {
  const template = templateByKey(templateKey);
  if (!template) {
    showToast("Modèle introuvable");
    return;
  }
  const context = documentTemplateContext(options);
  const stampSrc = normalizeLogoData(state.center?.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(template.title)}
      <div class="custom-document-body">
        ${renderTemplateContent(template.content, context)}
      </div>
      <div class="document-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <strong>Signature et cachet</strong>
      </div>
    </section>
  `;
  window.print();
}

function printSelectedDocumentTemplate() {
  const templateKey = ids.documentGeneratorTemplate?.value;
  if (!templateKey) {
    showToast("Choisissez un modèle");
    return;
  }
  printTemplateDocument(templateKey, {
    studentId: Number(ids.documentGeneratorStudent?.value || 0),
    beneficiaryValue: ids.documentGeneratorBeneficiary?.value || ""
  });
}

function renderDocumentTemplates() {
  if (!ids.documentTemplateList) return;
  ensureDocumentTemplates();
  const templates = [...state.documentTemplates].sort((a, b) =>
    String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title))
  );
  ids.documentTemplateList.innerHTML = templates.map(template => `
    <article class="document-template-card ${template.status === "archive" ? "is-archived" : ""}">
      <div>
        <strong>${escapeHtml(template.title)}</strong>
        <span>${escapeHtml(template.category)} · ${documentAudienceLabel(template.audience)} · ${template.status === "archive" ? "Archivé" : "Actif"}</span>
      </div>
      <div class="row-actions">
        <button class="chip-button" type="button" data-action="edit-document-template" data-key="${escapeHtml(template.key)}">Modifier</button>
        <button class="chip-button danger" type="button" data-action="delete-document-template" data-key="${escapeHtml(template.key)}">${template.locked ? "Archiver" : "Supprimer"}</button>
      </div>
    </article>
  `).join("") || `<p class="muted">Aucun modèle de document.</p>`;
}

function documentAudienceLabel(audience) {
  if (audience === "staff") return "Personnel";
  if (audience === "general") return "Général";
  return "Étudiant";
}

function slugifyTemplateKey(value) {
  const base = normalizeSearchText(value)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "modele-document";
  let key = base;
  let index = 2;
  while (state.documentTemplates.some(template => template.key === key)) {
    key = `${base}-${index}`;
    index += 1;
  }
  return key;
}

function resetDocumentTemplateForm() {
  if (!ids.documentTemplateTitle) return;
  ids.documentTemplateEditKey.value = "";
  ids.documentTemplateTitle.value = "";
  ids.documentTemplateCategory.value = "Attestation";
  ids.documentTemplateAudience.value = "student";
  ids.documentTemplateStatus.value = "active";
  ids.documentTemplateContent.value = "";
}

function editDocumentTemplate(key) {
  const template = templateByKey(key);
  if (!template || !ids.documentTemplateTitle) return;
  ids.documentTemplateEditKey.value = template.key;
  ids.documentTemplateTitle.value = template.title || "";
  ids.documentTemplateCategory.value = template.category || "Attestation";
  ids.documentTemplateAudience.value = template.audience || "student";
  ids.documentTemplateStatus.value = template.status || "active";
  ids.documentTemplateContent.value = template.content || "";
  ids.documentTemplateTitle.focus();
}

function saveDocumentTemplate(event) {
  event.preventDefault();
  const editKey = ids.documentTemplateEditKey.value;
  const payload = {
    title: ids.documentTemplateTitle.value.trim(),
    category: ids.documentTemplateCategory.value,
    audience: ids.documentTemplateAudience.value,
    status: ids.documentTemplateStatus.value,
    content: ids.documentTemplateContent.value.trim()
  };
  if (!payload.title || !payload.content) return;

  const existing = templateByKey(editKey);
  if (existing) {
    Object.assign(existing, payload);
    showToast("Modèle modifié");
  } else {
    state.documentTemplates.push({
      key: slugifyTemplateKey(payload.title),
      locked: false,
      ...payload
    });
    showToast("Modèle ajouté");
  }

  saveState();
  resetDocumentTemplateForm();
  syncSelects();
  renderDocumentTemplates();
}

function deleteDocumentTemplate(key) {
  const template = templateByKey(key);
  if (!template) return;
  if (template.locked) {
    template.status = "archive";
    showToast("Modèle archivé");
  } else {
    state.documentTemplates = state.documentTemplates.filter(item => item.key !== key);
    showToast("Modèle supprimé");
  }
  saveState();
  resetDocumentTemplateForm();
  syncSelects();
  renderDocumentTemplates();
}

function renderSettings() {
  renderUserAccessSettings();
  renderLoginHistory();
  renderAuditLog();
  if (!canAccessView("settings")) return;

  document.getElementById("centerName").value = state.center?.name || "CFP EREXIT";
  document.getElementById("centerSubtitle").value = state.center?.subtitle || "Centre de Formation Professionnelle";
  document.getElementById("centerPhone").value = state.center?.phone || "";
  document.getElementById("centerEmail").value = state.center?.email || "";
  document.getElementById("centerAddress").value = state.center?.address || "";
  ensurePaymentMotifs();
  ids.paymentMotifsSettings.innerHTML = state.paymentMotifs.map(motif => `
    <div class="motif-row">
      <input type="text" value="${escapeHtml(motif.label)}" data-motif-label="${escapeHtml(motif.key)}" required>
      <input type="number" min="0" step="500" value="${Number(motif.amount || 0)}" data-motif-amount="${escapeHtml(motif.key)}">
      <button class="chip-button danger" type="button" data-action="delete-motif" data-key="${escapeHtml(motif.key)}" ${motif.key === "scolarite" ? "disabled" : ""}>Supprimer</button>
    </div>
  `).join("");

  ids.courseFeesSettings.innerHTML = state.courses.map(course => `
    <div class="fee-row">
      <div>
        <strong>${escapeHtml(course.name)}</strong>
        <span>${escapeHtml(course.code || "")}</span>
      </div>
      <label>
        <span>Inscription</span>
        <input type="number" min="0" step="1" value="${Number(course.registrationFee || 0)}" data-course-registration-fee="${course.id}">
      </label>
      <label>
        <span>Formation</span>
        <input type="number" min="0" step="1" value="${Number(course.trainingFee || 0)}" data-course-training-fee="${course.id}">
      </label>
      <label>
        <span>Mensualité</span>
        <input type="number" min="0" step="1" value="${Number(course.monthlyFee || 0)}" data-course-monthly-fee="${course.id}">
      </label>
    </div>
  `).join("") || `<p class="muted">Aucune formation enregistrée.</p>`;

  renderDocumentTemplates();
  renderRequiredDocumentsSettings();
}

function renderRequiredDocumentsSettings() {
  if (!ids.requiredDocumentsSettings) return;
  const labels = [
    ["student", "Étudiants"],
    ["trainer", "Formateurs"],
    ["staff", "Personnel"]
  ];
  const required = normalizeRequiredDocuments(state.requiredDocuments);
  ids.requiredDocumentsSettings.innerHTML = labels.map(([kind, label]) => `
    <label>
      <span>${escapeHtml(label)}</span>
      <textarea rows="3" data-required-documents="${kind}" placeholder="Un document par ligne">${escapeHtml(required[kind].join("\n"))}</textarea>
    </label>
  `).join("");
}

function renderAuditLog() {
  if (!ids.auditLogTable || !ids.auditLogCount) return;
  if (!isAdmin()) {
    ids.auditLogTable.innerHTML = "";
    ids.auditLogCount.textContent = "0 action(s)";
    return;
  }
  const rows = [...(state.auditLog || [])]
    .sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")))
    .slice(0, 120);
  ids.auditLogCount.textContent = `${rows.length} action(s)`;
  ids.auditLogTable.innerHTML = rows.map(entry => `
    <tr>
      <td>${escapeHtml(formatDateTime(new Date(entry.at || Date.now())))}</td>
      <td>${escapeHtml(entry.section || "-")}</td>
      <td>${escapeHtml(entry.action || "-")}</td>
      <td>${escapeHtml(entry.detail || "-")}</td>
      <td>${escapeHtml(entry.operator || entry.operatorEmail || "-")}</td>
    </tr>
  `).join("") || emptyRow(5, "Aucune action enregistrée.");
}

function renderLoginHistory() {
  if (!ids.loginHistoryTable || !ids.loginHistoryCount) return;
  if (!isAdmin()) {
    ids.loginHistoryTable.innerHTML = "";
    ids.loginHistoryCount.textContent = "0 action(s)";
    return;
  }

  const rows = [...(state.loginHistory || [])]
    .sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")))
    .slice(0, 80);
  ids.loginHistoryCount.textContent = `${rows.length} action(s)`;
  ids.loginHistoryTable.innerHTML = rows.map(entry => `
    <tr>
      <td>${escapeHtml(formatDateTime(new Date(entry.at || Date.now())))}</td>
      <td>${escapeHtml(entry.identifier || entry.email || "-")}</td>
      <td>${escapeHtml(entry.userName || "-")}</td>
      <td><span class="status ${entry.success ? "active" : "inactive"}">${entry.success ? "Réussie" : "Refusée"}</span></td>
      <td>${escapeHtml(entry.ip || "-")}</td>
    </tr>
  `).join("") || emptyRow(5, "Aucune connexion enregistrée.");
}

function renderUserAccessSettings() {
  if (!ids.userAccessSettings) return;
  if (!isAdmin()) {
    ids.userAccessSettings.innerHTML = "";
    if (ids.passwordResetRequests) ids.passwordResetRequests.innerHTML = "";
    return;
  }

  renderPasswordResetRequests();
  const users = state.users.length ? state.users : [currentUser].filter(Boolean);
  ids.userAccessSettings.innerHTML = users.map(user => {
    const role = user.role || "Secrétaire";
    const isUserAdmin = role === "Administrateur";
    const permissions = isUserAdmin ? ACCESS_VIEWS : permissionsForUser(user);
    const disabled = isUserAdmin ? "disabled" : "";
    const visiblePassword = visibleUserPassword(user);
    return `
      <article class="access-card" data-user-access-row="${user.id || ""}">
        <div class="access-card-header">
          <strong>${escapeHtml(user.name || "Nouvel utilisateur")}</strong>
          ${isUserAdmin ? `<span class="status active">Accès total</span>` : `<button class="chip-button danger" type="button" data-action="delete-user-access" data-id="${user.id || ""}">Supprimer</button>`}
        </div>
        <div class="access-user-grid">
          <label>
            <span>Nom</span>
            <input type="text" value="${escapeHtml(user.name || "")}" data-user-name="${user.id || ""}" required>
          </label>
          <label>
            <span>Identifiant</span>
            <input type="text" value="${escapeHtml(user.username || "")}" data-user-username="${user.id || ""}" required>
          </label>
          <label>
            <span>Email</span>
            <input type="email" value="${escapeHtml(user.email || "")}" data-user-email="${user.id || ""}" required>
          </label>
          <label>
            <span>Profil</span>
            <select data-user-role="${user.id || ""}" ${isUserAdmin ? "disabled" : ""}>
              ${(isUserAdmin ? ["Administrateur"] : ROLE_OPTIONS.filter(option => option !== "Administrateur")).map(option => `<option value="${escapeHtml(option)}" ${option === role ? "selected" : ""}>${escapeHtml(option)}</option>`).join("")}
            </select>
          </label>
          <label>
            <span>Statut</span>
            <select data-user-status="${user.id || ""}" ${isUserAdmin ? "disabled" : ""}>
              <option value="active" ${(user.status || "active") === "active" ? "selected" : ""}>Actif</option>
              <option value="inactive" ${user.status === "inactive" ? "selected" : ""}>Inactif</option>
            </select>
          </label>
          <label>
            <span>Nouveau mot de passe</span>
            <input type="password" data-user-password="${user.id || ""}" placeholder="${user.id ? "Laisser vide pour garder" : "Obligatoire"}">
          </label>
          <label>
            <span>Mot de passe enregistré</span>
            <input type="text" readonly value="${escapeHtml(visiblePassword || "Non disponible")}">
          </label>
          <label class="password-toggle-line">
            <input type="checkbox" data-toggle-password="${user.id || ""}">
            <span>Afficher</span>
          </label>
        </div>
        <div class="access-checks">
          ${MANAGED_ACCESS_VIEWS.map(view => `
            <label>
              <input type="checkbox" value="${escapeHtml(view)}" data-user-permission="${user.id || ""}" ${permissions.includes(view) ? "checked" : ""} ${disabled}>
              <span>${escapeHtml(VIEW_LABELS[view])}</span>
            </label>
          `).join("")}
        </div>
      </article>
    `;
  }).join("");
}

function visibleUserPassword(user = {}) {
  return user.visiblePassword || user.password || "";
}

function normalizeUsername(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function renderPasswordResetRequests() {
  if (!ids.passwordResetRequests) return;
  const pending = (state.passwordResetRequests || [])
    .filter(request => request.status !== "done")
    .sort((a, b) => String(b.requestedAt || "").localeCompare(String(a.requestedAt || "")));

  if (!pending.length) {
    ids.passwordResetRequests.innerHTML = `<p class="muted password-reset-empty">Aucune demande de réinitialisation en attente.</p>`;
    return;
  }

  ids.passwordResetRequests.innerHTML = `
    <div class="password-reset-list">
      <h4>Demandes de réinitialisation</h4>
      ${pending.map(request => {
        const user = state.users.find(item => item.email === request.email);
        return `
          <article class="password-reset-request">
            <div>
              <strong>${escapeHtml(user?.name || request.email)}</strong>
              <span>${escapeHtml(request.email)} · ${formatDateTime(new Date(request.requestedAt || Date.now()))}</span>
            </div>
            <button class="chip-button success" type="button" data-action="mark-password-reset-done" data-id="${request.id}">Marquer traité</button>
          </article>
        `;
      }).join("")}
    </div>
  `;
}

function balances() {
  return state.enrollments
    .map(enrollment => {
      const student = getStudent(enrollment.studentId);
      const course = getCourse(enrollment.courseId);
      const paid = paidAmount(enrollment.id);
      const balance = balanceForEnrollment(enrollment);
      return {
        enrollment,
        student: fullName(student),
        course: course?.name || "-",
        sessionType: groupSessionLabel(getGroup(enrollment.groupId)),
        finalAmount: Number(enrollment.finalAmount || 0),
        paid,
        balance
      };
    })
    .filter(item => item.balance > 0)
    .sort((a, b) => b.balance - a.balance);
}

function requiredAnnexMotifs() {
  ensurePaymentMotifs();
  return state.paymentMotifs.filter(motif => !isTuitionMotifKey(motif.key) && Number(motif.amount || 0) > 0);
}

function paymentAlerts() {
  const alerts = [];
  const annexMotifs = requiredAnnexMotifs();

  state.enrollments
    .filter(enrollment => !["annulee", "terminee"].includes(enrollment.status))
    .forEach(enrollment => {
      const student = getStudent(enrollment.studentId);
      const course = getCourse(enrollment.courseId);
      const group = getGroup(enrollment.groupId);
      const studentLabel = fullName(student);
      const courseLabel = course?.name || "-";
      const lastTuitionDate = lastPaymentDateForEnrollment(enrollment.id, isTuitionPayment);
      const tuitionBalance = balanceForEnrollment(enrollment);

      if (tuitionBalance > 0) {
        const days = daysSince(lastTuitionDate || enrollment.date);
        const noTuitionPayment = !lastTuitionDate;
        const severity = noTuitionPayment || days >= 30 ? "danger" : days >= 20 ? "warning" : "info";
        alerts.push({
          enrollmentId: enrollment.id,
          reasonKey: "scolarite",
          severity,
          priority: severity === "danger" ? 1 : severity === "warning" ? 2 : 3,
          student: studentLabel,
          detail: courseLabel,
          message: noTuitionPayment ? "Premier paiement scolarité attendu" : days >= 30 ? "Scolarité en retard" : days >= 20 ? "Relance scolarité proche" : "Reste scolarité à suivre",
          amount: tuitionBalance,
          lastPaymentDate: lastTuitionDate,
          referenceDate: lastTuitionDate || enrollment.date,
          sessionType: groupSessionLabel(group)
        });
      }

      annexMotifs.forEach(motif => {
        const paid = paymentsForEnrollment(enrollment.id)
          .some(payment => String(payment.reasonKey || "") === motif.key);
        if (paid) return;
        const days = daysSince(enrollment.date);
        alerts.push({
          enrollmentId: enrollment.id,
          reasonKey: motif.key,
          severity: days >= 30 ? "warning" : "info",
          priority: days >= 30 ? 2 : 4,
          student: studentLabel,
          detail: courseLabel,
          message: `Frais annexe non payé : ${motif.label}`,
          amount: Number(motif.amount || 0),
          lastPaymentDate: "",
          referenceDate: enrollment.date,
          sessionType: groupSessionLabel(group)
        });
      });
    });

  return alerts.sort((a, b) =>
    a.priority - b.priority ||
    b.amount - a.amount ||
    String(a.referenceDate).localeCompare(String(b.referenceDate))
  );
}

function emptyRow(colspan, label) {
  return `<tr><td colspan="${colspan}" class="muted">${label}</td></tr>`;
}

function syncSelects() {
  fillSelect("groupCourse", state.courses, course => course.name);
  fillSelectWithAll("groupCourseFilter", state.courses, course => course.name, "Toutes formations");
  fillSelectWithAll("enrollmentCourseFilter", state.courses, course => course.name, "Toutes formations");
  fillSelect("enrollmentStudent", state.students, student => `${fullName(student)} - ${student.matricule}`);
  fillSelect("enrollmentCourse", state.courses, course => course.name);
  syncEnrollmentGroups();
  fillSelect("paymentEnrollment", state.enrollments, enrollmentLabel);
  syncPaymentReasons();
  fillSelect("attendanceGroup", state.groups, group => group.name);
  fillSelect("evaluationGroup", state.groups, group => group.name);
  fillSelect("evaluationTrainer", state.trainers, trainer => trainerName(trainer));
  const payrollOptions = [
    ...state.staffMembers
      .filter(member => member.status !== "archive")
      .map(member => ({ id: payrollBeneficiaryValue("staff", member.id), label: `${staffName(member)} - ${member.role || "Personnel"}` })),
    ...state.trainers
      .filter(trainer => trainer.status !== "archive")
      .map(trainer => ({ id: payrollBeneficiaryValue("trainer", trainer.id), label: `${trainerName(trainer)} - Formateur` }))
  ];
  fillSelect("staffPaymentStaff", payrollOptions, option => option.label);
  fillSelect("individualReportStudent", state.students, student => `${fullName(student)} - ${student.matricule}`);
  fillSelect("documentGeneratorStudent", state.students, student => `${fullName(student)} - ${student.matricule}`);
  fillSelect("documentGeneratorTemplate", activeDocumentTemplates(), template => `${template.title} - ${template.category}`);
  fillSelect("documentGeneratorBeneficiary", payrollOptions, option => option.label);

  document.getElementById("enrollmentDate").value ||= today();
  document.getElementById("paymentDate").value ||= today();
  document.getElementById("cashDate").value ||= today();
  document.getElementById("attendanceDate").value ||= today();
  document.getElementById("trainerAttendanceDate").value ||= today();
  document.getElementById("staffPaymentDate").value ||= today();
  document.getElementById("staffPaymentPeriod").value ||= today().slice(0, 7);
  document.getElementById("evaluationDate").value ||= today();
}

function fillSelect(id, items, labeler) {
  const select = document.getElementById(id);
  if (!select) return;
  const oldValue = select.value;
  select.innerHTML = items.map(item => `<option value="${item.id}">${escapeHtml(labeler(item))}</option>`).join("");
  if (items.some(item => String(item.id) === oldValue)) {
    select.value = oldValue;
  }
}

function fillSelectWithAll(id, items, labeler, allLabel) {
  const select = document.getElementById(id);
  if (!select) return;
  const oldValue = select.value;
  select.innerHTML = `<option value="">${escapeHtml(allLabel)}</option>` +
    items.map(item => `<option value="${item.id}">${escapeHtml(labeler(item))}</option>`).join("");
  if ([...select.options].some(option => option.value === oldValue)) {
    select.value = oldValue;
  }
}

function syncPaymentReasons() {
  ensurePaymentMotifs();
  const select = document.getElementById("paymentReason");
  const oldValue = select.value;
  select.innerHTML = state.paymentMotifs
    .map(motif => `<option value="${escapeHtml(motif.key)}">${escapeHtml(motif.label)}</option>`)
    .join("");

  if ([...select.options].some(option => option.value === oldValue)) {
    select.value = oldValue;
  }
  updatePaymentReasonFields();
}

function syncEnrollmentGroups() {
  const courseId = Number(document.getElementById("enrollmentCourse").value || state.courses[0]?.id);
  const groups = state.groups.filter(group => Number(group.courseId) === courseId);
  fillSelect("enrollmentGroup", groups.length ? groups : state.groups, group => `${group.name} - ${groupSessionLabel(group)}`);
}

function updateEvaluationStudents(existingGrades = null) {
  const groupId = Number(document.getElementById("evaluationGroup").value);
  const grades = existingGrades || [];
  const gradeByStudent = new Map(grades.map(grade => [Number(grade.studentId), grade]));
  const students = studentsForGroup(groupId);

  ids.gradeEntryList.innerHTML = students.map(student => {
    const grade = gradeByStudent.get(Number(student.id)) || {};
    const needsMakeup = gradeNeedsMakeup(grade.score, Number(document.getElementById("evaluationMaxScore").value || 20));
    return `
      <div class="grade-entry-row">
        <div class="student-line">
          <strong>${escapeHtml(fullName(student))}</strong>
          <span>${escapeHtml(student.matricule)}</span>
          <span class="grade-rule ${needsMakeup ? "makeup" : ""}">${escapeHtml(gradeStatusLabel(grade.score, Number(document.getElementById("evaluationMaxScore").value || 20)))}${needsMakeup ? ` - ${formatMoney(MAKEUP_FEE)}` : ""}</span>
        </div>
        <input type="number" min="0" step="0.25" placeholder="Note" value="${escapeHtml(grade.score ?? "")}" data-grade-student="${student.id}">
        <input type="text" placeholder="Appreciation" value="${escapeHtml(grade.appreciation || "")}" data-grade-appreciation="${student.id}">
      </div>
    `;
  }).join("") || `<p class="muted">Aucun étudiant inscrit dans cette promotion.</p>`;
}

function enrollmentLabel(enrollment) {
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const balance = balanceForEnrollment(enrollment);
  return `${fullName(student)} - ${course?.name || "-"} - reste scolarité ${formatMoney(balance)}`;
}

function attendanceStatusLabel(status) {
  if (status === "present") return "Présent";
  if (status === "absent") return "Absent";
  if (status === "retard") return "Retard";
  return status || "-";
}

function showLoginChoice() {
  ids.loginChoiceView.hidden = false;
  document.getElementById("loginForm").hidden = true;
  document.getElementById("studentPortalLoginForm").hidden = true;
  ids.loginError.textContent = "";
  ids.studentPortalLoginError.textContent = "";
  hidePasswordResetBox();
}

function showLoginFormPanel(type) {
  ids.loginChoiceView.hidden = true;
  document.getElementById("loginForm").hidden = type !== "personnel";
  document.getElementById("studentPortalLoginForm").hidden = type !== "student";
  ids.loginError.textContent = "";
  ids.studentPortalLoginError.textContent = "";
  hidePasswordResetBox();
  const focusTarget = type === "student" ? "studentPortalMatricule" : "loginEmail";
  window.setTimeout(() => document.getElementById(focusTarget)?.focus(), 60);
}

function showPasswordResetBox() {
  ids.loginError.textContent = "";
  ids.passwordResetMessage.textContent = "";
  const loginValue = document.getElementById("loginEmail").value.trim();
  ids.passwordResetEmail.value = loginValue.includes("@") ? loginValue : "";
  ids.passwordResetBox.hidden = false;
  window.setTimeout(() => ids.passwordResetEmail.focus(), 60);
}

function hidePasswordResetBox() {
  if (!ids.passwordResetBox) return;
  ids.passwordResetBox.hidden = true;
  ids.passwordResetMessage.textContent = "";
}

async function requestPasswordReset() {
  const email = ids.passwordResetEmail.value.trim().toLowerCase();
  ids.passwordResetMessage.textContent = "";
  if (!email) {
    ids.passwordResetMessage.textContent = "Saisissez l'email du compte.";
    return;
  }

  try {
    const result = await apiRequest("/api/password-reset-request", {
      method: "POST",
      body: JSON.stringify({ email })
    });
    ids.passwordResetMessage.textContent = result.message || "Demande envoyée à l'administrateur.";
  } catch (error) {
    ids.passwordResetMessage.textContent = error.message;
  }
}

function showStudentPortal(data) {
  studentPortalData = data;
  currentUser = null;
  stopServerSync();
  if (ids.studentPortal) ids.studentPortal.hidden = false;
  document.body.classList.remove("loading", "needs-login");
  document.body.classList.add("student-portal-mode");
  renderStudentPortal(data);
}

function showLoginScreen() {
  studentPortalData = null;
  stopServerSync();
  if (ids.studentPortal) ids.studentPortal.hidden = true;
  showLoginChoice();
  document.body.classList.remove("loading", "student-portal-mode");
  document.body.classList.add("needs-login");
}

function renderStudentPortal(data = studentPortalData) {
  if (!data || !ids.studentPortal) return;
  const student = data.student || {};
  const enrollments = data.enrollments || [];
  const payments = data.payments || [];
  const grades = data.grades || [];
  const attendance = data.attendance || [];
  const tuitionPaid = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.tuitionPaid || 0), 0);
  const annexPaid = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.annexPaid || 0), 0);
  const balance = enrollments.reduce((sum, enrollment) => sum + Number(enrollment.balance || 0), 0);
  const numericGrades = grades
    .map(row => Number(row.score) * 20 / Number(row.maxScore || 20))
    .filter(score => Number.isFinite(score));
  const average = numericGrades.length
    ? `${(numericGrades.reduce((sum, score) => sum + score, 0) / numericGrades.length).toFixed(2)} / 20`
    : "-";
  const makeupGrades = grades.filter(row => row.needsMakeup);
  const makeupTotal = makeupGrades.length * MAKEUP_FEE;

  ids.studentPortalName.textContent = student.fullName || fullName(student);
  ids.studentPortalMeta.textContent = `${student.matricule || "-"} · ${student.status || "statut non précisé"}`;
  ids.studentPortalSummary.innerHTML = [
    ["Scolarité payée", formatMoney(tuitionPaid)],
    ["Frais annexes payés", formatMoney(annexPaid)],
    ["Reste scolarité", formatMoney(balance)],
    ["Moyenne notes", average],
    ["Matières non validées", String(makeupGrades.length)],
    ["Rattrapage à prévoir", formatMoney(makeupTotal)]
  ].map(([label, value]) => `
    <article class="stat-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </article>
  `).join("");

  ids.studentPortalInfo.innerHTML = [
    ["Matricule", student.matricule || "-"],
    ["Téléphone", student.phone || "-"],
    ["Email", student.email || "-"],
    ["Adresse", student.address || "-"],
    ["Date de naissance", formatDate(student.birthDate)]
  ].map(([label, value]) => `
    <div class="detail-row">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </div>
  `).join("");

  ids.studentPortalEnrollments.innerHTML = enrollments.map(enrollment => `
    <tr>
      <td>
        <strong>${escapeHtml(enrollment.courseName || "-")}</strong><br>
        <span class="muted">${escapeHtml(enrollment.groupName || enrollment.courseCode || "-")}</span>
      </td>
      <td>${escapeHtml(enrollment.sessionType || "-")}</td>
      <td>${formatMoney(enrollment.finalAmount)}</td>
      <td>${formatMoney(enrollment.tuitionPaid)}</td>
      <td><strong>${formatMoney(enrollment.balance)}</strong></td>
    </tr>
  `).join("") || `<tr><td colspan="5">Aucune inscription enregistrée.</td></tr>`;

  ids.studentPortalPayments.innerHTML = payments.map(payment => `
    <tr>
      <td>${formatDate(payment.date)}</td>
      <td>${escapeHtml(payment.receiptNumber || "-")}</td>
      <td>
        ${escapeHtml(payment.reason || "-")}<br>
        <span class="muted">${escapeHtml(payment.category || "")}</span>
      </td>
      <td><strong>${formatMoney(payment.amount)}</strong></td>
      <td>${escapeHtml(payment.method || "-")}</td>
    </tr>
  `).join("") || `<tr><td colspan="5">Aucun paiement enregistré.</td></tr>`;

  const makeupNotice = makeupGrades.length
    ? `<tr class="student-makeup-notice"><td colspan="5">
        <strong>${makeupGrades.length} matière(s) non validée(s).</strong>
        Rattrapage à faire : ${formatMoney(makeupTotal)} au total (${formatMoney(MAKEUP_FEE)} par matière).
      </td></tr>`
    : "";
  ids.studentPortalGrades.innerHTML = grades.map(row => `
    <tr>
      <td>${formatDate(row.date)}</td>
      <td>${escapeHtml(row.title || "-")}</td>
      <td>${escapeHtml(row.groupName || "-")}</td>
      <td>
        <strong>${row.score === "" ? "-" : `${escapeHtml(row.score)} / ${escapeHtml(row.maxScore || 20)}`}</strong><br>
        <span class="grade-rule ${row.needsMakeup ? "makeup" : ""}">${row.needsMakeup ? "Matière non validée" : escapeHtml(row.status || gradeStatusLabel(row.score, row.maxScore || 20))}</span>
      </td>
      <td>
        ${escapeHtml(row.needsMakeup ? "Non validé" : (row.appreciation || ""))}
        ${row.needsMakeup ? `<div class="muted">Rattrapage requis : ${formatMoney(MAKEUP_FEE)} pour cette matière.</div>` : ""}
      </td>
    </tr>
  `).join("") + makeupNotice || `<tr><td colspan="5">Aucune note enregistrée.</td></tr>`;

  ids.studentPortalAttendance.innerHTML = attendance.map(row => `
    <tr>
      <td>${formatDate(row.date)}</td>
      <td>${escapeHtml(row.groupName || "-")}</td>
      <td>${escapeHtml(row.topic || "-")}</td>
      <td><span class="status">${escapeHtml(attendanceStatusLabel(row.status))}</span></td>
    </tr>
  `).join("") || `<tr><td colspan="4">Aucune présence enregistrée.</td></tr>`;
}

async function loginStudentPortal(event) {
  event.preventDefault();
  ids.studentPortalLoginError.textContent = "";
  const submitButton = event.currentTarget.querySelector("button[type='submit']");
  submitButton.disabled = true;

  try {
    if (!SERVER_MODE) {
      throw new Error("L'espace étudiant doit être ouvert avec le serveur local.");
    }
    const data = await apiRequest("/api/student-portal", {
      method: "POST",
      body: JSON.stringify({
        matricule: document.getElementById("studentPortalMatricule").value,
        phone: document.getElementById("studentPortalPhone").value
      })
    });
    showStudentPortal(data);
  } catch (error) {
    ids.studentPortalLoginError.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
}

function logoutStudentPortal() {
  document.getElementById("studentPortalMatricule").value = "";
  document.getElementById("studentPortalPhone").value = "";
  showLoginScreen();
}

async function bootstrap() {
  wireEvents();
  resetStudentForm();
  resetGroupForm();
  resetEnrollmentForm();
  resetTrainerForm();
  resetStaffForm();
  resetEvaluationForm();

  if (!SERVER_MODE) {
    document.body.classList.remove("loading", "needs-login");
    render();
    return;
  }

  try {
    const session = await apiRequest("/api/me");
    currentUser = session.user;
    if (!currentUser) {
      await loadPublicCenterIdentity();
      showLoginScreen();
      return;
    }
    await loadServerState();
    startServerSync();
    if (ids.studentPortal) ids.studentPortal.hidden = true;
    document.body.classList.remove("loading", "needs-login", "student-portal-mode");
    render();
  } catch {
    showLoginScreen();
    ids.loginError.textContent = "Serveur indisponible";
  }
}

async function login(event) {
  event.preventDefault();
  ids.loginError.textContent = "";
  const submitButton = event.currentTarget.querySelector("button[type='submit']");
  submitButton.disabled = true;

  try {
    const result = await apiRequest("/api/login", {
      method: "POST",
      body: JSON.stringify({
        identifier: document.getElementById("loginEmail").value,
        email: document.getElementById("loginEmail").value,
        password: document.getElementById("loginPassword").value
      })
    });
    currentUser = result.user;
    await loadServerState();
    startServerSync();
    if (ids.studentPortal) ids.studentPortal.hidden = true;
    document.body.classList.remove("loading", "needs-login", "student-portal-mode");
    render();
    showToast("Connexion réussie");
  } catch (error) {
    ids.loginError.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
}

async function logout() {
  if (SERVER_MODE) {
    stopServerSync();
    await apiRequest("/api/logout", { method: "POST" }).catch(() => {});
    currentUser = null;
    showLoginScreen();
    renderSession();
  }
}

function wireEvents() {
  document.getElementById("loginForm").addEventListener("submit", login);
  document.getElementById("studentPortalLoginForm").addEventListener("submit", loginStudentPortal);
  document.getElementById("forgotPasswordButton").addEventListener("click", showPasswordResetBox);
  document.getElementById("cancelPasswordReset").addEventListener("click", hidePasswordResetBox);
  document.getElementById("sendPasswordReset").addEventListener("click", requestPasswordReset);
  document.addEventListener("change", event => {
    const toggle = event.target.closest("[data-toggle-password]");
    if (!toggle) return;
    const input = document.querySelector(`[data-user-password="${CSS.escape(toggle.dataset.togglePassword)}"]`);
    if (input) input.type = toggle.checked ? "text" : "password";
  });
  document.querySelectorAll("[data-login-choice]").forEach(button => {
    button.addEventListener("click", () => showLoginFormPanel(button.dataset.loginChoice));
  });
  document.querySelectorAll("[data-login-back]").forEach(button => {
    button.addEventListener("click", showLoginChoice);
  });
  document.getElementById("studentPortalLogout").addEventListener("click", logoutStudentPortal);
  document.getElementById("logoutButton").addEventListener("click", logout);

  document.querySelectorAll("[data-view-target]").forEach(button => {
    button.addEventListener("click", () => setView(button.dataset.viewTarget));
  });

  document.getElementById("backupButton").addEventListener("click", () => {
    saveState({ immediate: true, notify: true });
  });

  document.getElementById("studentSearch").addEventListener("input", () => renderAndPaginate(renderStudents, ["studentsTable"]));
  document.getElementById("studentStatusFilter").addEventListener("change", () => renderAndPaginate(renderStudents, ["studentsTable"]));
  ["courseSearch", "courseStatusFilter"].forEach(id => document.getElementById(id)?.addEventListener("input", () => renderAndPaginate(renderCourses, ["coursesTable"])));
  ["groupCourseFilter", "groupSessionFilter", "groupStatusFilter"].forEach(id => document.getElementById(id)?.addEventListener("change", () => renderAndPaginate(renderGroups, ["groupsTable"])));
  ["enrollmentSearch", "enrollmentCourseFilter", "enrollmentStatusFilter", "enrollmentBalanceFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "enrollmentSearch" ? "input" : "change", () => renderAndPaginate(renderEnrollments, ["enrollmentsTable"]));
  });
  ["paymentSearch", "paymentCategoryFilter", "paymentMethodFilter", "paymentMonthFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "paymentSearch" ? "input" : "change", () => renderAndPaginate(renderPayments, ["paymentsTable"]));
  });
  ["trainerSearch", "trainerStatusFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "trainerSearch" ? "input" : "change", () => renderAndPaginate(renderTrainers, ["trainersTable"]));
  });
  ["staffSearch", "staffStatusFilter"].forEach(id => {
    const element = document.getElementById(id);
    element?.addEventListener(id === "staffSearch" ? "input" : "change", () => renderAndPaginate(renderStaff, ["staffTable", "staffPaymentsTable"]));
  });

  document.getElementById("studentForm").addEventListener("submit", saveStudent);
  document.getElementById("courseForm").addEventListener("submit", saveCourse);
  document.getElementById("groupForm").addEventListener("submit", saveGroup);
  document.getElementById("enrollmentForm").addEventListener("submit", saveEnrollment);
  document.getElementById("paymentForm").addEventListener("submit", savePayment);
  document.getElementById("cashForm").addEventListener("submit", saveCashEntry);
  document.getElementById("attendanceForm").addEventListener("submit", saveAttendance);
  document.getElementById("trainerAttendanceForm").addEventListener("submit", saveTrainerAttendance);
  document.getElementById("trainerForm").addEventListener("submit", saveTrainer);
  document.getElementById("staffForm").addEventListener("submit", saveStaff);
  document.getElementById("staffPaymentForm").addEventListener("submit", saveStaffPayment);
  document.getElementById("evaluationForm").addEventListener("submit", saveEvaluation);
  document.getElementById("centerForm").addEventListener("submit", saveCenter);
  document.getElementById("motifSettingsForm").addEventListener("submit", savePaymentMotifs);
  document.getElementById("courseFeesSettingsForm").addEventListener("submit", saveCourseFeesSettings);
  document.getElementById("documentTemplateForm").addEventListener("submit", saveDocumentTemplate);
  document.getElementById("requiredDocumentsForm").addEventListener("submit", saveRequiredDocumentsSettings);
  document.getElementById("userAccessForm").addEventListener("submit", saveUserAccessSettings);

  document.getElementById("studentCancelEdit").addEventListener("click", resetStudentForm);
  document.getElementById("courseCancelEdit").addEventListener("click", resetCourseForm);
  document.getElementById("groupCancelEdit").addEventListener("click", resetGroupForm);
  document.getElementById("enrollmentCancelEdit").addEventListener("click", resetEnrollmentForm);
  document.getElementById("paymentCancelEdit").addEventListener("click", resetPaymentForm);
  document.getElementById("trainerCancelEdit").addEventListener("click", resetTrainerForm);
  document.getElementById("staffCancelEdit").addEventListener("click", resetStaffForm);
  document.getElementById("evaluationCancelEdit").addEventListener("click", resetEvaluationForm);

  ["student", "trainer", "staff"].forEach(kind => {
    document.getElementById(`${kind}PhotoInput`)?.addEventListener("change", () => importPersonPhoto(kind));
    document.getElementById(`${kind}RemovePhoto`)?.addEventListener("click", () => removePersonPhoto(kind));
    document.getElementById(`${kind}AddDocument`)?.addEventListener("click", () => addPersonDocument(kind));
  });

  document.getElementById("enrollmentCourse").addEventListener("change", () => {
    syncEnrollmentGroups();
    applyCourseCostToEnrollment();
  });
  document.getElementById("enrollmentDiscount").addEventListener("input", updateEnrollmentFinal);
  document.getElementById("enrollmentTotal").addEventListener("input", updateEnrollmentFinal);
  document.getElementById("paymentEnrollment").addEventListener("change", () => {
    updatePaymentBalance();
    updatePaymentReasonFields();
  });
  document.getElementById("paymentReason").addEventListener("change", updatePaymentReasonFields);
  document.getElementById("attendanceGroup").addEventListener("change", () => renderAndPaginate(renderAttendance, ["attendanceTable"]));
  document.getElementById("evaluationGroup").addEventListener("change", () => updateEvaluationStudents());
  document.getElementById("evaluationMaxScore").addEventListener("input", () => updateEvaluationStudents());
  document.getElementById("documentGeneratorTemplate").addEventListener("change", renderDocumentGenerator);
  document.getElementById("individualReportStudent").addEventListener("change", renderIndividualReport);

  document.body.addEventListener("click", handleActionClick);
  document.body.addEventListener("click", handleTablePaginationClick);

  document.getElementById("exportPaymentsCsv").addEventListener("click", exportPaymentsCsv);
  document.getElementById("exportCashCsv").addEventListener("click", exportCashCsv);
  document.getElementById("exportStudentsCsv").addEventListener("click", exportStudentsCsv);
  document.getElementById("exportAllCsv").addEventListener("click", exportAllCsv);
  document.getElementById("printBalances").addEventListener("click", printBalancesReport);
  document.getElementById("printIndividualReport").addEventListener("click", printIndividualStudentReport);
  document.getElementById("printStudentTranscript").addEventListener("click", () => {
    printStudentTranscript(Number(ids.individualReportStudent.value));
  });
  document.getElementById("printCustomDocument").addEventListener("click", printSelectedDocumentTemplate);
  document.getElementById("addPaymentMotif").addEventListener("click", addPaymentMotif);
  document.getElementById("newDocumentTemplate").addEventListener("click", resetDocumentTemplateForm);
  document.getElementById("documentTemplateCancelEdit").addEventListener("click", resetDocumentTemplateForm);
  document.getElementById("addUserAccess").addEventListener("click", addUserAccess);
  document.getElementById("centerLogo").addEventListener("change", importCenterLogo);
  document.getElementById("removeCenterLogo").addEventListener("click", removeCenterLogo);
  document.getElementById("centerStamp").addEventListener("change", importCenterStamp);
  document.getElementById("removeCenterStamp").addEventListener("click", removeCenterStamp);
  document.getElementById("exportJson").addEventListener("click", exportJson);
  document.getElementById("importJson").addEventListener("change", importJson);
  document.getElementById("resetData").addEventListener("click", resetData);
}

function saveStudent(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const matricule = form.dataset.editId
    ? document.getElementById("studentMatricule").value.trim()
    : generateMatricule(yearFromDate());
  const payload = {
    matricule,
    firstName: document.getElementById("studentFirstName").value.trim(),
    lastName: document.getElementById("studentLastName").value.trim(),
    gender: document.getElementById("studentGender").value,
    birthDate: document.getElementById("studentBirthDate").value,
    phone: document.getElementById("studentPhone").value.trim(),
    email: document.getElementById("studentEmail").value.trim(),
    address: document.getElementById("studentAddress").value.trim(),
    emergencyName: document.getElementById("studentEmergencyName").value.trim(),
    emergencyPhone: document.getElementById("studentEmergencyPhone").value.trim(),
    status: document.getElementById("studentStatus").value,
    ...personFilesPayload("student")
  };

  if (form.dataset.editId) {
    const student = getStudent(form.dataset.editId);
    Object.assign(student, payload);
    showToast("Étudiant modifié");
  } else {
    state.students.push({ id: nextId(state.students), ...payload });
    showToast("Étudiant ajouté");
  }

  saveState();
  resetStudentForm();
  render();
}

function saveCourse(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    code: document.getElementById("courseCode").value.trim(),
    name: document.getElementById("courseName").value.trim(),
    duration: document.getElementById("courseDuration").value.trim(),
    registrationFee: Number(document.getElementById("courseRegistrationFee").value || 0),
    trainingFee: Number(document.getElementById("courseTrainingFee").value || 0),
    monthlyFee: Number(document.getElementById("courseMonthlyFee").value || 0),
    description: document.getElementById("courseDescription").value.trim(),
    status: document.getElementById("courseStatus").value
  };

  if (form.dataset.editId) {
    const course = getCourse(form.dataset.editId);
    Object.assign(course, payload);
    showToast("Formation modifiée");
  } else {
    state.courses.push({ id: nextId(state.courses), ...payload });
    showToast("Formation ajoutée");
  }

  saveState();
  resetCourseForm();
  render();
}

function saveGroup(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    name: document.getElementById("groupName").value.trim(),
    courseId: Number(document.getElementById("groupCourse").value),
    year: document.getElementById("groupYear").value.trim(),
    sessionType: document.getElementById("groupSessionType").value,
    trainer: document.getElementById("groupTrainer").value.trim(),
    capacity: Number(document.getElementById("groupCapacity").value || 0),
    startDate: document.getElementById("groupStartDate").value,
    endDate: document.getElementById("groupEndDate").value,
    status: document.getElementById("groupStatus").value
  };

  if (form.dataset.editId) {
    const group = getGroup(form.dataset.editId);
    Object.assign(group, payload);
    showToast("Promotion modifiée");
  } else {
    state.groups.push({ id: nextId(state.groups), ...payload });
    showToast("Promotion ajoutée");
  }

  saveState();
  resetGroupForm();
  render();
}

function saveEnrollment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    studentId: Number(document.getElementById("enrollmentStudent").value),
    courseId: Number(document.getElementById("enrollmentCourse").value),
    groupId: Number(document.getElementById("enrollmentGroup").value),
    date: document.getElementById("enrollmentDate").value,
    totalAmount: Number(document.getElementById("enrollmentTotal").value || 0),
    discountAmount: Number(document.getElementById("enrollmentDiscount").value || 0),
    finalAmount: Number(document.getElementById("enrollmentFinal").value || 0),
    status: document.getElementById("enrollmentStatus").value
  };

  if (form.dataset.editId) {
    const enrollment = getEnrollment(form.dataset.editId);
    Object.assign(enrollment, payload);
    showToast("Inscription modifiée");
  } else {
    const firstEnrollment = !state.enrollments.some(enrollment => Number(enrollment.studentId) === payload.studentId);
    const student = getStudent(payload.studentId);
    if (student && firstEnrollment) {
      student.matricule = generateMatricule(yearFromDate(payload.date));
    }
    state.enrollments.push({ id: nextId(state.enrollments), ...payload });
    showToast("Inscription enregistrée");
  }

  saveState();
  resetEnrollmentForm();
  render();
}

function controlledPaymentReason(actionLabel) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut corriger un paiement");
    return "";
  }
  const reason = prompt(`${actionLabel} : indiquez le motif du controle`);
  if (!reason || reason.trim().length < 4) {
    showToast("Motif de controle obligatoire");
    return "";
  }
  return reason.trim();
}

function paymentSnapshot(payment) {
  return JSON.parse(JSON.stringify(payment || {}));
}

function logPaymentControl(action, payment, controlReason, before = null, after = null) {
  state.paymentAuditLog.push({
    id: nextId(state.paymentAuditLog),
    date: new Date().toISOString(),
    action,
    paymentId: payment?.id || before?.id || after?.id || 0,
    receiptNumber: payment?.receiptNumber || before?.receiptNumber || after?.receiptNumber || "",
    operator: currentOperatorName(),
    controlReason,
    before,
    after
  });
}

function validatePaymentPayload(payload, editId = 0) {
  if (!payload.enrollmentId || payload.amount <= 0 || !payload.reason) {
    showToast("Paiement incomplet");
    return false;
  }
  if (isTuitionMotifKey(payload.reasonKey)) {
    const balance = editId
      ? balanceForEnrollmentExcluding(getEnrollment(payload.enrollmentId), editId)
      : balanceForEnrollment(getEnrollment(payload.enrollmentId));
    if (balance <= 0) {
      showToast("La scolarite est deja soldee");
      return false;
    }
    if (payload.amount > balance) {
      showToast("Le paiement depasse le reste de scolarite");
      return false;
    }
    return true;
  }

  const alreadyPaid = paymentsForEnrollment(payload.enrollmentId)
    .some(payment => Number(payment.id) !== Number(editId) && String(payment.reasonKey || "") === payload.reasonKey);
  if (alreadyPaid) {
    showToast("Ce frais annexe est deja paye pour cet etudiant");
    return false;
  }
  return true;
}

function savePayment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const editId = Number(form.dataset.editId || 0);
  const enrollmentId = Number(document.getElementById("paymentEnrollment").value);
  const reasonKey = document.getElementById("paymentReason").value;
  const reason = getPaymentMotif(reasonKey)?.label || reasonKey;
  const amount = Number(document.getElementById("paymentAmount").value || 0);
  const payload = {
    enrollmentId,
    amount,
    method: document.getElementById("paymentMethod").value,
    reason,
    reasonKey,
    date: document.getElementById("paymentDate").value,
    receivedBy: currentOperatorName()
  };

  if (!validatePaymentPayload(payload, editId)) return;

  if (editId) {
    const payment = findById(state.payments, editId);
    if (!payment) return;
    if (isTuitionPayment(payment) !== isTuitionMotifKey(payload.reasonKey)) {
      showToast("La categorie du recu ne peut pas etre changee");
      return;
    }
    const controlReason = controlledPaymentReason("Modification du paiement");
    if (!controlReason) return;
    const before = paymentSnapshot(payment);
    Object.assign(payment, payload, {
      correctedAt: new Date().toISOString(),
      correctedBy: currentOperatorName(),
      correctionReason: controlReason
    });
    logPaymentControl("Modification", payment, controlReason, before, paymentSnapshot(payment));
    showToast("Paiement modifie avec controle");
  } else {
    const payment = {
      id: nextId(state.payments),
      receiptNumber: nextReceiptNumber(reasonKey),
      ...payload
    };
    state.payments.push(payment);
    showToast("Paiement enregistre");
    printReceipt(payment.id);
  }

  saveState();
  resetPaymentForm();
  render();
}

function saveCashEntry(event) {
  event.preventDefault();
  const amount = Number(document.getElementById("cashAmount").value || 0);
  const category = document.getElementById("cashCategory").value.trim();

  if (amount <= 0 || !category) {
    showToast("Opération de caisse incomplète");
    return;
  }

  state.cashEntries.push({
    id: nextId(state.cashEntries),
    type: document.getElementById("cashType").value,
    date: document.getElementById("cashDate").value,
    category,
    amount,
    method: document.getElementById("cashMethod").value,
    description: document.getElementById("cashDescription").value.trim(),
    recordedBy: document.getElementById("roleSelect").value
  });

  saveState();
  event.currentTarget.reset();
  document.getElementById("cashDate").value = today();
  render();
  showToast("Opération enregistrée");
}

function saveAttendance(event) {
  event.preventDefault();
  const groupId = Number(document.getElementById("attendanceGroup").value);
  const records = [...document.querySelectorAll("[data-attendance-student]")].map(select => ({
    studentId: Number(select.dataset.attendanceStudent),
    status: select.value
  }));

  if (!groupId || !records.length) {
    showToast("Aucun étudiant pour l'appel");
    return;
  }

  const session = {
    id: nextId(state.attendanceSessions),
    groupId,
    date: document.getElementById("attendanceDate").value,
    topic: document.getElementById("attendanceTopic").value.trim(),
    records
  };

  state.attendanceSessions.push(session);
  saveState();
  document.getElementById("attendanceTopic").value = "";
  render();
  showToast("Appel enregistré");
}

function saveTrainerAttendance(event) {
  event.preventDefault();
  const records = [...document.querySelectorAll("[data-attendance-trainer]")].map(select => ({
    trainerId: Number(select.dataset.attendanceTrainer),
    status: select.value
  }));

  if (!records.length) {
    showToast("Aucun professeur pour l'appel");
    return;
  }

  state.trainerAttendanceSessions.push({
    id: nextId(state.trainerAttendanceSessions),
    date: document.getElementById("trainerAttendanceDate").value,
    topic: document.getElementById("trainerAttendanceTopic").value.trim(),
    records
  });

  saveState();
  document.getElementById("trainerAttendanceTopic").value = "";
  render();
  showToast("Appel des professeurs enregistré");
}

function saveTrainer(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    firstName: document.getElementById("trainerFirstName").value.trim(),
    lastName: document.getElementById("trainerLastName").value.trim(),
    phone: document.getElementById("trainerPhone").value.trim(),
    email: document.getElementById("trainerEmail").value.trim(),
    specialty: document.getElementById("trainerSpecialty").value.trim(),
    modules: document.getElementById("trainerModules").value.trim(),
    status: document.getElementById("trainerStatus").value,
    ...personFilesPayload("trainer")
  };

  if (form.dataset.editId) {
    const trainer = getTrainer(form.dataset.editId);
    Object.assign(trainer, payload);
    showToast("Formateur modifie");
  } else {
    state.trainers.push({ id: nextId(state.trainers), ...payload });
    showToast("Formateur ajoute");
  }

  saveState();
  resetTrainerForm();
  render();
}

function saveStaff(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    firstName: document.getElementById("staffFirstName").value.trim(),
    lastName: document.getElementById("staffLastName").value.trim(),
    role: document.getElementById("staffRole").value.trim(),
    salary: Number(document.getElementById("staffSalary").value || 0),
    phone: document.getElementById("staffPhone").value.trim(),
    email: document.getElementById("staffEmail").value.trim(),
    status: document.getElementById("staffStatus").value,
    ...personFilesPayload("staff")
  };

  if (!payload.firstName || !payload.lastName || !payload.role) {
    showToast("Fiche personnel incomplete");
    return;
  }

  if (form.dataset.editId) {
    const member = getStaffMember(form.dataset.editId);
    if (!member) return;
    Object.assign(member, payload);
    showToast("Personnel modifie");
  } else {
    state.staffMembers.push({ id: nextId(state.staffMembers), ...payload });
    showToast("Personnel ajoute");
  }

  saveState();
  resetStaffForm();
  render();
}

function saveStaffPayment(event) {
  event.preventDefault();
  const beneficiary = parsePayrollBeneficiary(document.getElementById("staffPaymentStaff").value);
  const amount = Number(document.getElementById("staffPaymentAmount").value || 0);

  if (!beneficiary.id || amount <= 0) {
    showToast("Paiement personnel incomplet");
    return;
  }

  state.staffPayments.push({
    id: nextId(state.staffPayments),
    staffId: beneficiary.type === "staff" ? beneficiary.id : 0,
    payeeType: beneficiary.type,
    payeeId: beneficiary.id,
    period: document.getElementById("staffPaymentPeriod").value,
    date: document.getElementById("staffPaymentDate").value || today(),
    reason: document.getElementById("staffPaymentReason").value,
    amount,
    method: document.getElementById("staffPaymentMethod").value,
    note: document.getElementById("staffPaymentNote").value.trim(),
    recordedBy: currentUser?.name || document.getElementById("roleSelect")?.value || "Administrateur"
  });

  saveState();
  event.currentTarget.reset();
  document.getElementById("staffPaymentDate").value = today();
  document.getElementById("staffPaymentPeriod").value = today().slice(0, 7);
  render();
  showToast("Paiement personnel enregistre");
}

function saveEvaluation(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const maxScore = Number(document.getElementById("evaluationMaxScore").value || 20);
  const grades = [...document.querySelectorAll("[data-grade-student]")].map(input => {
    const studentId = Number(input.dataset.gradeStudent);
    return {
      studentId,
      score: input.value === "" ? "" : Number(input.value),
      appreciation: document.querySelector(`[data-grade-appreciation="${studentId}"]`)?.value.trim() || ""
    };
  });

  const invalidGrade = grades.some(grade => grade.score !== "" && (Number(grade.score) < 0 || Number(grade.score) > maxScore));
  if (invalidGrade) {
    showToast("Une note depasse le bareme");
    return;
  }

  const payload = {
    groupId: Number(document.getElementById("evaluationGroup").value),
    trainerId: Number(document.getElementById("evaluationTrainer").value || 0),
    title: document.getElementById("evaluationTitle").value.trim(),
    type: document.getElementById("evaluationType").value,
    date: document.getElementById("evaluationDate").value,
    maxScore,
    grades
  };

  if (!payload.groupId || !payload.title) {
    showToast("Evaluation incomplete");
    return;
  }

  if (form.dataset.editId) {
    const evaluation = getEvaluation(form.dataset.editId);
    Object.assign(evaluation, payload);
    showToast("Evaluation modifiee");
  } else {
    state.evaluations.push({ id: nextId(state.evaluations), ...payload });
    showToast("Evaluation enregistree");
  }

  saveState();
  resetEvaluationForm();
  render();
}

function saveCenter(event) {
  event.preventDefault();
  state.center = {
    ...(state.center || {}),
    name: document.getElementById("centerName").value.trim() || "CFP EREXIT",
    subtitle: document.getElementById("centerSubtitle").value.trim() || "Centre de Formation Professionnelle",
    phone: document.getElementById("centerPhone").value.trim(),
    email: document.getElementById("centerEmail").value.trim(),
    address: document.getElementById("centerAddress").value.trim(),
    logoData: state.center?.logoData || "",
    stampData: state.center?.stampData || ""
  };
  saveState();
  renderCenterIdentity();
  showToast("Informations du centre enregistrées");
}

async function importCenterLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Format de logo invalide");
    event.target.value = "";
    return;
  }

  try {
    const logoData = file.type === "image/svg+xml"
      ? await svgToDataUrl(file)
      : await imageToPngDataUrl(file);
    state.center = {
      ...(state.center || {}),
      logoData
    };
    saveState();
    render();
    showToast("Logo enregistré");
  } catch {
    showToast("Logo illisible");
  } finally {
    event.target.value = "";
  }
}

function removeCenterLogo() {
  state.center = {
    ...(state.center || {}),
    logoData: ""
  };
  saveState();
  render();
  showToast("Logo retiré");
}

async function importCenterStamp(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showToast("Format de signature/cachet invalide");
    event.target.value = "";
    return;
  }

  try {
    const stampData = file.type === "image/svg+xml"
      ? await svgToDataUrl(file)
      : await imageToPngDataUrl(file, 420);
    state.center = {
      ...(state.center || {}),
      stampData
    };
    saveState();
    render();
    showToast("Signature/cachet enregistré");
  } catch {
    showToast("Signature/cachet illisible");
  } finally {
    event.target.value = "";
  }
}

function removeCenterStamp() {
  state.center = {
    ...(state.center || {}),
    stampData: ""
  };
  saveState();
  render();
  showToast("Signature/cachet retiré");
}

function savePaymentMotifs(event) {
  event.preventDefault();
  collectPaymentMotifInputs();
  saveState();
  syncPaymentReasons();
  render();
  showToast("Motifs enregistrés");
}

function saveCourseFeesSettings(event) {
  event.preventDefault();
  state.courses.forEach(course => {
    const registrationInput = document.querySelector(`[data-course-registration-fee="${course.id}"]`);
    const trainingInput = document.querySelector(`[data-course-training-fee="${course.id}"]`);
    const monthlyInput = document.querySelector(`[data-course-monthly-fee="${course.id}"]`);
    course.registrationFee = Number(registrationInput?.value || 0);
    course.trainingFee = Number(trainingInput?.value || 0);
    course.monthlyFee = Number(monthlyInput?.value || 0);
  });
  saveState();
  renderCourses();
  syncSelects();
  showToast("Frais des formations enregistrés");
}

function saveUserAccessSettings(event) {
  event.preventDefault();
  if (!isAdmin()) {
    showToast("Accès réservé à l'administrateur");
    return;
  }

  const users = [...document.querySelectorAll("[data-user-access-row]")].map(row => {
    const idText = row.dataset.userAccessRow;
    const id = Number(idText);
    const existing = state.users.find(user => Number(user.id) === id) || {};
    const roleInput = row.querySelector(`[data-user-role="${CSS.escape(idText)}"]`);
    const role = existing.role === "Administrateur" ? "Administrateur" : (roleInput?.value || "Secrétaire");
    const permissions = role === "Administrateur"
      ? [...ACCESS_VIEWS]
      : [...row.querySelectorAll(`[data-user-permission="${CSS.escape(idText)}"]:checked`)].map(input => input.value);
    const password = row.querySelector(`[data-user-password="${CSS.escape(idText)}"]`)?.value.trim() || "";
    const isNewUser = !existing.email;
    return {
      id,
      name: row.querySelector(`[data-user-name="${CSS.escape(idText)}"]`)?.value.trim() || "Utilisateur",
      username: normalizeUsername(row.querySelector(`[data-user-username="${CSS.escape(idText)}"]`)?.value || existing.username || ""),
      email: row.querySelector(`[data-user-email="${CSS.escape(idText)}"]`)?.value.trim().toLowerCase() || existing.email || "",
      role,
      status: role === "Administrateur" ? "active" : (row.querySelector(`[data-user-status="${CSS.escape(idText)}"]`)?.value || "active"),
      permissions,
      visiblePassword: password || visibleUserPassword(existing),
      isNewUser,
      ...(password ? { password } : {})
    };
  });

  if (users.some(user => !user.email)) {
    showToast("Chaque utilisateur doit avoir un email");
    return;
  }
  if (users.some(user => !user.username)) {
    showToast("Chaque utilisateur doit avoir un identifiant");
    return;
  }
  if (users.some(user => user.isNewUser && !user.password)) {
    showToast("Mot de passe obligatoire pour un nouvel utilisateur");
    return;
  }
  const uniqueEmails = new Set(users.map(user => user.email));
  if (uniqueEmails.size !== users.length) {
    showToast("Deux utilisateurs ont le même email");
    return;
  }
  const uniqueUsernames = new Set(users.map(user => user.username));
  if (uniqueUsernames.size !== users.length) {
    showToast("Deux utilisateurs ont le même identifiant");
    return;
  }

  const changedPasswordEmails = users
    .filter(user => user.password)
    .map(user => user.email);
  state.users = users.map(({ isNewUser, ...user }) => user);
  if (changedPasswordEmails.length) {
    state.passwordResetRequests = (state.passwordResetRequests || []).map(request => (
      changedPasswordEmails.includes(request.email)
        ? { ...request, status: "done", resolvedAt: new Date().toISOString(), resolvedBy: currentOperatorName() }
        : request
    ));
  }
  saveState();
  renderSettings();
  showToast("Accès utilisateurs enregistrés");
}

function saveRequiredDocumentsSettings(event) {
  event.preventDefault();
  if (!isAdmin()) return;
  state.requiredDocuments = {
    student: linesFromTextarea("student"),
    trainer: linesFromTextarea("trainer"),
    staff: linesFromTextarea("staff")
  };
  saveState();
  render();
  showToast("Documents obligatoires enregistrés");
}

function linesFromTextarea(kind) {
  const value = document.querySelector(`[data-required-documents="${kind}"]`)?.value || "";
  return value
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);
}

function collectPaymentMotifInputs() {
  ensurePaymentMotifs();
  state.paymentMotifs.forEach(motif => {
    const labelInput = document.querySelector(`[data-motif-label="${CSS.escape(motif.key)}"]`);
    const amountInput = document.querySelector(`[data-motif-amount="${CSS.escape(motif.key)}"]`);
    motif.label = labelInput?.value.trim() || motif.label || "Motif";
    motif.amount = Number(amountInput?.value || 0);
  });
}

function addPaymentMotif() {
  collectPaymentMotifInputs();
  state.paymentMotifs.push({
    key: `motif-${Date.now()}`,
    label: "Nouveau motif",
    amount: 0
  });
  saveState();
  renderSettings();
  syncPaymentReasons();
  showToast("Motif ajouté");
}

function addUserAccess() {
  if (!isAdmin()) return;
  collectCurrentUserAccessDraft();
  state.users.push({
    id: nextId(state.users),
    name: "Nouvel utilisateur",
    username: "",
    email: "",
    role: "Secrétaire",
    status: "active",
    permissions: defaultPermissionsForRole("Secrétaire")
  });
  renderSettings();
}

function collectCurrentUserAccessDraft() {
  if (!ids.userAccessSettings) return;
  const rows = [...document.querySelectorAll("[data-user-access-row]")];
  if (!rows.length) return;
  state.users = rows.map(row => {
    const idText = row.dataset.userAccessRow;
    const id = Number(idText);
    const existing = state.users.find(user => Number(user.id) === id) || {};
    const roleInput = row.querySelector(`[data-user-role="${CSS.escape(idText)}"]`);
    const role = existing.role === "Administrateur" ? "Administrateur" : (roleInput?.value || existing.role || "Secrétaire");
    return {
      ...existing,
      id,
      name: row.querySelector(`[data-user-name="${CSS.escape(idText)}"]`)?.value.trim() || existing.name || "Utilisateur",
      username: normalizeUsername(row.querySelector(`[data-user-username="${CSS.escape(idText)}"]`)?.value || existing.username || ""),
      email: row.querySelector(`[data-user-email="${CSS.escape(idText)}"]`)?.value.trim().toLowerCase() || existing.email || "",
      role,
      status: role === "Administrateur" ? "active" : (row.querySelector(`[data-user-status="${CSS.escape(idText)}"]`)?.value || existing.status || "active"),
      permissions: role === "Administrateur"
        ? [...ACCESS_VIEWS]
        : [...row.querySelectorAll(`[data-user-permission="${CSS.escape(idText)}"]:checked`)].map(input => input.value)
    };
  });
}

function handleActionClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const id = Number(button.dataset.id);
  const action = button.dataset.action;

  if (action === "edit-student") editStudent(id);
  if (action === "delete-student") deleteStudent(id);
  if (action === "edit-course") editCourse(id);
  if (action === "delete-course") deleteCourse(id);
  if (action === "edit-group") editGroup(id);
  if (action === "delete-group") deleteGroup(id);
  if (action === "edit-enrollment") editEnrollment(id);
  if (action === "pay-enrollment") startPayment(id);
  if (action === "pay-alert") startPayment(id, button.dataset.reason);
  if (action === "print-enrollment") printEnrollment(id);
  if (action === "print-attestation") printAttestation(id);
  if (action === "print-contract") printTrainingContract(id);
  if (action === "print-receipt") printReceipt(id);
  if (action === "edit-payment") editPayment(id);
  if (action === "delete-payment") deletePayment(id);
  if (action === "delete-cash-entry") deleteCashEntry(id);
  if (action === "edit-trainer") editTrainer(id);
  if (action === "delete-trainer") deleteTrainer(id);
  if (action === "edit-staff") editStaff(id);
  if (action === "delete-staff") deleteStaff(id);
  if (action === "delete-staff-payment") deleteStaffPayment(id);
  if (action === "print-payroll-slip") printPayrollSlip(id);
  if (action === "edit-evaluation") editEvaluation(id);
  if (action === "delete-evaluation") deleteEvaluation(id);
  if (action === "print-grades") printGradesReport(id);
  if (action === "delete-motif") deletePaymentMotif(button.dataset.key);
  if (action === "delete-person-document") deletePersonDocument(button.dataset.kind, button.dataset.index);
  if (action === "edit-document-template") editDocumentTemplate(button.dataset.key);
  if (action === "delete-document-template") deleteDocumentTemplate(button.dataset.key);
  if (action === "delete-user-access") deleteUserAccess(id);
  if (action === "mark-password-reset-done") markPasswordResetDone(id);
}

function markPasswordResetDone(id) {
  state.passwordResetRequests = (state.passwordResetRequests || []).map(request => (
    Number(request.id) === Number(id)
      ? { ...request, status: "done", resolvedAt: new Date().toISOString(), resolvedBy: currentOperatorName() }
      : request
  ));
  saveState();
  renderUserAccessSettings();
  showToast("Demande marquée comme traitée");
}

function editStudent(id) {
  const student = getStudent(id);
  if (!student) return;
  const form = document.getElementById("studentForm");
  form.dataset.editId = id;
  document.getElementById("studentFormTitle").textContent = "Modifier étudiant";
  document.getElementById("studentMatricule").value = student.matricule || "";
  document.getElementById("studentFirstName").value = student.firstName || "";
  document.getElementById("studentLastName").value = student.lastName || "";
  document.getElementById("studentGender").value = student.gender || "";
  document.getElementById("studentBirthDate").value = student.birthDate || "";
  document.getElementById("studentPhone").value = student.phone || "";
  document.getElementById("studentEmail").value = student.email || "";
  document.getElementById("studentAddress").value = student.address || "";
  document.getElementById("studentEmergencyName").value = student.emergencyName || "";
  document.getElementById("studentEmergencyPhone").value = student.emergencyPhone || "";
  document.getElementById("studentStatus").value = student.status || "actif";
  resetPersonFileDraft("student", student);
  setView("students");
}

function editCourse(id) {
  const course = getCourse(id);
  if (!course) return;
  const form = document.getElementById("courseForm");
  form.dataset.editId = id;
  document.getElementById("courseFormTitle").textContent = "Modifier formation";
  document.getElementById("courseCode").value = course.code || "";
  document.getElementById("courseName").value = course.name || "";
  document.getElementById("courseDuration").value = course.duration || "";
  document.getElementById("courseRegistrationFee").value = course.registrationFee || 0;
  document.getElementById("courseTrainingFee").value = course.trainingFee || 0;
  document.getElementById("courseMonthlyFee").value = course.monthlyFee || 0;
  document.getElementById("courseDescription").value = course.description || "";
  document.getElementById("courseStatus").value = course.status || "active";
  setView("courses");
}

function editGroup(id) {
  const group = getGroup(id);
  if (!group) return;
  const form = document.getElementById("groupForm");
  form.dataset.editId = id;
  document.getElementById("groupFormTitle").textContent = "Modifier promotion";
  document.getElementById("groupName").value = group.name || "";
  document.getElementById("groupCourse").value = group.courseId;
  document.getElementById("groupYear").value = group.year || "";
  document.getElementById("groupSessionType").value = group.sessionType || "jour";
  document.getElementById("groupTrainer").value = group.trainer || "";
  document.getElementById("groupCapacity").value = group.capacity || "";
  document.getElementById("groupStartDate").value = group.startDate || "";
  document.getElementById("groupEndDate").value = group.endDate || "";
  document.getElementById("groupStatus").value = group.status || "active";
  setView("groups");
}

function editEnrollment(id) {
  const enrollment = getEnrollment(id);
  if (!enrollment) return;
  const form = document.getElementById("enrollmentForm");
  form.dataset.editId = id;
  document.getElementById("enrollmentFormTitle").textContent = "Modifier inscription";
  document.getElementById("enrollmentStudent").value = enrollment.studentId;
  document.getElementById("enrollmentCourse").value = enrollment.courseId;
  syncEnrollmentGroups();
  document.getElementById("enrollmentGroup").value = enrollment.groupId;
  document.getElementById("enrollmentDate").value = enrollment.date || today();
  document.getElementById("enrollmentTotal").value = enrollment.totalAmount || 0;
  document.getElementById("enrollmentDiscount").value = enrollment.discountAmount || 0;
  document.getElementById("enrollmentFinal").value = enrollment.finalAmount || 0;
  document.getElementById("enrollmentStatus").value = enrollment.status || "validee";
  setView("enrollments");
}

function editPayment(id) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut corriger un paiement");
    return;
  }
  const payment = findById(state.payments, id);
  if (!payment) return;
  const form = document.getElementById("paymentForm");
  form.dataset.editId = id;
  setView("payments");
  document.getElementById("paymentFormTitle").textContent = `Modifier ${payment.receiptNumber || "paiement"}`;
  document.getElementById("paymentSubmitButton").textContent = "Enregistrer la correction";
  document.getElementById("paymentCancelEdit").hidden = false;
  document.getElementById("paymentEnrollment").value = payment.enrollmentId;
  document.getElementById("paymentReason").value = payment.reasonKey || "scolarite";
  updatePaymentBalance();
  updatePaymentReasonFields();
  document.getElementById("paymentAmount").value = payment.amount || 0;
  document.getElementById("paymentMethod").value = payment.method || "Espèce";
  document.getElementById("paymentDate").value = payment.date || today();
  document.getElementById("paymentAmount").focus();
}

function editTrainer(id) {
  const trainer = getTrainer(id);
  if (!trainer) return;
  const form = document.getElementById("trainerForm");
  form.dataset.editId = id;
  document.getElementById("trainerFormTitle").textContent = "Modifier formateur";
  document.getElementById("trainerFirstName").value = trainer.firstName || "";
  document.getElementById("trainerLastName").value = trainer.lastName || "";
  document.getElementById("trainerPhone").value = trainer.phone || "";
  document.getElementById("trainerEmail").value = trainer.email || "";
  document.getElementById("trainerSpecialty").value = trainer.specialty || "";
  document.getElementById("trainerModules").value = trainer.modules || "";
  document.getElementById("trainerStatus").value = trainer.status || "actif";
  resetPersonFileDraft("trainer", trainer);
  setView("trainers");
}

function editStaff(id) {
  const member = getStaffMember(id);
  if (!member) return;
  const form = document.getElementById("staffForm");
  form.dataset.editId = id;
  document.getElementById("staffFormTitle").textContent = "Modifier personnel";
  document.getElementById("staffFirstName").value = member.firstName || "";
  document.getElementById("staffLastName").value = member.lastName || "";
  document.getElementById("staffRole").value = member.role || "";
  document.getElementById("staffSalary").value = member.salary || 0;
  document.getElementById("staffPhone").value = member.phone || "";
  document.getElementById("staffEmail").value = member.email || "";
  document.getElementById("staffStatus").value = member.status || "actif";
  resetPersonFileDraft("staff", member);
  setView("staff");
}

function editEvaluation(id) {
  const evaluation = getEvaluation(id);
  if (!evaluation) return;
  setView("grades");
  const form = document.getElementById("evaluationForm");
  form.dataset.editId = id;
  document.getElementById("evaluationFormTitle").textContent = "Modifier évaluation";
  document.getElementById("evaluationTitle").value = evaluation.title || "";
  document.getElementById("evaluationGroup").value = evaluation.groupId;
  document.getElementById("evaluationTrainer").value = evaluation.trainerId || "";
  document.getElementById("evaluationType").value = evaluation.type || "devoir";
  document.getElementById("evaluationDate").value = evaluation.date || today();
  document.getElementById("evaluationMaxScore").value = evaluation.maxScore || 20;
  updateEvaluationStudents(evaluation.grades || []);
}

function deleteStudent(id) {
  if (state.enrollments.some(enrollment => Number(enrollment.studentId) === id)) {
    showToast("Suppression bloquée : étudiant inscrit");
    return;
  }
  if (!confirm("Supprimer cet étudiant ?")) return;
  state.students = state.students.filter(student => Number(student.id) !== id);
  saveState();
  render();
  showToast("Étudiant supprimé");
}

function deleteCourse(id) {
  if (state.enrollments.some(enrollment => Number(enrollment.courseId) === id)) {
    showToast("Suppression bloquée : formation utilisée");
    return;
  }
  if (!confirm("Supprimer cette formation ?")) return;
  state.courses = state.courses.filter(course => Number(course.id) !== id);
  saveState();
  render();
  showToast("Formation supprimée");
}

function deleteGroup(id) {
  if (state.enrollments.some(enrollment => Number(enrollment.groupId) === id)) {
    showToast("Suppression bloquée : promotion utilisée");
    return;
  }
  if (!confirm("Supprimer cette promotion ?")) return;
  state.groups = state.groups.filter(group => Number(group.id) !== id);
  saveState();
  render();
  showToast("Promotion supprimée");
}

function deletePayment(id) {
  if (!canControlPayments()) {
    showToast("Seul l'administrateur peut supprimer un paiement");
    return;
  }
  const payment = findById(state.payments, id);
  if (!payment) return;
  const controlReason = controlledPaymentReason("Suppression du paiement");
  if (!controlReason) return;
  if (!confirm("Supprimer ce paiement ?")) return;
  logPaymentControl("Suppression", payment, controlReason, paymentSnapshot(payment), null);
  state.payments = state.payments.filter(payment => Number(payment.id) !== id);
  saveState();
  resetPaymentForm();
  render();
  showToast("Paiement supprime avec controle");
}

function deleteCashEntry(id) {
  if (!confirm("Supprimer cette opération de caisse ?")) return;
  state.cashEntries = state.cashEntries.filter(entry => Number(entry.id) !== id);
  saveState();
  render();
  showToast("Opération supprimée");
}

function deletePaymentMotif(key) {
  if (key === "scolarite") {
    showToast("Le motif Scolarité est obligatoire");
    return;
  }
  collectPaymentMotifInputs();
  if (state.payments.some(payment => payment.reasonKey === key)) {
    showToast("Suppression bloquée : motif déjà utilisé");
    return;
  }
  if (!confirm("Supprimer ce motif ?")) return;
  state.paymentMotifs = state.paymentMotifs.filter(motif => motif.key !== key);
  saveState();
  render();
  showToast("Motif supprimé");
}

function deleteUserAccess(id) {
  if (!isAdmin()) return;
  const user = state.users.find(item => Number(item.id) === id);
  if (!user || user.role === "Administrateur") {
    showToast("Le compte administrateur ne peut pas être supprimé");
    return;
  }
  collectCurrentUserAccessDraft();
  if (!confirm("Supprimer cet utilisateur ?")) return;
  state.users = state.users.filter(item => Number(item.id) !== id);
  saveState();
  renderSettings();
  showToast("Utilisateur supprimé");
}

function deleteTrainer(id) {
  if (state.evaluations.some(evaluation => Number(evaluation.trainerId) === id)) {
    showToast("Suppression bloquee : formateur utilise");
    return;
  }
  if (state.staffPayments.some(payment => payment.payeeType === "trainer" && Number(payment.payeeId) === id)) {
    showToast("Suppression bloquee : fiche de paie formateur enregistree");
    return;
  }
  if (!confirm("Supprimer ce formateur ?")) return;
  state.trainers = state.trainers.filter(trainer => Number(trainer.id) !== id);
  saveState();
  render();
  showToast("Formateur supprime");
}

function deleteStaff(id) {
  if (state.staffPayments.some(payment => (payment.payeeType || "staff") === "staff" && Number(payment.payeeId || payment.staffId) === id)) {
    showToast("Suppression bloquee : paiements enregistres");
    return;
  }
  if (!confirm("Supprimer ce personnel ?")) return;
  state.staffMembers = state.staffMembers.filter(member => Number(member.id) !== id);
  saveState();
  render();
  showToast("Personnel supprime");
}

function deleteStaffPayment(id) {
  if (!confirm("Supprimer ce paiement personnel ?")) return;
  state.staffPayments = state.staffPayments.filter(payment => Number(payment.id) !== id);
  saveState();
  render();
  showToast("Paiement personnel supprime");
}

function deleteEvaluation(id) {
  if (!confirm("Supprimer cette evaluation ?")) return;
  state.evaluations = state.evaluations.filter(evaluation => Number(evaluation.id) !== id);
  saveState();
  render();
  showToast("Evaluation supprimee");
}

function resetStudentForm() {
  const form = document.getElementById("studentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("studentFormTitle").textContent = "Nouvel étudiant";
  document.getElementById("studentMatricule").value = generateMatricule(yearFromDate());
  document.getElementById("studentStatus").value = "actif";
  resetPersonFileDraft("student");
}

function resetCourseForm() {
  const form = document.getElementById("courseForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("courseFormTitle").textContent = "Nouvelle formation";
  document.getElementById("courseStatus").value = "active";
}

function resetGroupForm() {
  const form = document.getElementById("groupForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("groupFormTitle").textContent = "Nouvelle promotion";
  document.getElementById("groupYear").value = String(new Date().getFullYear());
  document.getElementById("groupSessionType").value = "jour";
}

function resetEnrollmentForm() {
  const form = document.getElementById("enrollmentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("enrollmentFormTitle").textContent = "Nouvelle inscription";
  document.getElementById("enrollmentDate").value = today();
  document.getElementById("enrollmentDiscount").value = 0;
  syncSelects();
  applyCourseCostToEnrollment();
}

function resetPaymentForm() {
  const form = document.getElementById("paymentForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("paymentFormTitle").textContent = "Nouveau paiement";
  document.getElementById("paymentSubmitButton").textContent = "Encaisser";
  document.getElementById("paymentCancelEdit").hidden = true;
  document.getElementById("paymentDate").value = today();
  syncSelects();
  updatePaymentBalance();
  updatePaymentReasonFields();
}

function resetTrainerForm() {
  const form = document.getElementById("trainerForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("trainerFormTitle").textContent = "Nouveau formateur";
  document.getElementById("trainerStatus").value = "actif";
  resetPersonFileDraft("trainer");
}

function resetStaffForm() {
  const form = document.getElementById("staffForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("staffFormTitle").textContent = "Nouveau personnel";
  document.getElementById("staffSalary").value = 0;
  document.getElementById("staffStatus").value = "actif";
  resetPersonFileDraft("staff");
}

function resetEvaluationForm() {
  const form = document.getElementById("evaluationForm");
  form.reset();
  delete form.dataset.editId;
  document.getElementById("evaluationFormTitle").textContent = "Nouvelle évaluation";
  document.getElementById("evaluationDate").value = today();
  document.getElementById("evaluationMaxScore").value = 20;
  syncSelects();
  updateEvaluationStudents();
}

function applyCourseCostToEnrollment() {
  const course = getCourse(document.getElementById("enrollmentCourse").value);
  document.getElementById("enrollmentTotal").value = courseCost(course);
  updateEnrollmentFinal();
}

function updateEnrollmentFinal() {
  const total = Number(document.getElementById("enrollmentTotal").value || 0);
  const discount = Number(document.getElementById("enrollmentDiscount").value || 0);
  document.getElementById("enrollmentFinal").value = Math.max(0, total - discount);
}

function updatePaymentBalance() {
  const enrollment = getEnrollment(document.getElementById("paymentEnrollment").value);
  const editId = Number(document.getElementById("paymentForm").dataset.editId || 0);
  const balance = editId ? balanceForEnrollmentExcluding(enrollment, editId) : balanceForEnrollment(enrollment);
  ids.paymentBalance.textContent = `Reste scolarité : ${formatMoney(balance)}`;
}

function updatePaymentReasonFields() {
  const reason = document.getElementById("paymentReason").value;
  const amountInput = document.getElementById("paymentAmount");
  const motif = getPaymentMotif(reason);
  if (isTuitionMotifKey(reason)) {
    const enrollment = getEnrollment(document.getElementById("paymentEnrollment").value);
    const course = enrollment ? getCourse(enrollment.courseId) : undefined;
    const editId = Number(document.getElementById("paymentForm").dataset.editId || 0);
    const balance = editId ? balanceForEnrollmentExcluding(enrollment, editId) : balanceForEnrollment(enrollment);
    const suggested = Number(course?.monthlyFee || 0) || balance;
    amountInput.value = balance > 0 ? Math.min(suggested, balance) : suggested;
    amountInput.removeAttribute("readonly");
    amountInput.placeholder = "Montant payé";
    return;
  }
  amountInput.value = Number(motif?.amount || 0);
  amountInput.setAttribute("readonly", "readonly");
  amountInput.placeholder = "";
}

function startPayment(enrollmentId, reasonKey = "") {
  setView("payments");
  document.getElementById("paymentEnrollment").value = enrollmentId;
  if (reasonKey && [...document.getElementById("paymentReason").options].some(option => option.value === reasonKey)) {
    document.getElementById("paymentReason").value = reasonKey;
  }
  updatePaymentBalance();
  updatePaymentReasonFields();
  document.getElementById("paymentAmount").focus();
}

const amountInput = document.getElementById("paymentAmount");
if (amountInput) {
  amountInput.focus();
}

function receiptSeriesPrefix(reasonKey) {
  return isTuitionMotifKey(reasonKey) ? "REC-SCO" : "REC-ANN";
}

function nextReceiptNumber(reasonKey = "scolarite") {
  const year = new Date().getFullYear();
  const prefix = receiptSeriesPrefix(reasonKey);
  const pattern = new RegExp(`^${prefix}-${year}-(\\d+)$`);
  const receiptNumbers = [
    ...state.payments.map(payment => payment.receiptNumber),
    ...state.paymentAuditLog.flatMap(item => [item.receiptNumber, item.before?.receiptNumber, item.after?.receiptNumber])
  ].filter(Boolean);
  const maxNumber = receiptNumbers.reduce((max, receiptNumber) => {
    const match = String(receiptNumber).match(pattern);
    return match ? Math.max(max, Number(match[1]) || 0) : max;
  }, 0);
  return `${prefix}-${year}-${String(maxNumber + 1).padStart(3, "0")}`;
}

function printReceipt(paymentId) {
  const payment = findById(state.payments, paymentId);
  if (!payment) return;
  const enrollment = getEnrollment(payment.enrollmentId);
  const student = enrollment ? getStudent(enrollment.studentId) : undefined;
  const course = enrollment ? getCourse(enrollment.courseId) : undefined;
  const group = enrollment ? getGroup(enrollment.groupId) : undefined;
  const center = state.center || {};
  const logoSrc = normalizeLogoData(center.logoData);
  const tuitionPayment = isTuitionPayment(payment);
  const expected = tuitionPayment ? Number(enrollment?.finalAmount || 0) : Number(payment.amount || 0);
  const balance = tuitionPayment ? balanceForEnrollment(enrollment) : 0;
  const academicYear = group?.year || yearFromDate(enrollment?.date || payment.date);
  const receiptTitle = tuitionPayment ? "REÇU DE SCOLARITÉ" : "REÇU DE FRAIS ANNEXE";
  const summaryHeaders = tuitionPayment
    ? ["ANNEE", "Formation", "Scolarité", "Reste scolarité"]
    : ["ANNEE", "Formation", "Frais annexe", "Statut"];
  const summaryValues = tuitionPayment
    ? [academicYear, course?.code || "-", formatPrintAmount(expected), formatPrintAmount(balance)]
    : [academicYear, course?.code || "-", payment.reason || "Frais annexe", "Payé"];
  const recorder = currentUser?.name || payment.receivedBy || document.getElementById("roleSelect").value;
  const receiptDateTime = formatDateTime(new Date());
  ids.printArea.innerHTML = `
    <section class="print-document receipt-document">
      <header class="receipt-header-grid">
        <div class="receipt-school">
          <h1>${escapeHtml(center.name || "CFP EREXIT")}</h1>
          <p>${escapeHtml(center.subtitle || "Centre de Formation Professionnelle")}</p>
        </div>
        <div class="receipt-republic">
          <h2>REPUBLIQUE TOGOLAISE</h2>
          <p>Travail - Liberté - Patrie</p>
        </div>
      </header>

      <div class="receipt-logo-wrap">
        ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="">` : ""}
      </div>

      <div class="receipt-contact">
        <strong>${center.phone ? `TEL : ${escapeHtml(center.phone)}` : ""}</strong>
        <span>${escapeHtml(center.address || "")}</span>
        ${center.email ? `<span>${escapeHtml(center.email)}</span>` : ""}
      </div>

      <h2 class="receipt-type">${escapeHtml(receiptTitle)}</h2>

      <div class="receipt-topline">
        <div class="receipt-reference">RÉFÉRENCE : ${escapeHtml(payment.receiptNumber)}</div>
        <table class="receipt-summary-table">
          <thead>
            <tr>
              ${summaryHeaders.map(header => `<th>${escapeHtml(header)}</th>`).join("")}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${escapeHtml(summaryValues[0])}</td>
              <td>
                <strong>${escapeHtml(summaryValues[1])}</strong>
                <div>${escapeHtml(groupSessionLabel(group))}</div>
              </td>
              <td>${escapeHtml(summaryValues[2])}</td>
              <td>${escapeHtml(summaryValues[3])}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <h2 class="receipt-student">ÉTUDIANT : ${escapeHtml(fullName(student))}</h2>

      <table class="receipt-lines-table">
        <thead>
          <tr>
            <th>Libellé</th>
            <th>Date paiement</th>
            <th>Montant payé</th>
            <th>Mode de paiement</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${escapeHtml(payment.reason || "Paiement")}</td>
            <td>${formatDate(payment.date)}</td>
            <td>${formatPrintAmount(payment.amount)}</td>
            <td>${escapeHtml(payment.method || "-")}</td>
          </tr>
          <tr>
            <td colspan="2"><strong>TOTAL</strong></td>
            <td colspan="2"><strong>${formatPrintAmount(payment.amount)}</strong></td>
          </tr>
        </tbody>
      </table>

      <div class="receipt-responsibles">
        <div>
          <strong>Responsable saisie : ${escapeHtml(recorder)}</strong>
          <span>Ce ${escapeHtml(receiptDateTime)}</span>
        </div>
        <div>
          <strong>Responsable caisse : ${escapeHtml(payment.receivedBy || recorder)}</strong>
          <span>Ce ${escapeHtml(receiptDateTime)}</span>
        </div>
      </div>

      <div class="receipt-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <span>Signature et cachet</span>
      </div>

      <p class="receipt-note"><strong>NB :</strong> Aucun remboursement n'est accepté après encaissement. Merci</p>
    </section>
  `;
  window.print();
}

function printPayrollSlip(paymentId) {
  const payment = state.staffPayments.find(item => Number(item.id) === Number(paymentId));
  if (!payment) return;
  const beneficiary = payrollBeneficiary(payment);
  const title = beneficiary.type === "trainer" ? "Fiche de paie formateur" : "Fiche de paie personnel";
  const period = payment.period || today().slice(0, 7);
  const periodLabel = period.includes("-")
    ? new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric" }).format(new Date(`${period}-01T00:00:00`))
    : period;

  ids.printArea.innerHTML = `
    <section class="print-document payroll-document">
      ${printHeaderHtml(title)}
      <table>
        <tbody>
          <tr><td>Bénéficiaire</td><td><strong>${escapeHtml(beneficiary.name)}</strong></td></tr>
          <tr><td>Catégorie</td><td>${escapeHtml(beneficiary.role)}</td></tr>
          <tr><td>Période</td><td>${escapeHtml(periodLabel)}</td></tr>
          <tr><td>Date de paiement</td><td>${formatDate(payment.date)}</td></tr>
          <tr><td>Mode de paiement</td><td>${escapeHtml(payment.method || "-")}</td></tr>
          <tr><td>Référence interne</td><td>PAY-${String(payment.id).padStart(5, "0")}</td></tr>
        </tbody>
      </table>

      <table style="margin-top: 20px;">
        <thead>
          <tr>
            <th>Libellé</th>
            <th>Note</th>
            <th>Montant</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${escapeHtml(payment.reason || "Paiement")}</td>
            <td>${escapeHtml(payment.note || "-")}</td>
            <td><strong>${formatMoney(payment.amount)}</strong></td>
          </tr>
          <tr>
            <td colspan="2"><strong>Net payé</strong></td>
            <td><strong>${formatMoney(payment.amount)}</strong></td>
          </tr>
        </tbody>
      </table>

      <div class="print-signature-row">
        <p>Responsable caisse</p>
        <p>Bénéficiaire</p>
      </div>
      <p class="muted" style="margin-top: 18px;">Document généré le ${escapeHtml(formatDateTime(new Date()))}</p>
    </section>
  `;
  window.print();
}

function printEnrollment(enrollmentId) {
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Fiche d'inscription")}
      <table>
        <tbody>
          <tr><td>Matricule</td><td>${escapeHtml(student?.matricule || "-")}</td></tr>
          <tr><td>Étudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Téléphone</td><td>${escapeHtml(student?.phone || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Date</td><td>${formatDate(enrollment.date)}</td></tr>
          <tr><td>Scolarité finale</td><td>${formatMoney(enrollment.finalAmount)}</td></tr>
          <tr><td>Scolarité payée</td><td>${formatMoney(paidAmount(enrollment.id))}</td></tr>
          <tr><td>Frais annexes payés</td><td>${formatMoney(annexPaidAmount(enrollment.id))}</td></tr>
          <tr><td>Total payé</td><td>${formatMoney(totalPaidAmountForEnrollment(enrollment.id))}</td></tr>
          <tr><td>Reste scolarité</td><td>${formatMoney(balanceForEnrollment(enrollment))}</td></tr>
        </tbody>
      </table>
      <p style="margin-top: 42px;">Signature et cachet</p>
    </section>
  `;
  window.print();
}

function printAttestation(enrollmentId) {
  const template = templateByKey("attestation-inscription");
  if (template && template.status !== "archive") {
    printTemplateDocument("attestation-inscription", { enrollmentId });
    return;
  }
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  const center = state.center || {};
  const stampSrc = normalizeLogoData(center.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Attestation d'inscription")}
      <p style="margin-top: 28px; line-height: 1.8; font-size: 15px;">
        Nous soussignés <strong>${escapeHtml(center.name || "CFP EREXIT")}</strong>,
        attestons que <strong>${escapeHtml(fullName(student))}</strong>,
        matricule <strong>${escapeHtml(student?.matricule || "-")}</strong>, est régulièrement inscrit(e)
        à la formation <strong>${escapeHtml(course?.name || "-")}</strong>,
        promotion <strong>${escapeHtml(group?.name || "-")}</strong>
        (${escapeHtml(groupSessionLabel(group))}), pour l'année ${escapeHtml(group?.year || yearFromDate(enrollment.date))}.
      </p>
      <table style="margin-top: 22px;">
        <tbody>
          <tr><td>Date d'inscription</td><td>${formatDate(enrollment.date)}</td></tr>
          <tr><td>Scolarité finale</td><td>${formatMoney(enrollment.finalAmount)}</td></tr>
          <tr><td>Scolarité payée</td><td>${formatMoney(paidAmount(enrollment.id))}</td></tr>
          <tr><td>Reste scolarité</td><td>${formatMoney(balanceForEnrollment(enrollment))}</td></tr>
        </tbody>
      </table>
      <p style="margin-top: 28px;">Fait pour servir et valoir ce que de droit.</p>
      <div class="document-signature">
        ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
        <strong>Signature et cachet</strong>
      </div>
    </section>
  `;
  window.print();
}

function printTrainingContract(enrollmentId) {
  const template = templateByKey("contrat-formation");
  if (template && template.status !== "archive") {
    printTemplateDocument("contrat-formation", { enrollmentId });
    return;
  }
  const enrollment = getEnrollment(enrollmentId);
  if (!enrollment) return;
  const student = getStudent(enrollment.studentId);
  const course = getCourse(enrollment.courseId);
  const group = getGroup(enrollment.groupId);
  const center = state.center || {};
  const stampSrc = normalizeLogoData(center.stampData);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Contrat de formation")}
      <table>
        <tbody>
          <tr><td>Centre</td><td>${escapeHtml(center.name || "CFP EREXIT")}</td></tr>
          <tr><td>Étudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Matricule</td><td>${escapeHtml(student?.matricule || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Durée</td><td>${escapeHtml(course?.duration || "-")}</td></tr>
          <tr><td>Scolarité convenue</td><td>${formatMoney(enrollment.finalAmount)}</td></tr>
          <tr><td>Mensualité indicative</td><td>${formatMoney(course?.monthlyFee || 0)}</td></tr>
        </tbody>
      </table>
      <h2>Engagements</h2>
      <p>L'étudiant s'engage à respecter le règlement intérieur, les horaires, le programme pédagogique et les modalités de paiement convenues.</p>
      <p>Le centre s'engage à assurer la formation conformément au programme prévu et à suivre la progression de l'étudiant.</p>
      <div class="contract-signatures">
        <div>
          <strong>L'étudiant</strong>
          <span>Signature</span>
        </div>
        <div>
          ${stampSrc ? `<img src="${escapeHtml(stampSrc)}" alt="">` : ""}
          <strong>Le centre</strong>
          <span>Signature et cachet</span>
        </div>
      </div>
    </section>
  `;
  window.print();
}

function printBalancesReport() {
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(`Rapport des restes scolarité - ${formatDate(today())}`)}
      <table>
        <thead>
          <tr>
            <th>Étudiant</th>
            <th>Formation</th>
            <th>Type</th>
            <th>Scolarité finale</th>
            <th>Scolarité payée</th>
            <th>Reste scolarité</th>
          </tr>
        </thead>
        <tbody>
          ${balances().map(item => `
            <tr>
              <td>${escapeHtml(item.student)}</td>
              <td>${escapeHtml(item.course)}</td>
              <td>${escapeHtml(item.sessionType)}</td>
              <td>${formatMoney(item.finalAmount)}</td>
              <td>${formatMoney(item.paid)}</td>
              <td>${formatMoney(item.balance)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </section>
  `;
  window.print();
}

function printIndividualStudentReport() {
  const report = individualStudentReportData();
  const { student, enrollments, payments, paymentsByMotif, tuitionExpected, tuitionPaid, annexPaid, totalPaid, balance } = report;
  if (!student) {
    showToast("Aucun étudiant sélectionné");
    return;
  }

  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml(`Rapport individuel étudiant - ${formatDate(today())}`)}
      <table>
        <tbody>
          <tr><td>Matricule</td><td>${escapeHtml(student.matricule || "-")}</td></tr>
          <tr><td>Étudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Téléphone</td><td>${escapeHtml(student.phone || "-")}</td></tr>
          <tr><td>Email</td><td>${escapeHtml(student.email || "-")}</td></tr>
          <tr><td>Adresse</td><td>${escapeHtml(student.address || "-")}</td></tr>
          <tr><td>Statut</td><td>${escapeHtml(student.status || "-")}</td></tr>
        </tbody>
      </table>

      <h2>Inscriptions</h2>
      <table>
        <thead>
          <tr>
            <th>Formation</th>
            <th>Promotion</th>
            <th>Type</th>
            <th>Date</th>
            <th>Scolarité finale</th>
            <th>Reste</th>
          </tr>
        </thead>
        <tbody>
          ${enrollments.map(enrollment => {
            const course = getCourse(enrollment.courseId);
            const group = getGroup(enrollment.groupId);
            return `
              <tr>
                <td>${escapeHtml(course?.name || "-")}</td>
                <td>${escapeHtml(group?.name || "-")}</td>
                <td>${escapeHtml(groupSessionLabel(group))}</td>
                <td>${formatDate(enrollment.date)}</td>
                <td>${formatMoney(enrollment.finalAmount)}</td>
                <td>${formatMoney(balanceForEnrollment(enrollment))}</td>
              </tr>
            `;
          }).join("") || `<tr><td colspan="6">Aucune inscription</td></tr>`}
        </tbody>
      </table>

      <h2>Synthèse financière</h2>
      <table>
        <tbody>
          <tr><td>Scolarité due</td><td>${formatMoney(tuitionExpected)}</td></tr>
          <tr><td>Scolarité payée</td><td>${formatMoney(tuitionPaid)}</td></tr>
          <tr><td>Reste scolarité</td><td>${formatMoney(balance)}</td></tr>
          <tr><td>Frais annexes payés</td><td>${formatMoney(annexPaid)}</td></tr>
          <tr><td>Total payé</td><td><strong>${formatMoney(totalPaid)}</strong></td></tr>
        </tbody>
      </table>

      <h2>Détail par motif</h2>
      <table>
        <thead>
          <tr>
            <th>Motif</th>
            <th>Catégorie</th>
            <th>Montant payé</th>
            <th>Dernier paiement</th>
          </tr>
        </thead>
        <tbody>
          ${paymentsByMotif.map(item => `
            <tr>
              <td>${escapeHtml(item.reason)}</td>
              <td>${escapeHtml(item.category)}</td>
              <td>${formatMoney(item.amount)}</td>
              <td>${formatDate(item.lastDate)}</td>
            </tr>
          `).join("") || `<tr><td colspan="4">Aucun paiement</td></tr>`}
        </tbody>
      </table>

      <h2>Historique des paiements</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Reçu</th>
            <th>Motif</th>
            <th>Catégorie</th>
            <th>Montant</th>
            <th>Mode</th>
          </tr>
        </thead>
        <tbody>
          ${payments.map(payment => `
            <tr>
              <td>${formatDate(payment.date)}</td>
              <td>${escapeHtml(payment.receiptNumber || "-")}</td>
              <td>${escapeHtml(payment.reason || "-")}</td>
              <td>${isTuitionPayment(payment) ? "Scolarité" : "Frais annexe"}</td>
              <td>${formatMoney(payment.amount)}</td>
              <td>${escapeHtml(payment.method || "-")}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucun paiement</td></tr>`}
        </tbody>
      </table>

      <h2>Notes et évaluations</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Évaluation</th>
            <th>Type</th>
            <th>Note</th>
            <th>Statut</th>
            <th>Appréciation</th>
          </tr>
        </thead>
        <tbody>
          ${studentGradeRows(student.id).map(row => `
            <tr>
              <td>${formatDate(row.date)}</td>
              <td>${escapeHtml(row.title)}</td>
              <td>${escapeHtml(row.type)}</td>
              <td>${escapeHtml(row.score)}</td>
              <td>${escapeHtml(row.status)}</td>
              <td>${escapeHtml(row.needsMakeup ? "Non validé" : (row.appreciation || ""))}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucune note</td></tr>`}
        </tbody>
      </table>

      <p style="margin-top: 42px;">Signature et cachet</p>
    </section>
  `;
  window.print();
}

function printStudentTranscript(studentId = Number(ids.individualReportStudent?.value || 0)) {
  const student = getStudent(studentId);
  if (!student) {
    showToast("Choisissez un étudiant");
    return;
  }

  const rows = studentGradeRows(student.id);
  const scoredRows = rows.filter(row => row.score20 !== null);
  const average20 = scoredRows.length
    ? scoredRows.reduce((sum, row) => sum + Number(row.score20 || 0), 0) / scoredRows.length
    : null;
  const enrollment = state.enrollments.find(item => Number(item.studentId) === Number(student.id));
  const course = enrollment ? getCourse(enrollment.courseId) : null;
  const group = enrollment ? getGroup(enrollment.groupId) : null;

  ids.printArea.innerHTML = `
    <section class="print-document transcript-document">
      ${printHeaderHtml("Relevé de notes")}
      <table>
        <tbody>
          <tr><td>Étudiant</td><td><strong>${escapeHtml(fullName(student))}</strong></td></tr>
          <tr><td>Matricule</td><td>${escapeHtml(student.matricule || "-")}</td></tr>
          <tr><td>Formation</td><td>${escapeHtml(course?.name || "-")}</td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Condition de validation</td><td>${PASSING_SCORE_20}/20 minimum par matière</td></tr>
        </tbody>
      </table>

      <div class="transcript-summary">
        <div><span>Moyenne générale</span><strong>${average20 === null ? "-" : `${average20.toFixed(2)} / 20`}</strong></div>
        <div><span>Matières évaluées</span><strong>${rows.length}</strong></div>
        <div><span>Matières validées</span><strong>${rows.filter(row => !row.needsMakeup && row.score20 !== null).length}</strong></div>
        <div><span>Matières non validées</span><strong>${rows.filter(row => row.needsMakeup).length}</strong></div>
      </div>

      <table style="margin-top: 18px;">
        <thead>
          <tr>
            <th>Date</th>
            <th>Matière / Évaluation</th>
            <th>Promotion</th>
            <th>Note</th>
            <th>Statut</th>
            <th>Appréciation</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map(row => `
            <tr>
              <td>${formatDate(row.date)}</td>
              <td>${escapeHtml(row.title)}</td>
              <td>${escapeHtml(row.groupName)}</td>
              <td>${escapeHtml(row.score)}</td>
              <td>${escapeHtml(row.status)}</td>
              <td>${escapeHtml(row.needsMakeup ? "Non validé" : (row.appreciation || ""))}</td>
            </tr>
          `).join("") || `<tr><td colspan="6">Aucune note enregistrée</td></tr>`}
        </tbody>
      </table>

      <div class="print-signature-row">
        <p>Direction des études</p>
        <p>Signature et cachet</p>
      </div>
    </section>
  `;
  window.print();
}

function studentGradeRows(studentId) {
  return state.evaluations.flatMap(evaluation => {
    const grade = (evaluation.grades || []).find(item => Number(item.studentId) === Number(studentId));
    if (!grade) return [];
    const maxScore = Number(evaluation.maxScore || 20);
    const needsMakeup = gradeNeedsMakeup(grade.score, maxScore);
    const group = getGroup(evaluation.groupId);
    const scoreNumber = Number(grade.score);
    return [{
      date: evaluation.date,
      title: evaluation.title,
      type: evaluation.type || "-",
      groupName: group?.name || "-",
      sessionType: groupSessionLabel(group),
      rawScore: Number.isNaN(scoreNumber) ? null : scoreNumber,
      maxScore,
      score20: Number.isNaN(scoreNumber) ? null : scoreNumber * 20 / maxScore,
      score: grade.score === "" ? "-" : `${grade.score} / ${maxScore}`,
      status: gradeStatusLabel(grade.score, maxScore),
      needsMakeup,
      makeupFee: needsMakeup ? MAKEUP_FEE : 0,
      appreciation: grade.appreciation || ""
    }];
  }).sort((a, b) => String(a.date).localeCompare(String(b.date)));
}

function printGradesReport(evaluationId) {
  const evaluation = getEvaluation(evaluationId);
  if (!evaluation) return;
  const group = getGroup(evaluation.groupId);
  const trainer = getTrainer(evaluation.trainerId);
  const maxScore = Number(evaluation.maxScore || 20);
  const grades = Array.isArray(evaluation.grades) ? evaluation.grades : [];
  const makeup = evaluationMakeupStats(evaluation);
  ids.printArea.innerHTML = `
    <section class="print-document">
      ${printHeaderHtml("Releve de notes")}
      <table>
        <tbody>
          <tr><td>Evaluation</td><td><strong>${escapeHtml(evaluation.title)}</strong></td></tr>
          <tr><td>Promotion</td><td>${escapeHtml(group?.name || "-")}</td></tr>
          <tr><td>Type de cours</td><td>${escapeHtml(groupSessionLabel(group))}</td></tr>
          <tr><td>Formateur</td><td>${escapeHtml(trainerName(trainer))}</td></tr>
          <tr><td>Date</td><td>${formatDate(evaluation.date)}</td></tr>
          <tr><td>Moyenne</td><td>${formatAverage(evaluation)}</td></tr>
          <tr><td>Condition de validation</td><td>${PASSING_SCORE_20}/20 minimum par matière</td></tr>
          <tr><td>Matières non validées</td><td>${makeup.count} étudiant(s)</td></tr>
        </tbody>
      </table>
      <table style="margin-top: 18px;">
        <thead>
          <tr>
            <th>Matricule</th>
            <th>Étudiant</th>
            <th>Note</th>
            <th>Statut</th>
            <th>Appreciation</th>
          </tr>
        </thead>
        <tbody>
          ${grades.map(grade => {
            const student = getStudent(grade.studentId);
            return `
              <tr>
                <td>${escapeHtml(student?.matricule || "-")}</td>
                <td>${escapeHtml(fullName(student))}</td>
                <td>${grade.score === "" ? "-" : `${escapeHtml(grade.score)} / ${maxScore}`}</td>
                <td>${escapeHtml(gradeStatusLabel(grade.score, maxScore))}</td>
                <td>${escapeHtml(gradeNeedsMakeup(grade.score, maxScore) ? "Non validé" : (grade.appreciation || ""))}</td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
      <p style="margin-top: 42px;">Signature du formateur</p>
    </section>
  `;
  window.print();
}

function exportPaymentsCsv(filename = "paiements-cfp-erexit.csv") {
  const rows = state.payments.map(payment => {
    const enrollment = getEnrollment(payment.enrollmentId);
    const student = enrollment ? getStudent(enrollment.studentId) : undefined;
    return [
      payment.receiptNumber,
      fullName(student),
      payment.amount,
      payment.method,
      payment.reason,
      isTuitionPayment(payment) ? "Scolarité" : "Frais annexe",
      payment.date
    ];
  });
  downloadCsv(filename, ["Reçu", "Étudiant", "Montant", "Mode", "Motif", "Catégorie", "Date"], rows);
}

function exportCashCsv(filename = "caisse-cfp-erexit.csv") {
  const rows = state.cashEntries.map(entry => [
    entry.date,
    entry.type === "income" ? "Entrée" : "Dépense",
    entry.category,
    entry.amount,
    entry.method,
    entry.description,
    entry.recordedBy
  ]);
  downloadCsv(filename, ["Date", "Type", "Catégorie", "Montant", "Mode", "Description", "Saisi par"], rows);
}

function exportStudentsCsv(filename = "etudiants-cfp-erexit.csv") {
  const rows = state.students.map(student => [
    student.matricule,
    student.firstName,
    student.lastName,
    student.phone,
    student.email,
    student.status
  ]);
  downloadCsv(filename, ["Matricule", "Prénom", "Nom", "Téléphone", "Email", "Statut"], rows);
}

function exportAllCsv() {
  const stamp = exportStamp();
  exportPaymentsCsv(`paiements-cfp-erexit-${stamp}.csv`);
  exportCashCsv(`caisse-cfp-erexit-${stamp}.csv`);
  exportStudentsCsv(`etudiants-cfp-erexit-${stamp}.csv`);
  exportEnrollmentsCsv(`inscriptions-cfp-erexit-${stamp}.csv`);
  exportStaffPaymentsCsv(`paiements-personnel-cfp-erexit-${stamp}.csv`);
  showToast("Exports CSV générés");
}

function exportEnrollmentsCsv(filename = "inscriptions-cfp-erexit.csv") {
  const rows = state.enrollments.map(enrollment => {
    const student = getStudent(enrollment.studentId);
    const course = getCourse(enrollment.courseId);
    const group = getGroup(enrollment.groupId);
    return [
      fullName(student),
      course?.name || "",
      group?.name || "",
      groupSessionLabel(group),
      enrollment.date,
      enrollment.finalAmount,
      paidAmount(enrollment.id),
      annexPaidAmount(enrollment.id),
      balanceForEnrollment(enrollment),
      enrollment.status
    ];
  });
  downloadCsv(filename, ["Étudiant", "Formation", "Promotion", "Type de cours", "Date", "Scolarité finale", "Scolarité payée", "Annexes payées", "Reste scolarité", "Statut"], rows);
}

function exportStaffPaymentsCsv(filename = "paiements-personnel-cfp-erexit.csv") {
  const rows = state.staffPayments.map(payment => {
    const member = getStaffMember(payment.staffId);
    return [
      payment.date,
      staffName(member),
      payment.period,
      payment.reason,
      payment.amount,
      payment.method,
      payment.note,
      payment.recordedBy
    ];
  });
  downloadCsv(filename, ["Date", "Personnel", "Période", "Motif", "Montant", "Mode", "Note", "Saisi par"], rows);
}

function downloadCsv(filename, headers, rows) {
  const csv = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(";"))
    .join("\n");
  downloadFile(filename, `\uFEFF${csv}`, "text/csv;charset=utf-8");
}

function exportStamp() {
  return new Date().toISOString().slice(0, 19).replaceAll(":", "").replace("T", "-");
}

function exportJson() {
  const payload = {
    exportedAt: new Date().toISOString(),
    app: "CFP EREXIT Manager",
    version: "2.0.0",
    data: state
  };
  downloadFile(`cfp-erexit-sauvegarde-${exportStamp()}.json`, JSON.stringify(payload, null, 2), "application/json");
}

function importJson(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      const importedState = imported?.data && typeof imported.data === "object" ? imported.data : imported;
      state = { ...seedState(), ...importedState };
      saveState();
      render();
      showToast("Données importées");
    } catch {
      showToast("Fichier JSON invalide");
    }
    event.target.value = "";
  };
  reader.readAsText(file);
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function resetData() {
  if (!confirm("Réinitialiser toutes les données locales ?")) return;
  state = seedState();
  saveState();
  render();
  showToast("Données réinitialisées");
}

window.addEventListener("error", (event) => {
  console.error("Erreur JS :", event.error);
});

bootstrap();
