# CFP EREXIT Manager

## Version locale simple

Ouvrir le fichier :

`index.html`

Cette option fonctionne directement dans le navigateur et sauvegarde les donnees dans le stockage local du navigateur.

## Version serveur recommandee

Lancer l'application avec :

```powershell
npm start
```

Puis ouvrir :

`http://localhost:3000`

Depuis un autre poste du meme reseau, ouvrir :

`http://ADRESSE-IP-DU-PC:3000`

Pour un hebergement en ligne/cloud, lancer le meme serveur sur un VPS ou un service Node.js, avec sauvegarde du dossier `data` et HTTPS.

Les donnees sont sauvegardees dans :

`data/db.json`

Des copies automatiques sont conservees dans :

`data/backups`

## Comptes de test

- Administrateur : `admin` / `admin123` (`admin@cftperexit.com`)
- Secretariat : `secretariat` / `secret123` (`secretariat@cftperexit.com`)
- Comptabilite : `comptable` / `compta123` (`comptable@cftperexit.com`)
- Formateur : `formateur` / `formateur123` (`formateur@cftperexit.com`)

## Modules disponibles

- Tableau de bord
- Apprenants
- Formations
- Promotions / classes
- Inscriptions
- Paiements
- Montants configurables par motif : inscription, document, tenue, T-shirt, macaron
- Motif et montant libres pour les paiements de type autre
- Recu de paiement imprimable
- Fiche d'inscription imprimable
- Presences
- Formateurs
- Notes et evaluations
- Releve de notes imprimable
- Rapports
- Export CSV
- Export / import JSON
- Connexion utilisateur
- Sauvegarde serveur avec API
- Matricule automatique au format `ERX-annee-00000`

## Fichiers principaux

- `index.html` : structure de l'application
- `styles.css` : design et responsive
- `app.js` : logique, donnees et interactions
- `server.js` : serveur web, API et authentification
- `data/db.json` : base de donnees JSON de depart
- `package.json` : commande de lancement
- `schema-cfp-erexit.sql` : base de donnees recommandee pour la future version serveur
- `cahier-des-charges-cfp-erexit.md` : specification du projet

## Limite de cette version

Cette version est fonctionnelle pour tester la gestion du centre avec une base persistante JSON et plusieurs comptes.

Pour une utilisation officielle en production, il faudra ensuite ajouter :

- base de donnees MySQL ou PostgreSQL ;
- sauvegardes automatiques ;
- gestion fine des droits ;
- acces reseau controle depuis plusieurs ordinateurs ;
- certificats HTTPS ;
- changement obligatoire des mots de passe par defaut.

## Prochaine evolution conseillee

Transformer cette version en application Laravel + MySQL ou Django + PostgreSQL, en reutilisant les modules et le schema deja prepares.
